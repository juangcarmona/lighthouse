import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { readImplementationEvidence } from '@juangcarmona/lighthouse-sdlc/implementation-evidence';
import { taskDigest } from './node_modules/@juangcarmona/lighthouse-sdlc/src/issue-actions.mjs';
const phase=process.argv[2]??'unchanged', repository='juangcarmona/lighthouse', owner='juangcarmona', issue=372;
const root='/tmp/100-evidence/native', apiRoot=root+'/consumer-api-'+phase;mkdirSync(apiRoot,{recursive:true});let sequence=0;
const api=async(path,method='GET',body,optional=false)=>{
 assert.equal(method,'GET');
 try{
  const raw=execFileSync('gh',['api',`repos/${repository}/${path}`],{encoding:'utf8',maxBuffer:4*1024*1024,stdio:['ignore','pipe','pipe']});
  writeFileSync(apiRoot+'/'+String(++sequence).padStart(3,'0')+'.json',JSON.stringify({path,response:JSON.parse(raw)}));
  return JSON.parse(raw);
 }catch(error){
  if(optional&&String(error.stderr).includes('HTTP 404'))return null;
  throw Error(`Authenticated GitHub read unavailable: ${path}: ${String(error.stderr).slice(0,200)}`);
 }
};
const pr=await api('pulls/374'),item=await api('issues/372'),comments=await api('issues/372/comments?per_page=100&page=1'), baseline=await api('commits/codex/100-native');
assert.equal(pr.user.login,'github-actions[bot]');assert.equal(pr.head.repo.full_name,repository);assert.equal(pr.base.ref,'codex/100-native');assert.equal(item.user.login,owner);
const answers=comments.filter(c=>c.user.login===owner&&!/<!-- lighthouse-(?:actions|completion|run):/.test(c.body));
const completion={binding:{repository,issue,pr:pr.number,head:pr.head.sha,intent:taskDigest(item,answers),branch:pr.base.ref},currentRevision:baseline.sha};
if(phase==='criteria-stale')completion.binding.intent='0'.repeat(64);
const result=await readImplementationEvidence(api,completion);
writeFileSync(root+'/consumer-'+phase+'.json',JSON.stringify({phase,completion,result},null,2)+'\n');
const expected=['unchanged','unrelated'].includes(phase)?'passed':'unavailable';
assert.equal(result.status,expected,result.reason);
if(expected==='passed'){
 assert.equal(result.checks.length,3);
 const provider=result.checks.find(c=>c.command.includes('prodshape'));
 assert.equal(provider.output.jsonSummary.errors,0);
 assert.ok(provider.output.jsonSummary.current>0);
 assert.equal(result.publication.tree,'aa935816dca3fdd498f94605ae3ee44c759383be');
 assert.ok(result.checks.find(c=>c.command.includes('openspec')).output.content.includes('valid'));
}
console.log(JSON.stringify({phase,status:result.status,reason:result.reason??null,nativeRun:result.producer?.runId,attempt:result.producer?.attempt,commands:result.checks.map(c=>({name:c.name,status:c.status,summary:c.output.jsonSummary??null}))}));
