import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { readImplementationEvidence } from '@juangcarmona/lighthouse-sdlc/implementation-evidence';
import { assertCitedChecks } from './node_modules/@juangcarmona/lighthouse-sdlc/src/completion.mjs';
import { taskDigest } from './node_modules/@juangcarmona/lighthouse-sdlc/src/issue-actions.mjs';
const phase=process.argv[2]??'unchanged', repository='juangcarmona/lighthouse', owner='juangcarmona', issue=372;
const root='/tmp/100-evidence/native/final', apiRoot=root+'/consumer-api-'+phase;mkdirSync(apiRoot,{recursive:true});let sequence=0;
const api=async(path,method='GET',body,optional=false)=>{
 assert.equal(method,'GET');
 try{
  const raw=execFileSync('gh',['api',`repos/${repository}/${path}`],{encoding:'utf8',maxBuffer:4*1024*1024,stdio:['ignore','pipe','pipe']});
  writeFileSync(apiRoot+'/'+String(++sequence).padStart(3,'0')+'.json',JSON.stringify({path,response:JSON.parse(raw)}));
  return JSON.parse(raw);
 }catch(error){
  if(optional&&String(error.stderr).includes('HTTP 404'))return null;
  throw Error(`Authenticated GitHub read unavailable: ${path}: ${String(error.stderr).slice(0,200)}`);
 }
};
const number=Number(process.argv[3]);assert.ok(number>374);
const pr=await api('pulls/'+number),item=await api('issues/372'),comments=await api('issues/372/comments?per_page=100&page=1'), baseline=await api('git/ref/heads/codex/100-native');
assert.equal(pr.user.login,'github-actions[bot]');assert.equal(pr.head.repo.full_name,repository);assert.equal(pr.base.ref,'codex/100-native');assert.equal(item.user.login,owner);
const answers=comments.filter(c=>c.user.login===owner&&!/<!-- lighthouse-(?:actions|completion|run):/.test(c.body));
const liveHead=await api('git/ref/heads/'+pr.head.ref);
const completion={binding:{repository,issue,pr:pr.number,head:liveHead.object.sha,intent:taskDigest(item,answers),branch:pr.base.ref},currentRevision:baseline.object.sha};

const result=await readImplementationEvidence(api,completion);
writeFileSync(root+'/consumer-'+phase+'.json',JSON.stringify({phase,completion,result},null,2)+'\n');
const expected=['unchanged','unrelated','restored','final-package','scoped-final'].includes(phase)?'passed':'unavailable';
assert.equal(result.status,expected,result.reason);
if(expected==='passed'){
 assert.equal(result.checks.length,3);
 const assessment={result:{evidence:[{id:result.checks[0].evidenceId,status:'passed'}]}};
 assert.doesNotThrow(()=>assertCitedChecks(assessment,{observedChecks:result.checks},{observedChecks:result.checks}));
 assert.throws(()=>assertCitedChecks({result:{evidence:[{id:'implementation:forged',status:'passed'}]}},{observedChecks:result.checks},{observedChecks:result.checks}),/unauthenticated/);
 const provider=result.checks.find(c=>c.command.includes('prodshape'));
 assert.ok(provider.output.jsonSummary,'Provider output must include the complete JSON summary');
 assert.equal(provider.output.jsonSummary.errors,0);
 assert.ok(provider.output.jsonSummary.current>0);
 if(phase==='scoped-final'){
  const scoped=provider.output.jsonEvidence;
  assert.ok(scoped,'Retain original provider rows for this candidate');
  assert.equal(scoped.citations.length,3);
  assert.ok(scoped.citations.every(row=>row.source.startsWith('openspec/changes/issue-372-proposal/')&&row.status==='current'));
  assert.ok(scoped.diagnostics.length>=2,'Preserve unrelated provider warnings');
 }

 assert.equal(result.publication.tree,(await api('git/commits/'+pr.head.sha)).tree.sha);
 assert.ok(result.checks.find(c=>c.command.includes('openspec')&&c.command.includes('validate')).output.content.includes('valid'));
}
console.log(JSON.stringify({phase,status:result.status,reason:result.reason??null,nativeRun:result.producer?.runId,attempt:result.producer?.attempt,commands:result.checks.map(c=>({name:c.name,status:c.status,summary:c.output.jsonSummary??null}))}));
