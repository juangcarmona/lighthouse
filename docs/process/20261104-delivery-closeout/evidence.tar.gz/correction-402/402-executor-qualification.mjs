import { mkdtemp, mkdir, writeFile, readFile, rm } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { randomBytes, createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
const root=resolve(process.argv[2]),out=resolve(process.argv[3]),image=process.argv[4];
const load=file=>import(pathToFileURL(join(root,'src/packages/sdlc/src',file)));
const {snapshotSource}=await load('opencode-execute.mjs');
const {prepareImplementationWorkspace}=await load('implementation-runtime.mjs');
const {createExecutionOwner,runOwnedDocker}=await load('execution-cleanup.mjs');
const directory=await mkdtemp(join(tmpdir(),'lh-402-executor-')),source=join(directory,'source');await mkdir(source);
const owner=createExecutionOwner(join(directory,'journals'),{repository:'juangcarmona/lighthouse',runId:randomBytes(32).toString('hex'),workflowRunId:'402',attempt:1});
const config={resourceOwner:owner,image,uid:process.getuid()};let passed=false;
const hashes={};for(const file of ['implementation-runtime.mjs','opencode-execute.mjs'])hashes[file]=createHash('sha256').update(await readFile(join(root,'src/packages/sdlc/src',file))).digest('hex');
try{
 await snapshotSource(root,source);await prepareImplementationWorkspace(source,config,402,'juangcarmona/lighthouse');
 console.log('Exact failed native image:',image);
 console.log(runOwnedDocker(config,['run','--rm','--network','none','--user',`${process.getuid()}:${process.getgid()}`,'--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--pids-limit','1024','--memory','4g','--cpus','2','--shm-size','1g','--tmpfs','/tmp:rw,nosuid,nodev,size=1g','--env','HOME=/tmp/qualification-home','--env','GITHUB_ACTIONS=true','--env','PUPPETEER_EXECUTABLE_PATH=/usr/bin/chromium','--mount',`type=bind,src=${source},dst=/workspace`,'--mount',`type=bind,src=${root}/node_modules,dst=/workspace/node_modules,readonly`,'--workdir','/workspace','--entrypoint','sh',image,'-c','node --version && git remote get-url origin && node scripts/build-public-site.mjs && node scripts/verify-public-site.mjs'],{encoding:'utf8',stdio:['ignore','pipe','pipe'],timeout:600000,maxBuffer:8*1024*1024}));passed=true;
}finally{
 const cleanup=owner.cleanup();await writeFile(join(out,'402-executor-proof.json'),JSON.stringify({image,passed,codeRevision:execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),testedSourceSha256:hashes,cleanup},null,2)+'\n');console.log('Owned resource cleanup:',cleanup.status);if(cleanup.status!=='clean')throw Error('Qualification cleanup unverified');if(passed)await rm(directory,{recursive:true,force:true});
}
