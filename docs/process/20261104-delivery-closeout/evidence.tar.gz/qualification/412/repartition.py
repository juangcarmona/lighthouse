import sys,pathlib,zipfile,re,glob,json,hashlib
source,template,destination=map(pathlib.Path,sys.argv[1:4]);destination.mkdir(parents=True,exist_ok=True)
run='41938501442';attempt='1';text=template.read_text();prefix='${{ runner.temp }}/lighthouse-unattended-${{ github.run_id }}/'
blocks=text.split('      - name: ')
def patterns(label):
 block=next(b for b in blocks if b.startswith(label+'\n'));lines=block.splitlines();values=[];collect=False
 for line in lines:
  if line.strip()=='path: |':collect=True;continue
  if line.strip().startswith('path: '):values.append(line.strip()[6:]);continue
  if collect:
   if not line.startswith('            '):break
   values.append(line.strip())
 return [p.removeprefix(prefix).replace('${{ github.run_id }}',run).replace('${{ github.run_attempt }}',attempt) for p in values]
canonical_patterns=patterns('Retain bounded delivery receipts');diagnostic_patterns=patterns('Retain execution diagnostics')
def matches(name,items):return any(re.fullmatch(glob.translate(p,recursive=True),name) for p in items)
with zipfile.ZipFile(source) as old:
 data={n:old.read(n) for n in old.namelist() if not n.endswith('/')}
 canonical={n:b for n,b in data.items() if matches(n,canonical_patterns)}
 diagnostic={n:b for n,b in data.items() if matches(n,diagnostic_patterns)}
 assert canonical and diagnostic and not canonical.keys()&diagnostic.keys()
 assert not any('/workspace/' in n for n in [*canonical,*diagnostic])
 intended={n for n in data if '/tmp/lighthouse-'+run+'-'+attempt+'/evidence/' in n and '/workspace/' not in n}
 assert set(diagnostic)==intended
 for label,files in [('canonical',canonical),('diagnostics',diagnostic)]:
  with zipfile.ZipFile(destination/(label+'.zip'),'w',compression=zipfile.ZIP_DEFLATED) as output:
   for name,content in files.items():output.writestr(name,content)
 assert (destination/'canonical.zip').stat().st_size<2*1024*1024<source.stat().st_size
 manifest={'sourceZip':str(source),'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'originalBytes':source.stat().st_size,'canonicalZip':str(destination/'canonical.zip'),'canonicalBytes':(destination/'canonical.zip').stat().st_size,'canonicalPatterns':canonical_patterns,'diagnosticPatterns':diagnostic_patterns,'canonicalMembers':[{'name':n,'sha256':hashlib.sha256(b).hexdigest(),'value':json.loads(b)} for n,b in canonical.items()],'diagnosticMembers':[{'name':n,'sha256':hashlib.sha256(b).hexdigest()} for n,b in diagnostic.items()],'omittedWorkspaceMembers':sum('/workspace/' in n for n in data),'scope':'Repartition control only; failed native run remains failed and grants no acceptance'}
 (destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps({k:manifest[k] for k in ['originalBytes','canonicalBytes','omittedWorkspaceMembers']}));print('canonical members',len(canonical),'diagnostics',len(diagnostic))
