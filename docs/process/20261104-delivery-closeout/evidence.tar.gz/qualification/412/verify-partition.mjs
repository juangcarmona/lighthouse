import { readFile, writeFile, mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';
const [repository, manifestPath]=process.argv.slice(2);
const {readZipJson}=await import(pathToFileURL(join(repository,'src/packages/sdlc/src/zip-json.mjs')));
const {readActionsJson}=await import(pathToFileURL(join(repository,'src/packages/sdlc/src/actions-artifact.mjs')));
const proof=JSON.parse(await readFile(manifestPath,'utf8')), old=await readFile(proof.sourceZip), canonical=await readFile(proof.canonicalZip);
assert.throws(()=>readZipJson(old,proof.canonicalMembers[0].name),/Invalid or unsupported/);
for(const member of proof.canonicalMembers)assert.deepEqual(readZipJson(canonical,member.name),member.value);
const bin=await mkdtemp(join(tmpdir(),'lh-artifact-transport-')),invoked=join(bin,'invoked'),prior=process.env.PATH;
await writeFile(join(bin,'gh'),`#!${process.execPath}\nconst fs=require('node:fs');if(process.argv.slice(2).join(' ')!=='api repos/fixture/fixture/actions/artifacts/1/zip')process.exit(2);fs.writeFileSync(${JSON.stringify(invoked)},'read');process.stdout.write(fs.readFileSync(${JSON.stringify(proof.canonicalZip)}));\n`,{mode:0o755});
const api=size=>async path=>{assert.equal(path,'actions/runs/42/artifacts?per_page=100');return{total_count:1,artifacts:[{id:1,name:'fixture-canonical',expired:false,size_in_bytes:size}]};};
try {
 process.env.PATH=bin+':'+prior;
 await assert.rejects(readActionsJson(api(proof.originalBytes),'fixture/fixture','42','fixture-canonical',proof.canonicalMembers[0].name),/too large/);
 await assert.rejects(readFile(invoked),{code:'ENOENT'});
 assert.deepEqual(await readActionsJson(api(proof.canonicalBytes),'fixture/fixture','42','fixture-canonical',proof.canonicalMembers[0].name),proof.canonicalMembers[0].value);
 proof.reader='Original oversized ZIP rejected; all 27 canonical members read unchanged within existing limits';
 proof.transportControl='Original oversized metadata rejected before download; controlled gh transport reads unchanged canonical JSON';
 await writeFile(manifestPath,JSON.stringify(proof,null,2)+'\n');console.log(proof.reader);console.log(proof.transportControl);
} finally {process.env.PATH=prior;await rm(bin,{recursive:true,force:true});}
