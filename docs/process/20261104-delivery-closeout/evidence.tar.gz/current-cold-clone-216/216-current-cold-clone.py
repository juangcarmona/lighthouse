import subprocess, pathlib, json, hashlib, tempfile, os, datetime
root=pathlib.Path(tempfile.mkdtemp(prefix="lighthouse-216-registry-"))
log=pathlib.Path("/tmp/lighthouse-closeout/216-current-cold-clone.log")
receipt={"startedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"Current consumer configuration with published baseline packages; final tuple and native delivery remain pending","repository":"juangcarmona/lighthouse-published-consumer-20261104","clone":str(root),"checks":[]}
env=dict(os.environ);env["PATH"]="/opt/bastion-ai/releases/foundation-20261010/node-v24.21.0-linux-x64/bin:"+env["PATH"]
def run(args):
 with log.open("a") as f:
  f.write("\n$ "+" ".join(args)+"\n");f.flush()
  p=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 receipt["checks"].append({"command":args,"exitCode":p.returncode})
 if p.returncode: raise RuntimeError("Command failed: "+" ".join(args))
def capture(args):return subprocess.check_output(args,cwd=root,env=env,text=True).strip()
try:
 run(["git","-c","http.version=HTTP/1.1","clone","--depth","1","https://github.com/juangcarmona/lighthouse-published-consumer-20261104.git","."])
 receipt["revision"]=capture(["git","rev-parse","HEAD"])
 assert receipt["revision"]=="43df7fb50bdc05dc5af67ffb75845e846671524a"
 assert not (root/"node_modules").exists()
 receipt["noPreinstalledDependencies"]=True
 receipt["node"]=capture(["node","--version"])
 receipt["lockSha256"]=hashlib.sha256((root/"package-lock.json").read_bytes()).hexdigest()
 expected=json.loads(pathlib.Path("/tmp/lighthouse-closeout/216-native-preserved-files.json").read_text())
 for name,sha in expected.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
 receipt["preservedCustomizations"]=len(expected)
 run(["npm","ci","--ignore-scripts"])
 run(["npm","run","verify"])
 run(["npx","--no-install","lighthouse","verify"])
 run(["node","scripts/lighthouse-guard.mjs","verify"])
 receipt["trackedDiff"]=capture(["git","status","--porcelain"])
 assert not receipt["trackedDiff"]
 lock=json.loads((root/"package-lock.json").read_text())
 receipt["registryPackages"]={k:{f:v.get(f) for f in ("version","resolved","integrity")} for k,v in lock["packages"].items() if k.startswith("node_modules/@juangcarmona/")}
 receipt["status"]="passed"
except Exception as e:
 receipt["status"]="failed";receipt["error"]=str(e)
finally:
 receipt["completedAt"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
 pathlib.Path("/tmp/lighthouse-closeout/216-current-cold-clone.json").write_text(json.dumps(receipt,indent=2)+"\n")
 print(json.dumps(receipt,indent=2))
