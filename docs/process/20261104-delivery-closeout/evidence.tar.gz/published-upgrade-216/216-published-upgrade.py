import subprocess,pathlib,json,hashlib,tempfile,os,datetime,tarfile,io
origin=pathlib.Path('/srv/workspaces/juangcarmona/lighthouse/published-consumer-216');root=pathlib.Path(tempfile.mkdtemp(prefix='lighthouse-216-published-upgrade-'));out=pathlib.Path('/tmp/lighthouse-closeout');log=out/'216-published-upgrade.log';log.write_text('')
env=dict(os.environ);env['PATH']='/opt/bastion-ai/releases/foundation-20261010/node-v24.21.0-linux-x64/bin:'+env['PATH']
receipt={'scope':'Published baseline upgrade/rollback only; final published tuple and native delivery remain pending','root':str(root),'checks':[],'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def run(args,expected=0):
 p=subprocess.run(args,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 with log.open('a') as f:f.write('\n$ '+' '.join(args)+'\n'+p.stdout)
 receipt['checks'].append({'command':args,'exitCode':p.returncode});assert p.returncode==expected,p.stdout[-3500:];return p.stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def tracked():return {name:sha(root/name) for name in run(['git','ls-files','-z']).split('\0') if name}
def preserved():
 for name,digest in expected.items():assert sha(root/name)==digest,name
 assert run(['git','config','--get','core.hooksPath']).strip()=='.consumer-hooks'
def verify():
 run(['npm','run','verify']);run(['npx','--no-install','lighthouse','verify']);run(['node','scripts/lighthouse-guard.mjs','verify']);preserved()
def tuple_now():
 lock=json.loads((root/'package-lock.json').read_text());return {name:{key:lock['packages']['node_modules/@juangcarmona/'+name][key] for key in ('version','resolved','integrity')} for name in ('lighthouse','lighthouse-sdlc','lighthouse-ui')}
try:
 source_revision=subprocess.check_output(['git','-C',str(origin),'rev-parse','HEAD'],text=True).strip();receipt['customizationSourceRevision']=source_revision
 expected=json.loads((out/'216-native-preserved-files.json').read_text());manifest=json.loads((origin/'lighthouse.json').read_text());excluded=set(manifest['managed'])|{'lighthouse.json','package-lock.json'}
 archive=subprocess.check_output(['git','-C',str(origin),'archive',source_revision])
 with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
  for member in tar.getmembers():
   if not member.isfile() or member.name in excluded:continue
   path=root/member.name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(tar.extractfile(member).read());path.chmod(member.mode)
 pkg=json.loads((root/'package.json').read_text());pkg['dependencies']={};(root/'package.json').write_text(json.dumps(pkg,indent=2)+'\n')
 assert not (root/'node_modules').exists() and not (root/'src/packages').exists();receipt['noSourceCheckoutOrPreinstalledDependencies']=True
 run(['git','init','--template=','--initial-branch=main']);run(['git','config','core.hooksPath','.consumer-hooks'])
 run(['npm','install','--ignore-scripts','--save-exact','@juangcarmona/lighthouse@0.12.37'])
 run(['npx','--no-install','lighthouse','init','--name','Published upgrade qualification']);verify();receipt['sourceTuple']=tuple_now()
 run(['git','add','.']);run(['git','-c','user.name=Consumer qualification','-c','user.email=qualification@example.invalid','commit','-m','test: record published upgrade baseline']);baseline=run(['git','rev-parse','HEAD']).strip();receipt['baselineCommit']=baseline
 baseline_hashes=tracked();baseline_modes={name:(root/name).stat().st_mode&0o777 for name in expected}
 run(['npm','install','--ignore-scripts','--save-exact','@juangcarmona/lighthouse@0.12.38'])
 # Package selection is adopter-owned configuration; generated projections and ownership are updated only through the CLI.
 selected=json.loads((root/'lighthouse.json').read_text());selected['packages']['sdlc']['version']=tuple_now()['lighthouse-sdlc']['version'];(root/'lighthouse.json').write_text(json.dumps(selected,indent=2)+'\n')
 before=tracked();plan_text=run(['npx','--no-install','lighthouse','upgrade','--scope','all','--format','json']);plan=json.loads(plan_text);assert tracked()==before
 assert plan['source']['package']['version']=='0.12.37' and plan['target']['package']['version']=='0.12.38';(out/'216-published-upgrade-plan.json').write_text(plan_text)
 receipt['dryRunUnchanged']=True
 run(['npx','--no-install','lighthouse','upgrade','--scope','all','--apply']);verify();receipt['targetTuple']=tuple_now();receipt['customizationsPreserved']=len(expected)
 assert all((root/name).stat().st_mode&0o777==mode for name,mode in baseline_modes.items());receipt['customizationModesPreserved']=True
 # Existing installed-SDK ownership guard: preview only; no source checkout or workflow write occurs.
 stale=root/'.github/workflows/lighthouse-sdlc-router.yml';assert not stale.exists();stale.write_text('# consumer-owned stale workflow\nname: Preserve this workflow\n')
 sentinel=stale.read_bytes();guard_before=tracked();blocked=run(['node','node_modules/@juangcarmona/lighthouse-sdlc/src/install-workflows.mjs','.','458b454ece4e43f076ccdbdd7a37424334e85100'],1)
 assert 'Existing workflow differs' in blocked and stale.read_bytes()==sentinel and tracked()==guard_before;stale.unlink();receipt['baselineWorkflowOwnershipRefused']=True
 run(['git','add','.']);run(['git','-c','user.name=Consumer qualification','-c','user.email=qualification@example.invalid','commit','-m','test: record published upgrade result']);receipt['upgradeCommit']=run(['git','rev-parse','HEAD']).strip()
 assert str(root).startswith('/tmp/lighthouse-216-published-upgrade-')
 run(['git','reset','--hard',baseline]);run(['npm','ci','--ignore-scripts']);verify();assert tracked()==baseline_hashes and run(['git','status','--porcelain']).strip()==''
 receipt['rollbackTuple']=tuple_now();assert receipt['rollbackTuple']==receipt['sourceTuple'];receipt['rollbackMatchesBaseline']=True;receipt['status']='passed'
except Exception as error:receipt['status']='failed';receipt['error']=str(error)
finally:
 receipt['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'216-published-upgrade.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if receipt['status']!='passed':raise SystemExit(1)
