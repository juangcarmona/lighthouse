import assert from 'node:assert/strict';
import { mkdir, writeFile, readFile } from 'node:fs/promises';
const { chromium }=await import(process.cwd()+'/node_modules/@playwright/test/index.mjs');
const base='https://34762c08.lighthouse-6tc.pages.dev';
const output='docs/process/20261104-140-catalogue';
await mkdir(output+'/screenshots',{recursive:true});
const browser=await chromium.launch({headless:true});
const proof={base,renderedRevision:'cfb666a782d33d6e2fe18676722fa4d0dbd1483c',views:[],screenshots:[]};
const errors=[];
try{
 const page=await browser.newPage({viewport:{width:1440,height:1000}});page.on('pageerror',error=>errors.push(error.message));
 await page.goto(base+'/architecture/index.html#/section/06',{waitUntil:'networkidle'});
 await page.locator('#content a[href="#/section/06/worker-catalogue"]').first().click();
 await page.locator('#content').getByRole('heading',{name:'Worker catalogue',exact:true}).waitFor();
 for(const name of ['worker-catalogue','triage','refine','propose','implement','integrate','review','apply-review','product-change','apply-product-change','maintenance','unattended']){
  if(name!=='worker-catalogue'){
   await page.goto(base+'/architecture/index.html#/section/06/worker-catalogue',{waitUntil:'networkidle'});
   await page.locator(`#content a[href="#/section/06/${name}"]`).first().click();
  }
  const source=await readFile('docs/architecture/06-runtime-view/'+name+'.md','utf8');
  const title=source.match(/^# (.+)$/m)[1];
  await page.locator('#content').getByRole('heading',{name:title,exact:true}).waitFor();
  const frames=page.locator('#content iframe[data-native-frame]');
  const count=await frames.count();assert.ok(count>0,name);
  const accessible=[];
  for(let i=0;i<count;i++){
   await frames.nth(i).scrollIntoViewIfNeeded();
   await page.locator('#content iframe[data-native-frame][data-ready]').nth(i).waitFor();
   const title=await frames.nth(i).getAttribute('title');assert.ok(title,'missing iframe accessible title');accessible.push(title);
  }
  const graphs=page.frames().filter(frame=>frame.url()==='about:srcdoc');
  assert.ok(graphs.length>=count,'native graph did not mount: '+name);
  const text=(await Promise.all(graphs.map(frame=>frame.locator('body').innerText()))).join('\n');
  assert.ok(text.trim().length>0,'diagram has no readable native text: '+name);
  assert.doesNotMatch(text,/Syntax error in text|Parse error on line/);
  if(name==='integrate')for(const label of ['Merge exact accepted head','Retain original merge receipt','Publish report and issue/PR handoffs'])assert.ok(text.includes(label),label);
  const sourceFile=name==='worker-catalogue'?'lighthouse-sdlc-router.yml':name==='maintenance'?'lighthouse-worker-maintenance.yml':name==='unattended'?'lighthouse-sdlc-unattended.yml':`lighthouse-sdlc-${name}.md`;
  const sourceLinks=await page.locator('#content a').evaluateAll(nodes=>nodes.map(node=>node.href).filter(href=>href.includes('/src/packages/sdlc/')));
  assert.ok(sourceLinks.some(href=>href.includes('/blob/'+proof.renderedRevision+'/src/packages/sdlc/workflows/'+sourceFile)),'missing actual source anchor: '+name);
  if(name==='worker-catalogue')assert.ok(sourceLinks.some(href=>href.endsWith('/src/packages/sdlc/README.md')),'guide link missing');
  proof.views.push({name,title,diagrams:count,accessibleTitles:accessible,nativeText:true,sourceLinks});
  console.log('Rendered navigation verified:',name,count);
 }
 assert.deepEqual(errors,[]);
 await page.goto(base+'/architecture/index.html#/section/06/worker-catalogue',{waitUntil:'networkidle'});
 await page.locator('#content iframe[data-native-frame][data-ready]').waitFor();
 await page.screenshot({path:output+'/screenshots/catalogue-desktop.png',fullPage:false});proof.screenshots.push('catalogue-desktop.png');
 const open=await page.locator('#content a.native-open').first().getAttribute('href');assert.equal((await page.request.get(open)).status(),200);
 await page.goto(base+'/architecture/index.html#/section/06/integrate',{waitUntil:'networkidle'});
 await page.locator('#content iframe[data-native-frame][data-ready]').waitFor();
 const diagram=await page.locator('#content a.native-open').first().getAttribute('href');
 await page.goto(diagram,{waitUntil:'networkidle'});
 const graph=page.frames().find(frame=>frame.url()==='about:srcdoc');assert.ok(graph);
 const controls=await graph.locator('[data-view]').evaluateAll(nodes=>nodes.map(node=>({view:node.getAttribute('data-view'),aria:node.getAttribute('aria-label')})));
 proof.diagramControls=controls;
 const zoom=controls.find(control=>['in','zoom-in'].includes(control.view));
 if(zoom){await graph.locator(`[data-view="${zoom.view}"]`).click();await graph.locator(`[data-view="${zoom.view}"]`).click();}
 await page.screenshot({path:output+'/screenshots/integration-expanded.png',fullPage:false});proof.screenshots.push('integration-expanded.png');
 const mobile=await browser.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});mobile.on('pageerror',error=>errors.push(error.message));
 await mobile.goto(base+'/architecture/index.html#/section/06/worker-catalogue',{waitUntil:'networkidle'});
 await mobile.locator('#content iframe[data-native-frame][data-ready]').waitFor();
 await mobile.locator('#content a[href="#/section/06/maintenance"]').first().click();
 await mobile.locator('#content').getByRole('heading',{name:'Maintenance and worker reports',exact:true}).waitFor();
 await mobile.locator('#content iframe[data-native-frame][data-ready]').first().waitFor();
 await mobile.screenshot({path:output+'/screenshots/maintenance-mobile.png',fullPage:false});proof.screenshots.push('maintenance-mobile.png');
 proof.mobile={width:390,navigation:true};
 assert.deepEqual(errors,[]);proof.pageErrors=errors;
 await writeFile('/tmp/140-browser-proof.json',JSON.stringify(proof,null,2)+'\n');
 console.log(JSON.stringify({pages:proof.views.length,diagrams:proof.views.reduce((n,row)=>n+row.diagrams,0),mobile:true,errors}));
}finally{await browser.close();}
