from pathlib import Path
import json,subprocess,hashlib,tempfile,os,shutil,datetime
D=Path('/tmp/lighthouse-closeout');root=Path('/srv/workspaces/juangcarmona/lighthouse/consumer-registry-0213');proof=D/'216-registry-0213-sync-policy-qualified.json';assert not proof.exists(),'Reconcile existing policy proof';assert json.loads((D/'216-registry-0213-upgrade-qualified.json').read_text())['state']=='verified-ready-for-review'
head='ceeea3c20a5b49991f82a094d1f166c7c81074d3';subprocess.check_call(['git','fetch','origin',head],cwd=root)
excluded=sorted(f['path'] for f in json.loads((D/'516-live-readonly-plan.json').read_text())['result']['files']);assert len(excluded)==29 and '.lighthouse/implement.json' in excluded
program="const f=require('node:fs'),c=require('node:crypto'),x=new Set(process.argv.slice(2).flatMap(JSON.parse));let a=[];function w(d=''){for(const n of f.readdirSync(d||'.').sort()){let p=d+n;if(x.has(p)||/^(node_modules|\\.git)(\\/|$)|^\\.product\\/(cache|generated)(\\/|$)/.test(p))continue;let s=f.lstatSync(p);if(s.isDirectory())w(p+'/');else a.push([p,!!(s.mode&73),c.createHash('sha256').update(f.readFileSync(p)).digest('hex')]);}}w();let h=c.createHash('sha256').update(JSON.stringify(a)).digest('hex');if(process.argv[1]){if(h!==process.argv[1])throw Error('Admitted application, tests, product, plans or customizations changed')}else console.log(h);"
assert len(program)<=1000
chunks=[];chunk=[]
for path in excluded:
 if len(json.dumps(chunk+[path],separators=(',',':')))>950:chunks.append(json.dumps(chunk,separators=(',',':')));chunk=[]
 chunk.append(path)
if chunk:chunks.append(json.dumps(chunk,separators=(',',':')))
entries=[];payload={}
for entry in subprocess.check_output(['git','ls-tree','-rz','--full-tree',head],cwd=root).split(b'\0'):
 if not entry:continue
 meta,path=entry.split(b'\t',1);mode,kind,sha=meta.decode().split();path=path.decode();assert kind=='blob' and mode in ['100644','100755']
 payload[path]=(mode,subprocess.check_output(['git','cat-file','blob',sha],cwd=root))
 if path not in excluded and not path.startswith(('.product/cache/','.product/generated/')):entries.append([path,mode=='100755',hashlib.sha256(payload[path][1]).hexdigest()])
entries.sort(key=lambda row:row[0].split('/'));expected=hashlib.sha256(json.dumps(entries,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
p=root/'.lighthouse/implement.json';before=p.read_bytes();policy=json.loads(before);original_paths=policy['12']['verification']['paths'];assert len(original_paths)==20
policy['12']['scope']='Verification-only correction of the existing product-backed PR #16. Preserve all application, tests, accepted product intent, OpenSpec plans and adopter customizations. The trusted host may include only authenticated nonconflicting changes from the owner-admitted default branch before execution, then publish the independently checked tree with source and base as parents. No model file changes, new ProductShape apply, new PR or merge are authorized during this correction. All verification inputs remain frozen after trusted preparation; approval of the resulting exact head is separate.'
policy['12']['paths']=['src/'];policy['12']['verification']['synchronizeBase']=True;policy['12']['verification']['corrections']={};policy['12']['checks'][4]=['node','-e',program,expected,*chunks];assert policy['12']['verification']['paths']==original_paths
assert all(len(arg)<=1000 for check in policy['12']['checks'] for arg in check)
p.write_text(json.dumps(policy,indent=2)+'\n')
node='/opt/bastion-ai/releases/foundation-20261010/node-v24.21.0-linux-x64/bin/node'
subprocess.check_call([node,'scripts/verify-delivery-profile.mjs'],cwd=root)
with tempfile.TemporaryDirectory(prefix='lighthouse-sync-policy-') as tmp:
 candidate=Path(tmp)
 for path,(mode,content) in payload.items():
  if path in excluded:
   file=root/path
   if not file.exists():continue
   content=file.read_bytes();mode='100755' if file.stat().st_mode&0o111 else '100644'
  file=candidate/path;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(content);file.chmod(0o755 if mode=='100755' else 0o644)
 command=policy['12']['checks'][4];run=subprocess.run([node,*command[1:]],cwd=candidate,text=True,capture_output=True);assert run.returncode==0,run.stderr
 negative=[]
 for path in ['src/summary.mjs','src/summary.test.mjs','docs/product/model/requirements/FR-SUMMARY-001.md','tools/existing-tool.mjs']:
  if path not in payload:
   if path.startswith('docs/product'):path=next(p for p in payload if p.startswith('docs/product/model/') and p.endswith('.md'))
   else:raise AssertionError(path)
  file=candidate/path;original=file.read_bytes();file.write_bytes(original+b'\nunauthorized alteration\n');r=subprocess.run([node,*command[1:]],cwd=candidate,text=True,capture_output=True);assert r.returncode!=0;file.write_bytes(original);negative.append(path)
 # A managed input is excluded only from the durable domain guard; model edits still fail the frozen input check.
 script="import {sourceFiles} from './node_modules/@juangcarmona/lighthouse-sdlc/src/implementation.mjs';import {verificationIntegrity} from './node_modules/@juangcarmona/lighthouse-sdlc/src/verification-integrity.mjs';import {readFileSync} from 'node:fs';const p=JSON.parse(readFileSync('.lighthouse/implement.json'))['12'];const before=await sourceFiles(process.argv[1]);for(const path of ['.lighthouse/implement.json','.github/workflows/ci.yml','scripts/verify-delivery-profile.mjs']){const after=new Map(before);after.set(path,{...after.get(path),content:Buffer.from('tamper')});let denied=false;try{verificationIntegrity(before,after,p,12)}catch{denied=true}if(!denied)throw Error('Model verification input accepted: '+path)}console.log('three managed-input tampering cases rejected');"
 subprocess.check_call([node,'--input-type=module','-e',script,str(candidate)],cwd=root)
result={'state':'verified-ready-for-review','originalHead':head,'domainHash':expected,'domainFiles':len(entries),'basePathsExcludedOnlyFromDomainGuard':excluded,'verificationPathsUnchanged':original_paths,'modelChangesAuthorized':False,'negativeDomainCasesRejected':negative,'negativeManagedInputCasesRejected':3,'beforePolicySha256':hashlib.sha256(before).hexdigest(),'afterPolicySha256':hashlib.sha256(p.read_bytes()).hexdigest(),'checks':policy['12']['checks'],'verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};proof.write_text(json.dumps(result,indent=2)+'\n');(D/'216-registry-0213-sync-policy-before.json').write_bytes(before);print(json.dumps({k:v for k,v in result.items() if k not in ['checks','verificationPathsUnchanged','basePathsExcludedOnlyFromDomainGuard']}))
