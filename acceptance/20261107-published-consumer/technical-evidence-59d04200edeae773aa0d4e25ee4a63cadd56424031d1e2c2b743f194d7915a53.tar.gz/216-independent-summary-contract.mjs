import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
const module = await import(pathToFileURL(process.argv[2]).href);
assert.deepEqual(Object.keys(module), ['summarize']);
const cases = [['passed', 'passed'], ['failed', 'failed'], ['unknown', 'unavailable'], ['PASSED', 'unavailable'], ['', 'unavailable'], [null, 'unavailable'], [0, 'unavailable'], [false, 'unavailable'], [undefined, 'unavailable']];
for (let count = 0; count <= 64; count++) {
  const expected = { total: count, passed: 0, failed: 0, unavailable: 0 };
  const records = Array.from({ length: count }, (_, index) => {
    const [status, bucket] = cases[(count + index) % cases.length]; expected[bucket]++;
    return Object.freeze(status === undefined ? { id: index } : { id: index, status });
  });
  const input = Object.freeze(records), before = JSON.stringify(input), identities = [...input];
  const actual = module.summarize(input); assert.deepEqual(actual, expected);
  assert.deepEqual(module.summarize(input), expected); assert.notEqual(actual, module.summarize(input));
  assert.equal(JSON.stringify(input), before); input.forEach((record, index) => assert.equal(record, identities[index]));
}
console.log('65 frozen-input contract cases passed; exact export/result shape, strict status categories, original identities/order/contents and fresh result objects');
