import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { readImplementationEvidence } from '/srv/workspaces/juangcarmona/lighthouse/consumer-registry-0213/node_modules/@juangcarmona/lighthouse-sdlc/src/implementation-evidence.mjs';
const context=JSON.parse(readFileSync('/tmp/lighthouse-closeout/216-native-0213-receipt-reader-context.json'));
const calls=[];
const api=async(path,method='GET',body,optional=false)=>{
 assert.equal(method,'GET');assert.equal(body,undefined);calls.push({method,path});
 try{return JSON.parse(execFileSync('gh',['api','repos/juangcarmona/lighthouse-published-consumer-20261104/'+path],{encoding:'utf8',stdio:['ignore','pipe','pipe'],maxBuffer:8*1024*1024,timeout:40000}));}
 catch(error){if(optional&&String(error.stderr).includes('HTTP 404'))return null;throw error;}
};
const evidence=await readImplementationEvidence(api,context);
const record={at:new Date().toISOString(),sdk:'0.20.13',context,evidence,calls,effects:[]};
writeFileSync('/tmp/lighthouse-closeout/216-native-0213-authenticated-receipts-qualified.json',JSON.stringify(record,null,2)+'\n');
assert.equal(evidence.status,'passed',evidence.reason);assert.equal(evidence.checks.length,9);assert.ok(evidence.checks.every(c=>c.status==='passed'));
console.log(JSON.stringify({status:evidence.status,checks:evidence.checks.length,reads:calls.length,effects:0}));
