# Integrate and review in GitHub Actions

The optional completion adapter finishes an implementation through the adopter's repository workflows. OpenCode assesses the delivery in its existing isolated runner; a separate hosted publisher verifies GitHub state, performs an explicitly authorized merge and retains the report. SoFa is not required.

## Adoption

Follow the [packaged workflow installation and update procedure](README.md#install-or-update-workflows) with `--with-completion`. This includes triage, refine, propose, implement and corrections; it adds no new lifecycle stage.

In the existing `.lighthouse/github.json`, retain the adopted required checks and protected `evidenceBranch`, and add:

```json
{
  "completion": {
    "publishEvidence": true,
    "postMergeWorkflows": ["verify.yml"]
  }
}
```

Use real workflow filenames. Each must support `workflow_dispatch` for post-merge verification and verify its checked-out revision. Candidate CI can use the [optional App verification push](github-actions.md#eligible-ci-for-bot-delivery). Legacy candidate dispatch remains execution evidence; GitHub excludes its job checks from required PR rules. Post-merge runs count only when GitHub reports the actual merged SHA, default branch, permitted event and successful completion. Pending, missing and failed results remain distinct from success. A changed default tip stops dispatch rather than checking unrelated code.

The evidence branch must already exist separately from the application tree. Active repository rulesets must prevent deletion and non-fast-forward updates with no bypass actors. Completion verifies these rules before publication; it does not create or weaken them. `publishEvidence` opts into publishing the bounded report and receipt to the repository's audience. It does not authorize copying raw sessions or every implementation artifact.

GitHub hides `bypass_actors` from tokens that cannot edit rulesets. Before activation, run the read-only `node src/packages/sdlc/src/observe-protection.mjs <owner/repository> <evidence-branch>` command with the owner's existing GitHub CLI authentication. Add its array as `completion.protectionObservations` in the reviewed profile. No credential is stored. The observer requires visible empty bypass lists and stable provider timestamps. Actions compares the retained ruleset revision digest with live public metadata, including `updated_at`, conditions and rules; any change invalidates the observation. Reobserve after a deliberate protection change. If bypass actors are visible at runtime, a non-empty list always fails even when an old observation exists. Classic branch protection still requires access to its protection endpoint; the adapter fails closed when that policy cannot be read.

## Owner entry

Approve the implementation PR in GitHub when it is ready. A complete candidate starts as a draft, and passing required CI marks it ready. Manual draft changes are reflected on the issue; marking an incomplete or unchecked PR ready returns it to draft with a blocker. The router checks that approval belongs to the owner and the current commit, then assesses integration. If CI is still running, its completion resumes the check. Comments request changes on the same PR; they do not authorize merge.

Adding `integrate` to the issue requests an assessment of its single eligible bot implementation PR. The router requires a current complete implementation receipt, a non-draft PR, the owner's current-head approval and passing required checks. It reports missing prerequisites on the issue instead of silently skipping. The dispatch binds the resolved PR, head, implementation identity and approval; admission and publication recheck them. A completed assessment consumes the request label. Reservations remain separate and block admission. The label always uses `merge: false`; it never grants merge permission.

Manual `integrate` and `review` dispatches remain available for recovery. They require the issue, PR and accepted head SHA; integration needs `merge: true` to authorize a merge.

Integration binds the current work-item title/body and owner answers, PR content and changed paths, base revision, adopted policy and review state. The host rechecks them before publishing or merging. Changed inputs require a fresh assessment; a new commit needs a new approval. Required checks come from effective GitHub rules and classic branch protection; the adopted checks must still be enforced. Unrelated maintenance failures are not silently promoted to required checks. Additional CI observations exclude check identities belonging to the current workflow run, obtained from GitHub job metadata, so review cannot wait for itself to finish; required-check enforcement remains unchanged. GitHub remains responsible for review and merge protection. This adapter supports same-repository PRs and squash integration; merge queues and stacked merges need their own adapter.

The merge request includes the accepted head SHA. GitHub's REST merge operation has no expected-base argument: the adapter rechecks base immediately beforehand, while GitHub enforces current branch rules at merge time. The receipt records the actual merged revision, and post-merge verification checks that revision. It never claims the earlier test-merge revision is the final commit.

After integration, successful post-merge CI starts `review`. The host supplies matching integration evidence from the protected process branch: a commit-pinned report, hash-verified artifacts and receipt, accepted delivery identity, owner merge authorization and the successful originating workflow. Review rechecks that pinned evidence before publication; missing or stale history is explicit. The current review report remains a subsequent host effect. Review records the retrospective, affected-instruction findings and proposed improvements. A passed review closes the work item and removes the delivery labels; a blocker keeps it awaiting review. The router follows the adopted workflow; neither stage changes policy.

Integration handoffs state the confirmed merge SHA and observed post-merge CI separately from the agent assessment made before publication. New reports label that historical assessment; existing immutable bundles retain their original bytes.

A confirmed integration also retains a pending-review hint on the issue. The existing PR reconciler retries the original CI signal when integration or adopted CI completes, with its five-minute schedule as a fallback, including when CI finished first or the initial PR lookup was unavailable. Each retry rechecks the accepted head, current authority, protected evidence and all adopted post-merge checks. The router reuses the original CI dispatch receipt; an unconfirmed worker dispatch remains uncertain. Owner holds stop continuation. The original bot CI callback also makes at most 60 waits of up to five seconds for its retained integration to become terminal; it then rechecks the full grant. This covers missing completion events without another review signal. The scan is bounded to 1,000 open issues and their bounded comment histories; exceeding a bound fails visibly.

## Host command evidence

Implementation and same-PR corrections retain `lighthouse-command-evidence-<issue>-<attempt>` for 30 days. The publisher binds each receipt to its repository, issue, admitted intent, native run and attempt, source and admitted policy revisions, implementation policy, planning reference and exact tested/published Git tree. Each command retains argv, exit status, execution outcome and bounded redacted output with hashes. A complete JSON log also supplies its bounded summary and original document/citation rows for changed files and the issue plan, with diagnostics. Commands buffer output inside the disposable container before host capture to preserve provider output across abrupt exits; capture limits and excerpt limits are recorded separately. Output truncation is explicit; omitted text cannot establish provider details. Reuse also requires the originating authorization artifacts to remain available.

Implementation publishers use a named transition that retains the original head and grant separately from the confirmed PR head, checked tree and base. The new head becomes available to CI guards only after exact GitHub publication is observed; summary-only corrections use the same result without writing source. The legacy positional publication entrypoint remains compatible.

Integration supplies verified commands in `completion.implementationEvidence` and `observedChecks`. The reader authenticates the successful adopted workflow and its dispatch origin through GitHub, compares current inputs and rechecks cited receipts before publication or merge. A producer string, valid JSON or generic green CI does not authenticate a command. The packaged `implementation-evidence` export requires a host-authenticated API; a shape validator is not a trust boundary.

| Change or observation | Current acceptance |
| --- | --- |
| Same head/tree, intent, policy, plan, workflow and retained output; unrelated main commits | Reuse the scoped command result |
| Candidate or in-tree plan changes; criteria/owner answers, applicable policy, external plan, workflow or shared authority/validation inputs change | Revalidate; historical evidence stays readable |
| Wrong repository, producer/run/attempt, argv, publication or output digest | Unavailable evidence with a reason |
| Missing, expired, inaccessible or oversized artifact; legacy receipt without these bindings | Unavailable evidence; request an authorized same-PR revalidation |
| Executed command fails | Failed result |
| Command was not executed or its result is missing | Unavailable result |

ProductShape configuration, its configured accepted model and templates, shared OpenSpec configuration/schemas/specifications and Markdown policy are checked against the admitted baseline or the already-tested candidate after merge. An unrelated baseline commit can reuse evidence; changes to those shared inputs require revalidation. The current check policy declares one candidate-wide input scope. Changes within that tree or its shared policy invalidate the group; unrelated main commits do not. These observations supplement explicit work-item verification; they do not add forge merge gates or establish that the tests are strong enough. Existing stage-result v1 payloads remain unchanged. Legacy/unattended receipts without this command handoff retain their existing consumers and cannot be promoted to authenticated command evidence by this reader. Independent test integrity and review remain #101.

## Evidence and recovery

Actions shows authorization, OpenCode progress, validation, publication and cleanup as separate jobs or steps. The issue and PR receive a report link pinned to the confirmed evidence commit. The report records accepted source, actual integration outcome, GitHub check identities and retrospective. Reports and receipts use the existing evidence record/index formats under `docs/process/YYYYMMDD-issue-slug/runs/run/attempt-NNNN/`; dates use UTC. An existing work-item folder is reused after a rename.

Publication preserves previous bundles and unrelated files, rejects path escapes, links, credential-shaped payloads and excessive content, and updates the branch without force. Concurrent updates are rebased through a bounded retry. Identical bundle retries return the existing receipt; different content at the same identity is a conflict. This is a bounded pattern check, not a claim that arbitrary private content is safe to publish.

For an authenticated unattended fast-forward integration, review can reconstruct the original planning-review binding from the retained run artifact and its proposal, refinement, policy and reviewer result. When these match, the host includes the verified record in review context and retains `planning-review.json` with the report. Configured model names do not prove provider-reported settings. Missing, expired or unverifiable artifacts remain unavailable rather than passing silently.

A merge receipt is uploaded even if later dispatch or publication fails. An uncertain merge response is reconciled against GitHub before any further mutation. A fresh invocation on an already merged PR records the observed merge instead of repeating it. Artifact retention is 30 days; confirmed process-branch reports remain available under the adopter's retention policy. Earlier screenshots stay in their existing evidence location; this slice does not automatically migrate all binary artifacts to permanent storage.

## Related work

This adapter implements #105 completion and #100 command provenance for the supported implementation/correction producers. Independent test integrity and review (#101), process guards (#102), autonomy policy (#103) and continuity (#104) retain their own scope. The common evidence validator does not authenticate arbitrary producer claims.

Provider behavior: [merge a pull request](https://docs.github.com/en/rest/pulls/pulls#merge-a-pull-request), [required status checks](https://docs.github.com/en/pull-requests/how-tos/merge-and-close-pull-requests/troubleshooting-required-status-checks), and [triggering workflows from workflows](https://docs.github.com/en/actions/how-tos/writing-workflows/choosing-when-your-workflow-runs/triggering-a-workflow).
