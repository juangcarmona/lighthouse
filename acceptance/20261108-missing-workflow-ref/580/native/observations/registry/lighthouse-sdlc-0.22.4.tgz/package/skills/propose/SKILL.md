---
name: lighthouse-sdlc-propose
description: Use when a ready work item needs a solution proposal, OpenSpec change artifacts, test impact and a human-readable change overview.
---

# Propose

Describe the smallest implementable solution for a Ready item.

## Steps

1. Read the Ready evidence and inspect the current product and architecture authorities.
2. Create or update the OpenSpec change artifacts through the installed OpenSpec workflow. Always return `proposal.md`, `design.md` and `tasks.md`, including for documentation-only changes. For a change without spec-level behavior, return `.openspec.yaml` containing exactly `skip_specs: true` instead of a specification; the host adds it to provider-owned metadata.
3. Describe the solution, interfaces, data effects, test impact, slices, risks and Definition of Done.
4. Write a concise change overview preserving facts, links, commands, frontmatter and code. Use Humanizer when installed; otherwise review the prose directly for unsupported claims, repetition and unclear decisions, and record that method in the result output. A missing optional prose helper does not block an otherwise complete proposal.
5. Return a stage result with `stage: propose`, `gate: planned`, the change artifacts as output, evidence entries and separate `missingEvidence`, `unavailableChecks` and `pendingReview` arrays.

## Completion

The change artifacts explain the future state, the slices are dependency ordered, the evidence plan is explicit and the `planned` decision remains visible.
