import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readActionsJson } from './actions-artifact.mjs';
import { issueComments, readDispatchReceipt } from './stage-dispatch.mjs';
import { epicJournalKey } from './epic-github.mjs';
import { authenticateEpicChild } from './epic-native.mjs';
import { observeEpicRefinement } from './epic-refinement.mjs';
import { isDeepStrictEqual } from 'node:util';

const positive = value => /^[1-9][0-9]*$/.test(String(value));
export async function verifyEpicRefinementOrigin(api, { repository, owner, child, parent, runId }, { readArtifact = readActionsJson, observe = observeEpicRefinement } = {}) {
  if (![child, parent, runId].every(positive)) throw Error('Invalid epic refinement origin');
  const run = await api(`actions/runs/${runId}`), repo = await api('');
  if (String(run.id) !== String(runId) || run.path !== '.github/workflows/lighthouse-sdlc-epic.yml' || run.event !== 'workflow_dispatch' || run.status !== 'completed' || run.conclusion !== 'success' || run.run_attempt !== 1 || run.actor?.login !== owner || run.triggering_actor?.login !== owner || run.repository?.full_name !== repository || !/^[a-f0-9]{40}$/.test(run.head_sha ?? '') || typeof run.head_branch !== 'string' || !run.head_branch) throw Error('Epic refinement origin is not an authenticated current owner execution');
  const artifact = await readArtifact(api, repository, run.id, `lighthouse-epic-refinement-${parent}-${child}-1`, 'refinement.json');
  const current = await observe({ api, repository, owner, child: Number(child), allowWorking: true, readArtifact });
  const revision = (await api(`commits/${encodeURIComponent(repo.default_branch)}`)).sha;
  const expected = { schemaVersion: 1, repository, parent: Number(parent), runId: String(run.id), attempt: 1, revision, observation: current };
  if (current.epic.parent !== Number(parent) || current.epic.sourceRevision !== revision || !isDeepStrictEqual(artifact, expected)) throw Error('Epic refinement authorization or triage changed');
  return { run, current };
}

export async function dispatchEpicRefinement(api, { repository, owner, runId, parent, child }, options = {}) {
  const verified = await verifyEpicRefinementOrigin(api, { repository, owner, child, parent, runId }, options);
  const issue = await api(`issues/${child}`);
  if (issue.state !== 'open' || issue.labels.some(label => ['future', 'human-working', 'agent-working', 'needs-info', 'waiting-review', 'execution-failed'].includes(label.name))) return { status: 'paused', parent, child };
  await api('actions/workflows/lighthouse-sdlc-router.yml/dispatches', 'POST', { ref: verified.run.head_branch, inputs: { issue: String(child), stage: 'refine', workflow: 'stage', epic_parent: String(parent), epic_run: String(runId) } });
  return { status: 'dispatched', parent, child };
}
export async function verifyEpicTriageOrigin(api, { repository, owner, child, parent, runId }, { readArtifact = readActionsJson, authenticate = authenticateEpicChild } = {}) {
  if (![child, parent, runId].every(positive)) throw Error('Invalid epic triage origin');
  const run = await api(`actions/runs/${runId}`), repo = await api('');
  if (String(run.id) !== String(runId) || run.path !== '.github/workflows/lighthouse-sdlc-epic.yml' || run.event !== 'workflow_dispatch' || run.status !== 'completed' || run.conclusion !== 'success' || run.run_attempt !== 1 || run.actor?.login !== owner || run.triggering_actor?.login !== owner || run.repository?.full_name !== repository || !/^[a-f0-9]{40}$/.test(run.head_sha ?? '') || typeof run.head_branch !== 'string' || !run.head_branch) throw Error('Epic triage origin is not an authenticated current owner execution');
  const journal = await readArtifact(api, repository, run.id, `lighthouse-epic-journal-${parent}-${run.run_attempt}`, 'journal.json');
  if (journal?.schemaVersion !== 1 || journal.repository !== repository || journal.parent !== Number(parent) || journal.revision !== (await api(`commits/${encodeURIComponent(repo.default_branch)}`)).sha || (journal.workflowRevision !== undefined) !== (journal.workflowRef !== undefined) || (journal.workflowRevision ?? journal.revision) !== run.head_sha || (journal.workflowRef ?? repo.default_branch) !== run.head_branch || String(journal.runId) !== String(run.id) || journal.attempt !== run.run_attempt || !journal.entries || typeof journal.entries !== 'object') throw Error('Epic triage journal is invalid');
  const current = await authenticate({ api, repository, owner, child: Number(child), readArtifact });
  if (current.parent !== Number(parent)) throw Error('Epic triage parent changed');
  const matches = Object.values(journal.entries).filter(entry => entry?.receipt?.state === 'linked' && entry.receipt.correlation?.kind === 'child' && entry.receipt.correlation.parent === Number(parent) && entry.receipt.correlation.slice === current.slice && entry.receipt.correlation.planDigest === current.planDigest && entry.receipt.resource?.number === Number(child));
  if (matches.length !== 1 || journal.entries[epicJournalKey(matches[0].receipt.correlation)] !== matches[0]) throw Error('Epic triage is not in the retained parent execution');
  return { run, journal, current };
}

export async function dispatchEpicTriage(api, { repository, owner, runId }, { readArtifact = readActionsJson, authenticate = authenticateEpicChild, observe = observeEpicRefinement } = {}) {
  if (!positive(runId)) throw Error('Invalid epic execution');
  const run = await api(`actions/runs/${runId}`), inventory = await api(`actions/runs/${runId}/artifacts?per_page=100`);
  if (!Array.isArray(inventory.artifacts) || inventory.total_count !== inventory.artifacts.length || inventory.total_count > 100) throw Error('Epic artifact inventory is incomplete');
  const actions = inventory.artifacts.filter(item => /^lighthouse-epic-(?:action|recovery)-[1-9][0-9]*-1$/.test(item.name));
  if (actions.some(item => item.expired) || actions.filter(item => item.name.startsWith('lighthouse-epic-action-')).length > 1 || actions.filter(item => item.name.startsWith('lighthouse-epic-recovery-')).length > 1) throw Error('Epic action evidence is expired or ambiguous');
  const action = actions.find(item => item.name.startsWith('lighthouse-epic-action-')) ?? actions[0];
  if (action) {
    const recovery = action.name.startsWith('lighthouse-epic-recovery-');
    const parent = Number(action.name.match(/-([1-9][0-9]*)-1$/)[1]);
    const record = await readArtifact(api, repository, runId, action.name, recovery ? 'recovery.json' : 'result.json');
    if (run.path !== '.github/workflows/lighthouse-sdlc-epic.yml' || run.event !== 'workflow_dispatch' || run.status !== 'completed' || run.conclusion !== 'success' || run.run_attempt !== 1 || run.actor?.login !== owner || run.triggering_actor?.login !== owner || run.repository?.full_name !== repository || record?.schemaVersion !== 1 || record.repository !== repository || record.workflowRevision !== run.head_sha || (recovery ? record.recoveryRun !== String(run.id) || record.kind !== 'partial-publication-recovery' || record.state !== 'confirmed' || record.status !== 'reconciled' : record.runId !== String(run.id) || record.attempt !== 1 || record.parent !== parent || record.workflowRef !== run.head_branch || !['authorized', 'reconciled', 'linked', 'ready', 'accepted', 'published'].includes(record.result?.status) || !['reconcile', 'refine-child', 'register-pr', 'recover-publication', 'ready-child', 'accept-child', 'publish-aggregate', 'ready-aggregate', 'accept-aggregate'].includes(record.action))) throw Error('Epic action origin is not authenticated');
    if (recovery || !['reconcile', 'refine-child'].includes(record.action)) return { status: 'settled', parent, children: [] };
  }
  const names = inventory.artifacts.filter(item => !item.expired).map(item => item.name).filter(name => /^lighthouse-epic-journal-[1-9][0-9]*-1$/.test(name));
  const refinementArtifacts = inventory.artifacts.filter(item => /^lighthouse-epic-refinement-[1-9][0-9]*-[1-9][0-9]*-1$/.test(item.name));
  if (refinementArtifacts.some(item => item.expired)) throw Error('Epic refinement authorization expired');
  const refinements = refinementArtifacts.map(item => item.name);
  if (refinements.length > 1) throw Error('Epic refinement authorization is ambiguous');
  if (refinements.length === 1) {
    const [, parent, child] = refinements[0].match(/^lighthouse-epic-refinement-([1-9][0-9]*)-([1-9][0-9]*)-1$/);
    return dispatchEpicRefinement(api, { repository, owner, runId, parent: Number(parent), child: Number(child) }, { readArtifact, observe });
  }
  if (names.length !== 1) throw Error('Epic execution journal is missing or ambiguous');
  const parent = Number(names[0].match(/^lighthouse-epic-journal-([1-9][0-9]*)-1$/)[1]);
  const journal = await readArtifact(api, repository, runId, names[0], 'journal.json');
  const entries = Object.values(journal?.entries ?? {}).filter(entry => entry?.receipt?.state === 'linked' && entry.receipt.correlation?.kind === 'child');
  const sent = [];
  for (const entry of entries) {
    const child = entry.receipt.resource?.number;
    const verified = await verifyEpicTriageOrigin(api, { repository, owner, child, parent, runId }, { readArtifact, authenticate });
    const issue = await api(`issues/${child}`);
    if (issue.state !== 'open' || issue.labels.some(label => ['future', 'human-working', 'agent-working', 'needs-info', 'waiting-review', 'triaged', 'ready'].includes(label.name))) continue;
    const comments = await issueComments(api, child);
    const prior = comments.filter(comment => comment.user?.login === 'github-actions[bot]' && comment.user.type === 'Bot' && comment.body?.includes('<!-- lighthouse-dispatch:')).map(comment => readDispatchReceipt(comment, repository, child));
    if (prior.some(receipt => receipt.stage === 'triage')) continue;
    await api('actions/workflows/lighthouse-sdlc-router.yml/dispatches', 'POST', { ref: verified.run.head_branch, inputs: { issue: String(child), stage: 'triage', workflow: 'stage', epic_parent: String(parent), epic_run: String(runId) } });
    sent.push(child);
  }
  return { status: 'dispatched', parent, children: sent };
}

async function main() {
  const env = process.env, repository = env.GITHUB_REPOSITORY, owner = env.GITHUB_REPOSITORY_OWNER;
  const event = JSON.parse(await readFile(env.GITHUB_EVENT_PATH, 'utf8'));
  if (env.GITHUB_EVENT_NAME !== 'workflow_run' || event.action !== 'completed' || !positive(event.workflow_run?.id)) throw Error('Epic triage requires a completed workflow event');
  const api = async (path, method = 'GET', body, optional = false) => {
    const response = await fetch(`https://api.github.com/repos/${repository}${path ? `/${path}` : ''}`, { method, headers: { authorization: `Bearer ${env.GH_TOKEN}`, accept: 'application/vnd.github+json', 'content-type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(30000) });
    if (optional && response.status === 404) return null;
    if (!response.ok) throw Error(`GitHub ${method} ${path}: ${response.status}`);
    return response.status === 204 ? null : response.json();
  };
  console.log(JSON.stringify(await dispatchEpicTriage(api, { repository, owner, runId: event.workflow_run.id })));
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main().catch(error => { console.error(error.message); process.exitCode = 1; });
