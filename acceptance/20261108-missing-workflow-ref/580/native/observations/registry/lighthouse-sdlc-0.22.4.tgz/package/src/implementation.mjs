import { sourceLinksDigest } from './source-link-tree.mjs';
import { readFile, writeFile, mkdir, readdir, lstat, readlink, mkdtemp, rm } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { tmpdir } from 'node:os';
import { spawnSync, execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { setTimeout } from 'node:timers/promises';
import { proposalRoot, changeName } from './proposal-files.mjs';
import { validateEnvironment } from './execution-environment.mjs';
import { checkProductResumePullRequest, productImplementationProof, productModelDirectoryFromConfig } from './product-change.mjs';
import { checkAlignedImplementationPullRequest, checkReviewCurrent } from './proposal-review.mjs';
import { observeUpdatedProductPull } from './product-change-actions.mjs';
import { prepareSourceSynchronization, synchronizationDigest } from './source-sync.mjs';
import { needsVerificationRefresh, observeVerificationMerge } from './ci-subject.mjs';
import { selectPublicationBranch } from './publication-branch.mjs';

const hash = value => createHash('sha256').update(value).digest('hex');

export async function observeImplementationPublication(api, snapshot, published, wait) {
  const expectedBase = snapshot.epic?.baseSha ?? snapshot.baseRevision ?? snapshot.sourceRevision;
  const expectedBranch = snapshot.epic?.base ?? snapshot.implementationReview?.base ?? snapshot.defaultBranch;
  // An existing PR can retain an older base snapshot; the live target ref binds authority.
  const observed = await observeUpdatedProductPull(async path => {
    const current = await api(path);
    if (current.number !== published.number || published.id !== undefined && current.id !== published.id || current.state !== 'open' || current.merged || current.head?.ref !== published.head.ref || current.head?.repo?.full_name !== snapshot.repository || current.base?.repo?.full_name !== snapshot.repository || current.base?.ref !== expectedBranch || !/^[a-f0-9]{40}$/.test(current.base?.sha ?? '') || (await api(`git/ref/heads/${expectedBranch}`))?.object?.sha !== expectedBase || ![snapshot.sourceRevision, published.head.sha].includes(current.head?.sha) || (await api(`git/ref/heads/${published.head.ref}`)).object?.sha !== published.head.sha) throw Error('Implementation changed after publication');
    return current;
  }, published.number, published.head.sha, wait);
  return published.verificationRefresh ? observeVerificationMerge(api, observed, expectedBase, wait) : observed;
}
const safePath = path => typeof path === 'string' && path.length < 300 && !path.startsWith('/') && !path.includes('\\') && !path.split('/').some(p => !p || p === '.' || p === '..' || p === '.git');
const protectedPath = path => /^(?:\.lighthouse|\.agents|\.product|\.git|\.opencode)(?:\/|$)/.test(path) || /(?:^|\/)(?:\.env(?:\..*)?|\.npmrc|\.netrc|id_rsa|id_ed25519)$/.test(path) || path.startsWith('.github/') || /(?:^|\/)(?:AGENTS|CLAUDE)\.md$/.test(path);
export const changesDigest = changes => hash(JSON.stringify(changes));
export function validateImplementationPolicy(policy, issue) {
  if (!policy || Object.keys(policy).filter(k => !['seed', 'proposal', 'verification'].includes(k)).sort().join(',') !== 'checks,paths,reviewRequired,scope' || typeof policy.reviewRequired !== 'boolean' || ('proposal' in policy && (!Number.isSafeInteger(policy.proposal) || policy.proposal < 1)) || typeof policy.scope !== 'string' || !policy.scope.trim() || policy.scope.length > 4000) throw Error('Invalid implementation policy');
  if (!Array.isArray(policy.paths) || !policy.paths.length || policy.paths.length > 40 || policy.paths.some(p => p !== '*' && (!safePath(p.replace(/\/$/, '')) || protectedPath(p) || p.startsWith('openspec/') && p !== `${proposalRoot(issue)}/tasks.md` && p !== `${proposalRoot(issue)}/` || p.startsWith('.github/') && !/^\.github\/workflows\/[\w-]+\.ya?ml$/.test(p)))) throw Error('Implementation policy needs safe paths');
  if (!Array.isArray(policy.checks) || !policy.checks.length || policy.checks.length > 12 || policy.checks.some(c => !Array.isArray(c) || !c.length || c.length > 30 || c.some(a => typeof a !== 'string' || !a || a.length > 1000 || /[\0\r\n]/.test(a)))) throw Error('Implementation policy needs bounded command argument arrays');
  if ('seed' in policy && (!policy.seed || typeof policy.seed !== 'object' || Object.keys(policy.seed).sort().join(',') !== 'base,head' || !/^[a-f0-9]{40}$/.test(policy.seed.base ?? '') || !/^[a-f0-9]{40}$/.test(policy.seed.head ?? ''))) throw Error('Seed must identify immutable base and head commits');
  if (policy.verification !== undefined) {
    const { paths, corrections } = policy.verification ?? {};
    if (!policy.verification || Object.keys(policy.verification).filter(key => key !== 'synchronizeBase').sort().join(',') !== 'corrections,paths' || 'synchronizeBase' in policy.verification && typeof policy.verification.synchronizeBase !== 'boolean' || !Array.isArray(paths) || !paths.length || paths.length > 40 || paths.some(p => typeof p !== 'string' || /[?*\[\]{}]/.test(p) || !safePath(p.replace(/\/$/, ''))) || new Set(paths).size !== paths.length || !corrections || typeof corrections !== 'object' || Array.isArray(corrections) || Object.keys(corrections).length > 40 || Object.entries(corrections).some(([path, reason]) => !safePath(path) || !paths.some(p => p.endsWith('/') ? path.startsWith(p) : path === p) || typeof reason !== 'string' || !reason.trim() || reason.length > 2000)) throw Error('Verification needs explicit input paths and bounded correction reasons');
  }
  return policy;
}
export const withinScope = (path, policy) => safePath(path) && !protectedPath(path) && policy.paths.some(p => p === '*' || (p.endsWith('/') ? path.startsWith(p) : path === p));

export async function loadImplementation(api, issue, owner, revision, defaultBranch, route = null) {
  const config = await api(`contents/.lighthouse/implement.json?ref=${revision}`, 'GET', undefined, true);
  const configured = config ? JSON.parse(Buffer.from(config.content, 'base64').toString()) : {};
  let policy = configured[issue] ?? configured.defaults;
  if (!policy) {
    const manifest = await api(`contents/package.json?ref=${revision}`, 'GET', undefined, true);
    const pkg = manifest ? JSON.parse(Buffer.from(manifest.content, 'base64').toString()) : {};
    if (!pkg.scripts?.verify) throw Error('Configure repository implementation checks in .lighthouse/implement.json defaults, or provide npm run verify');
    policy = { scope: 'Implement only this issue and its acceptance criteria.', paths: ['*'], checks: [['npm', 'ci', '--ignore-scripts'], ['npm', 'run', 'verify']], reviewRequired: false };
  }
  const planCheck = ['npx', '--yes', '--package=@fission-ai/openspec@1.15.0', 'openspec', 'validate', changeName(issue), '--strict', '--no-interactive'];
  policy = validateImplementationPolicy(policy, issue);
  if (route === 'epic') policy = validateImplementationPolicy({ ...policy, paths: [...new Set([...policy.paths, `${proposalRoot(issue)}/`])] }, issue);
  policy = { ...policy, checks: [...policy.checks, ...(route === 'hotfix' ? [] : [planCheck])] };
  const environmentFile = await api(`contents/.lighthouse/environment.json?ref=${revision}`, 'GET', undefined, true);
  const environment = environmentFile ? validateEnvironment(JSON.parse(Buffer.from(environmentFile.content, 'base64').toString())) : null;
  return { policy, proposal: { root: proposalRoot(issue) }, ...(environment ? { environment } : {}) };
}

// A reviewed immutable seed recovers a failed attempt without updating its branch.
export async function loadImplementationSeed(api, policy, revision) {
  if (!policy.seed) return null;
  const { base, head } = policy.seed;
  const commit = await api(`git/commits/${head}`);
  if (commit.parents?.length !== 1 || commit.parents[0].sha !== base) throw Error('Seed must be one commit directly based on the declared revision');
  const trees = [];
  for (const sha of [base, head, revision]) {
    const tree = await api(`git/trees/${sha}?recursive=1`);
    if (tree.truncated || !Array.isArray(tree.tree) || tree.tree.length > 10000) throw Error('Seed tree exceeds bounds');
    trees.push(new Map(tree.tree.filter(f => f.type !== 'tree').map(f => [f.path, f])));
  }
  const [before, after, current] = trees, changes = [];
  let bytes = 0;
  for (const path of [...new Set([...before.keys(), ...after.keys()])].sort()) {
    const old = before.get(path), next = after.get(path), live = current.get(path);
    if (old?.sha === next?.sha && old?.mode === next?.mode) continue;
    if (!withinScope(path, policy) || old?.sha !== live?.sha || old?.mode !== live?.mode) throw Error('Seed conflicts with current source or write scope');
    if ([old, next].filter(Boolean).some(f => f.type !== 'blob' || !['100644', '100755'].includes(f.mode))) throw Error('Seed contains a link or non-regular change');
    if (changes.length >= 512) throw Error('Seed exceeds changed-file bound');
    let content = null;
    if (next) {
      const blob = await api(`git/blobs/${next.sha}`);
      if (blob.encoding !== 'base64' || blob.size > 4 * 1024 * 1024) throw Error('Seed blob exceeds bounds');
      content = blob.content.replaceAll('\n', '');
      bytes += Buffer.byteLength(content, 'base64');
      if (bytes > 16 * 1024 * 1024) throw Error('Seed exceeds byte bounds');
    }
    changes.push({ path, mode: next?.mode ?? old.mode, content });
  }
  return validateChanges(changes, policy);
}

// Honor Git ignores for new output without hiding tracked edits or following source links.
export async function sourceFiles(root, baseline) {
  const metadata = baseline ? await mkdtemp(join(tmpdir(), 'lighthouse-ignore-')) : null;
  const gitEnv = { ...process.env, GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_COUNT: '0' };
  if (metadata) execFileSync('git', ['init', '--bare', '-q', metadata], { env: gitEnv });
  const trackedDirectories = new Set();
  for (const path of baseline?.keys() ?? []) { let parent = dirname(path); while (parent !== '.') { trackedDirectories.add(parent); parent = dirname(parent); } }
  const pendingLinks = new Set([...baseline ?? []].filter(([, file]) => file.mode === '120000').map(([path]) => path));
  const files = new Map(); let bytes = 0;
  async function visit(dir, relative = '') {
    for (const entry of await readdir(dir, { withFileTypes: true })) {
      if (entry.name === '.git') continue;
      const path = relative ? `${relative}/${entry.name}` : entry.name, target = join(dir, entry.name);
      if (metadata && !baseline.has(path) && !trackedDirectories.has(path)) {
        const ignored = spawnSync('git', ['--git-dir', metadata, '--work-tree', root, 'check-ignore', '--no-index', '-z', '--stdin'], { input: path + '\0', env: gitEnv, timeout: 10000, maxBuffer: 4096 });
        if (ignored.status === 0) continue;
        if (ignored.status !== 1) throw Error('Unable to resolve ignored implementation output');
      }
      const stat = await lstat(target);
      if (pendingLinks.has(path)) {
        if (!safePath(path) || !stat.isSymbolicLink()) throw Error(`Admitted source link changed: ${path}`);
        const content = await readlink(target, { encoding: 'buffer' });
        const sha = createHash('sha1').update(`blob ${content.length}\0`).update(content).digest('hex');
        if (sha !== baseline.get(path).sha) throw Error(`Admitted source link changed: ${path}`);
        pendingLinks.delete(path);
        continue;
      }
      if (!safePath(path) || stat.isSymbolicLink() || !stat.isDirectory() && !stat.isFile()) throw Error(`Unsafe implementation file: ${path}`);
      if (stat.isDirectory()) await visit(target, path);
      else {
        bytes += stat.size;
        if (bytes > 64 * 1024 * 1024 || files.size >= 5000) throw Error('Implementation source exceeds bounds');
        files.set(path, { content: await readFile(target), mode: stat.mode & 0o111 ? '100755' : '100644' });
      }
    }
  }
  try {
    await visit(root);
    if (pendingLinks.size) throw Error(`Admitted source link is absent: ${[...pendingLinks][0]}`);
    return files;
  } finally { if (metadata) await rm(metadata, { recursive: true, force: true }); }
}
export function collectChanges(before, after, policy) {
  const changes = [];
  const modelRoot = productModelDirectoryFromConfig(before.get('.product/config.yaml')?.content.toString('utf8') ?? '');
  for (const path of [...new Set([...before.keys(), ...after.keys()])].sort()) {
    const old = before.get(path), current = after.get(path);
    if (old && current && old.content.equals(current.content) && old.mode === current.mode) continue;
    if (path === modelRoot || path.startsWith(`${modelRoot}/`)) throw Error(`Implementation cannot change the accepted product model: ${path}; request Product Change approval and provider apply before resuming`);
    changes.push({ path, mode: current?.mode ?? old?.mode ?? '100644', content: current ? current.content.toString('base64') : null });
  }
  return validateChanges(changes, policy);
}
export function validateChanges(changes, policy) {
  if (!Array.isArray(changes) || changes.length > 512) throw Error('Implementation exceeds 512 changed files');
  const seen = new Set(); let bytes = 0;
  for (const file of changes) {
    if (!file || Object.keys(file).sort().join(',') !== 'content,mode,path' || !withinScope(file.path, policy) || seen.has(file.path) || !['100644', '100755'].includes(file.mode) || file.content !== null && (typeof file.content !== 'string' || Buffer.from(file.content, 'base64').toString('base64') !== file.content)) throw Error('Invalid or out-of-scope implementation change');
    seen.add(file.path);
    const buffer = Buffer.from(file.content ?? '', 'base64'); bytes += buffer.length;
    if (buffer.length > 4 * 1024 * 1024 || bytes > 16 * 1024 * 1024) throw Error('Implementation exceeds byte bounds');
    if (/\b(?:sk-|ghp_|github_pat_)[A-Za-z0-9_-]{15,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----/.test(buffer.toString())) throw Error(`Credential-shaped content rejected in ${file.path}`);
  }
  return changes;
}
export async function materializeCandidate(before, changes, destination) {
  const files = new Map(before);
  for (const file of changes) if (file.content === null) files.delete(file.path); else files.set(file.path, { content: Buffer.from(file.content, 'base64'), mode: file.mode });
  for (const [path, file] of files) { await mkdir(dirname(join(destination, path)), { recursive: true, mode: 0o777 }); await writeFile(join(destination, path), file.content, { mode: file.mode === '100755' ? 0o777 : 0o666 }); }
}
export function validateCheckReceipt(receipt, request, changes) {
  if ((request.sourceSynchronization || request.sourceLinks) && receipt?.schemaVersion !== 2) throw Error('Synchronized verification requires a bound command receipt');
  if (receipt?.schemaVersion === 2 && (receipt.binding?.repository !== request.repository || receipt.binding.issue !== request.issue || receipt.binding.runId !== request.runId || receipt.binding.sourceRevision !== request.sourceRevision || receipt.binding.policyRevision !== (request.baseRevision ?? request.sourceRevision) || receipt.binding.intent !== request.taskDigest || receipt.binding.policy !== hash(JSON.stringify(request.implementation)) || receipt.binding.planning !== hash(JSON.stringify(request.planningReference ?? null)) || receipt.binding.synchronization !== synchronizationDigest(request.sourceSynchronization) || receipt.binding.sourceLinks !== sourceLinksDigest(request.sourceLinks, request.sourceRevision) || receipt.binding.attempt !== Number(request.attempt) || receipt.binding.workflowRunId !== String(request.workflowRunId) || !/^[a-f0-9]{40}$/.test(receipt.candidateTree ?? ''))) throw Error('Implementation check receipt producer or input mismatch');
  if (receipt?.runId !== request.runId || receipt.sourceRevision !== request.sourceRevision || receipt.changesDigest !== changesDigest(changes) || !Array.isArray(receipt.checks) || receipt.checks.length !== request.implementation.policy.checks.length) throw Error('Implementation check receipt identity mismatch');
  for (let i = 0; i < receipt.checks.length; i++) if (JSON.stringify(receipt.checks[i].command) !== JSON.stringify(request.implementation.policy.checks[i]) || !Number.isInteger(receipt.checks[i].exitCode)) throw Error('Implementation check receipt command mismatch');
  if (request.implementation.environment) {
    const declaration = validateEnvironment(request.implementation.environment);
    if (!/^sha256:[a-f0-9]{64}$/.test(receipt.image ?? '') || receipt.environment?.image !== receipt.image || receipt.environment?.profile !== declaration.profile || !Array.isArray(receipt.environment.services) || receipt.environment.services.length !== declaration.services.length || receipt.environment.services.some(s => s.type !== 'postgresql' || !/^sha256:[a-f0-9]{64}$/.test(s.image ?? ''))) throw Error('Implementation environment receipt mismatch');
  }
  return receipt.serviceCleanup !== false && receipt.checks.every(c => c.exitCode === 0);
}
export function isVerificationOnlyCorrection(request) {
  const review = request.implementationReview;
  return request.stage === 'implement' && request.worker === 'apply-review' && review?.approved === false && review.issue === request.issue && review.head === request.sourceRevision && /^[a-f0-9]{40}$/.test(review.head ?? '') && /^[a-f0-9]{40}$/.test(request.baseRevision ?? '') && /^[a-f0-9]{64}$/.test(review.implementationIdentity ?? '') && /^[a-f0-9]{64}$/.test(review.feedbackDigest ?? '');
}
function publicationState(snapshot, checkedTree) {
  return {
    state: 'prepared', originalHead: snapshot.sourceRevision, publishedHead: null, checkedTree: checkedTree ?? null,
    base: { branch: snapshot.epic?.base ?? snapshot.implementationReview?.base ?? snapshot.defaultBranch, head: snapshot.epic?.baseSha ?? snapshot.baseRevision ?? snapshot.sourceRevision },
    pullRequest: null, verificationRefresh: false,
    authority: structuredClone({ repository: snapshot.repository, issue: snapshot.issue, head: snapshot.sourceRevision, dispatch: snapshot.dispatch ?? null, feedback: snapshot.implementationReview ?? null, productResume: snapshot.productResume ?? null, productAlignment: snapshot.productAlignment ?? null, epic: snapshot.epic ?? null, ciRepair: snapshot.ciRepair ?? null }),
  };
}

export async function readImplementationPublication(api, snapshot, transition, wait) {
  const prepared = publicationState(snapshot, transition.checkedTree);
  if (transition.state !== 'confirmed' || transition.originalHead !== prepared.originalHead || JSON.stringify(transition.base) !== JSON.stringify(prepared.base) || JSON.stringify(transition.authority) !== JSON.stringify(prepared.authority)) throw Error('Implementation publication authority changed');
  const pr = transition.pullRequest;
  const observed = await observeImplementationPublication(api, snapshot, { number: pr.number, id: pr.id, head: { sha: transition.publishedHead, ref: pr.branch }, verificationRefresh: transition.verificationRefresh }, wait);
  if (transition.checkedTree !== null && (await api(`git/commits/${transition.publishedHead}`)).tree?.sha !== transition.checkedTree) throw Error('Command evidence does not bind the tested and published trees');
  return observed;
}

export async function publishImplementationPullRequest(api, { snapshot, changes, body, runUrl, draft, beforeWrite, afterRefWrite = async () => {}, refreshVerification = false, checkedTree, wait }) {
  const prepared = publicationState(snapshot, checkedTree);
  const published = await writeImplementationPullRequest(api, { snapshot, changes, body, runUrl, draft, beforeWrite: () => beforeWrite(structuredClone(prepared)), afterRefWrite: () => afterRefWrite(structuredClone(prepared)), refreshVerification, checkedTree });
  const observed = await observeImplementationPublication(api, snapshot, published, wait);
  if (checkedTree !== undefined && (await api(`git/commits/${observed.head.sha}`)).tree?.sha !== checkedTree) throw Error('Command evidence does not bind the tested and published trees');
  return { ...prepared, state: 'confirmed', publishedHead: observed.head.sha, pullRequest: { id: observed.id, number: observed.number, url: observed.html_url, branch: observed.head.ref }, verificationRefresh: published.verificationRefresh === true };
}

// Keep the exported positional entrypoint compatible for installed consumers.
export async function createImplementationPullRequest(api, snapshot, changes, body, runUrl, draft, beforeWrite, afterRefWrite = async () => {}, { refreshVerification = false, checkedTree } = {}) {
  return writeImplementationPullRequest(api, { snapshot, changes, body, runUrl, draft, beforeWrite, afterRefWrite, refreshVerification, checkedTree });
}

async function writeImplementationPullRequest(api, { snapshot, changes, body, runUrl, draft, beforeWrite, afterRefWrite, refreshVerification, checkedTree }) {
  validateChanges(changes, snapshot.implementation.policy);
  if (!changes.length && !isVerificationOnlyCorrection(snapshot)) throw Error('No implementation changes to publish');
  const synchronization = snapshot.sourceSynchronization;
  if (synchronization) {
    if (!refreshVerification || !/^[a-f0-9]{40}$/.test(checkedTree ?? '') || !isVerificationOnlyCorrection(snapshot) || changes.length || snapshot.epic || snapshot.productResume || snapshot.productAlignment || snapshot.implementation.policy.verification?.synchronizeBase !== true || synchronization.source !== snapshot.sourceRevision || synchronization.base !== snapshot.baseRevision) throw Error('Source synchronization requires a completed immutable verification correction');
    if (JSON.stringify(await prepareSourceSynchronization(api, snapshot.sourceRevision, snapshot.baseRevision)) !== JSON.stringify(synchronization)) throw Error('Source synchronization authority changed');
  }
  const epic = snapshot.epic;
  if (epic && (!Number.isSafeInteger(epic.parent) || epic.parent < 1 || epic.parent === snapshot.issue || epic.base !== `lighthouse/epic-${epic.parent}` || !/^[a-f0-9]{40}$/.test(epic.baseSha ?? '') || (snapshot.implementationReview ? snapshot.implementationReview.base !== epic.base || snapshot.implementationReview.head !== snapshot.sourceRevision : epic.baseSha !== snapshot.sourceRevision))) throw Error('Invalid epic publication base');
  const branch = await selectPublicationBranch(api, snapshot, 'implement', snapshot.implementationReview?.branch ?? snapshot.productResume?.branch ?? snapshot.productAlignment?.parent.pullRequest?.branch);
  const checkEpicBase = async () => {
    if (epic && (await api(`git/ref/heads/${epic.base}`)).object?.sha !== epic.baseSha) throw Error('Epic base changed; revalidate the child');
  };
  const description = marker => `${body.trim()}\n\nRefs #${snapshot.issue}.\n\nNext: ${draft ? 'complete the candidate and its checks' : 'wait for required CI, then review this PR'}. [Run and evidence](${runUrl}).\n\n<!-- lighthouse-implementation:${marker} -->`;
  const reviewBody = (current, head) => {
    const proof = productImplementationProof(current), marker = current.body?.match(/<!-- lighthouse-implementation:([a-f0-9]{64}) -->/)?.[1];
    if (!marker && !proof) throw Error('Implementation PR marker missing during update');
    if (!proof) return description(marker);
    const prior = current.body.replace(/<!-- lighthouse-product-implementation:\{[^\n]*\} -->/g, '');
    const evidence = `${body.trim()}\n\n[Implementation evidence](${runUrl}).`;
    if (proof.runId === snapshot.runId && proof.head === head && prior.trimEnd().endsWith(evidence)) return current.body;
    return `${prior}\n\n${evidence}\n\n<!-- lighthouse-product-implementation:${JSON.stringify({ ...proof, runId: snapshot.runId, head })} -->`;
  };
  await checkEpicBase();
  let verificationRefresh = false;
  if (!changes.length) {
    await beforeWrite();
    await checkEpicBase();
    const current = await checkReviewCurrent(api, snapshot.repository, snapshot.implementationReview, true);
    verificationRefresh = !synchronization && refreshVerification === true && !epic && !snapshot.productResume && !snapshot.productAlignment && await needsVerificationRefresh(api, current, snapshot.baseRevision);
    if (!verificationRefresh && !synchronization) {
      const revised = reviewBody(current, snapshot.sourceRevision);
      if (current.body !== revised) {
        try { await api(`pulls/${current.number}`, 'PATCH', { body: revised }); }
        catch (error) {
          const observed = await checkReviewCurrent(api, snapshot.repository, snapshot.implementationReview, true);
          if (observed.body !== revised) throw error;
          await beforeWrite(); await checkEpicBase();
          return observed;
        }
      }
      return { ...current, body: revised };
    }
  }
  const commit = await api(`git/commits/${snapshot.sourceRevision}`), entries = [];
  if (synchronization && (commit.sha !== synchronization.source || commit.tree?.sha !== synchronization.sourceTree)) throw Error('Synchronized source tree changed');
  for (const file of changes) {
    const sha = file.content === null ? null : (await api('git/blobs', 'POST', { content: file.content, encoding: 'base64' })).sha;
    entries.push({ path: file.path, mode: file.mode, type: 'blob', sha });
  }
  if (synchronization) entries.push(...synchronization.files.map(({ path, sha, mode }) => ({ path, sha, mode, type: 'blob' })));
  if (verificationRefresh && (commit.sha !== snapshot.sourceRevision || !/^[a-f0-9]{40}$/.test(commit.tree?.sha ?? ''))) throw Error('Checked verification tree changed');
  const tree = verificationRefresh ? commit.tree : await api('git/trees', 'POST', { base_tree: commit.tree.sha, tree: entries });
  if (synchronization && tree.sha !== checkedTree) throw Error('Synchronized publication differs from the independently checked tree');
  const message = verificationRefresh ? `chore: refresh verification for issue #${snapshot.issue}\n\nLighthouse-CI-Base: ${snapshot.baseRevision}` : `feat: implement issue #${snapshot.issue}`;
  const created = await api('git/commits', 'POST', { message, tree: tree.sha, parents: synchronization ? [snapshot.sourceRevision, snapshot.baseRevision] : [snapshot.sourceRevision] });
  await beforeWrite();
  await checkEpicBase();
  if (snapshot.productAlignment?.parent.pullRequest) {
    const prior = snapshot.productAlignment.parent.pullRequest;
    const current = await api(`pulls/${prior.number}`);
    checkAlignedImplementationPullRequest(current, snapshot.repository, snapshot.productAlignment);
    await api(`git/refs/heads/${prior.branch}`, 'PATCH', { sha: created.sha, force: false });
    const proof = productImplementationProof(current);
    const preserved = proof ? current.body.replace(/<!-- lighthouse-product-implementation:\{[^\n]*\} -->/, `<!-- lighthouse-product-implementation:${JSON.stringify({ ...proof, runId: snapshot.runId, head: created.sha })} -->`) : current.body;
    await api(`pulls/${prior.number}`, 'PATCH', { body: `${preserved}\n\n${body.trim()}\n\n[Implementation evidence](${runUrl}).` });
    return { number: prior.number, html_url: current.html_url, head: { sha: created.sha, ref: prior.branch } };
  }
  if (snapshot.productResume) {
    const resume = snapshot.productResume;
    const current = await api(`pulls/${resume.pullRequest}`);
    checkProductResumePullRequest(current, snapshot.repository, resume);
    await api(`git/refs/heads/${resume.branch}`, 'PATCH', { sha: created.sha, force: false });
    const proof = { schemaVersion: 1, issue: snapshot.issue, runId: snapshot.runId, applyIntent: resume.receiptIntent, head: created.sha };
    const prior = (current.body ?? '').replace(/<!-- lighthouse-product-implementation:\{[^\n]*\} -->/g, '');
    await api(`pulls/${resume.pullRequest}`, 'PATCH', { body: `${prior}\n\n${body.trim()}\n\n[Implementation evidence](${runUrl}).\n\n<!-- lighthouse-product-implementation:${JSON.stringify(proof)} -->` });
    return { number: resume.pullRequest, html_url: current.html_url, head: { sha: created.sha, ref: resume.branch } };
  }
  if (snapshot.implementationReview) {
    const current = await api(`pulls/${snapshot.implementationReview.number}`);
    if (current.head?.sha !== snapshot.sourceRevision) throw Error('Implementation PR changed before update');
    try { await api(`git/refs/heads/${snapshot.implementationReview.branch}`, 'PATCH', { sha: created.sha, force: false }); }
    catch (error) {
      if (!verificationRefresh && !synchronization) throw error;
      const observed = await api(`git/ref/heads/${snapshot.implementationReview.branch}`);
      if (observed.ref !== `refs/heads/${snapshot.implementationReview.branch}` || observed.object?.sha !== created.sha) throw error;
    }
    const revised = reviewBody(current, created.sha);
    if (epic) {
      for (let attempt = 0; ; attempt++) {
        const updated = await api(`pulls/${snapshot.implementationReview.number}`);
        if (updated.base?.ref !== epic.base || updated.head?.ref !== snapshot.implementationReview.branch || ![snapshot.sourceRevision, created.sha].includes(updated.head?.sha) || (await api(`git/ref/heads/${snapshot.implementationReview.branch}`)).object?.sha !== created.sha) throw Error('Epic PR changed during its update');
        await checkEpicBase();
        if (updated.head.sha === created.sha) break;
        if (attempt === 3) throw Error('Epic PR head readback did not reach the confirmed update');
        await setTimeout(250 * 2 ** attempt);
      }
      await afterRefWrite();
    }
    await api(`pulls/${snapshot.implementationReview.number}`, 'PATCH', { body: revised });
    return { number: snapshot.implementationReview.number, html_url: snapshot.implementationReview.url, head: { sha: created.sha, ref: snapshot.implementationReview.branch }, ...(verificationRefresh ? { verificationRefresh: true } : {}) };
  }
  await api('git/refs', 'POST', { ref: `refs/heads/${branch}`, sha: created.sha });
  if (epic) { await beforeWrite(); await checkEpicBase(); }
  return api('pulls', 'POST', { title: snapshot.title.slice(0, 180), head: branch, base: epic?.base ?? snapshot.defaultBranch, draft, body: description(snapshot.runId) });
}
