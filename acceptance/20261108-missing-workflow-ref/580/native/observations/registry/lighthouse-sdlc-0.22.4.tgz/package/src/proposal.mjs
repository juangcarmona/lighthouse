import { loadClientDispatch, checkClientSnapshot } from './issue-control-native.mjs';
export { changeName, proposalRoot, validateProposalFiles } from './proposal-files.mjs';
import { changeName, proposalRoot, validateProposalFiles } from './proposal-files.mjs';
import { loadDispatch, checkDispatchClaim } from './stage-dispatch.mjs';
import { mkdtemp, mkdir, readFile, writeFile, rm, realpath } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { isDeepStrictEqual } from 'node:util';
import { checkProductResumePullRequest } from './product-change.mjs';
import { readActionsJson } from './actions-artifact.mjs';
import { selectPublicationBranch } from './publication-branch.mjs';
import { openSpec as openspec } from './openspec-provider.mjs';

export function proposalValidationFailure(error, issue) {
  if ((error.code ?? error.status) !== 1 || error.signal || error.killed || !error.stdout || Buffer.byteLength(error.stdout) > 65536) return null;
  try {
    const output = error.stdout.toString(), report = JSON.parse(output), item = report.items?.[0];
    if (report.version !== '1.0' || report.items.length !== 1 || item.id !== changeName(issue) || item.type !== 'change' || item.valid !== false || report.summary?.totals?.items !== 1 || report.summary.totals.failed !== 1 || report.summary.totals.passed !== 0 || !Array.isArray(item.issues) || !item.issues.length || item.issues.length > 64 || item.issues.some(finding => !['ERROR', 'WARNING', 'INFO'].includes(finding.level) || typeof finding.path !== 'string' || typeof finding.message !== 'string' || !finding.message.trim())) return null;
    const findings = item.issues.filter(finding => finding.level !== 'INFO').slice(0, 8).map(finding => `${finding.path}: ${finding.message}`.slice(0, 1000));
    return findings.length ? { provider: '@fission-ai/openspec@1.15.0', status: 'failed', findings, output } : null;
  } catch { return null; }
}

// Use the provider's scaffold, instructions and validator; never maintain a copied schema.
export async function prepareProposal(issue, files, provider = openspec, baseline = null) {
  if (files) validateProposalFiles(files, issue);
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-proposal-'));
  const name = changeName(issue);
  try {
    for (const [path, file] of baseline ?? []) {
      if (path !== 'openspec/config.yaml' && !path.startsWith('openspec/specs/') && !path.startsWith('openspec/schemas/')) continue;
      if (path.includes('\\') || path.split('/').some(part => !part || part === '.' || part === '..')
          || !['100644', '100755'].includes(file.mode) || !Buffer.isBuffer(file.content)) throw Error('Invalid OpenSpec baseline input');
      const target = join(dir, path);
      await mkdir(dirname(target), { recursive: true }); await writeFile(target, file.content);
    }
    await provider(dir, ['new', 'change', name, '--schema', 'spec-driven', '--json']);
    if (!files) {
      let discovery = null;
      if (baseline !== null) {
        const command = ['list', '--specs', '--json'];
        const inventory = JSON.parse(await provider(dir, command));
        if (!Array.isArray(inventory.specs) || !Array.isArray(inventory.status ?? [])
            || (inventory.status ?? []).some(item => item?.severity === 'error')
            || ![dir, await realpath(dir)].includes(inventory.root?.path))
          throw Error('OpenSpec discovery did not identify the prepared source baseline');
        discovery = { status: 'passed', command: ['openspec', ...command], specifications: inventory.specs, diagnostics: inventory.status ?? [] };
      }
      const instructions = {};
      for (const artifact of ['proposal', 'specs', 'design', 'tasks']) {
        const value = JSON.parse(await provider(dir, ['instructions', artifact, '--change', name, '--json']));
        instructions[artifact] = { outputPath: value.outputPath, instruction: value.instruction, template: value.template };
      }
      return { provider: '@fission-ai/openspec@1.15.0', schema: 'spec-driven', root: proposalRoot(issue), instructions, ...(discovery ? { discovery } : {}) };
    }
    const metadata = `${proposalRoot(issue)}/.openspec.yaml`;
    for (const file of files) {
      const path = join(dir, file.path);
      if (file.path === metadata) { await writeFile(path, `${(await readFile(path, 'utf8')).trimEnd()}\nskip_specs: true\n`); continue; }
      await mkdir(dirname(path), { recursive: true }); await writeFile(path, file.content);
    }
    try { await provider(dir, ['validate', name, '--strict', '--no-interactive', '--json']); }
    catch (error) {
      const validation = proposalValidationFailure(error, issue);
      if (validation) {
        error.proposalValidation = validation;
        error.message += '\nOpenSpec validation: ' + validation.findings.join('; ').slice(0, 3000);
      }
      throw error;
    }
    const status = JSON.parse(await provider(dir, ['status', '--change', name, '--json']));
    if (!status.isPlanningComplete) throw Error('OpenSpec planning artifacts are incomplete');
    return [...files.filter(file => file.path !== metadata), { path: metadata, content: await readFile(join(dir, metadata), 'utf8') }];
  } finally { await rm(dir, { recursive: true, force: true }); }
}

export function checkRefinement(predecessor, envelope, run, current, marker, dispatched = false) {
  if (run.status !== 'completed' || run.conclusion !== 'success' || (dispatched ? run.path !== '.github/workflows/lighthouse-sdlc-refine.lock.yml' : run.event !== 'issues' && run.event !== 'issue_comment' && run.event !== 'workflow_dispatch' || run.path !== '.github/workflows/lighthouse-sdlc-router.yml' || run.actor?.login !== current.owner)) throw Error('Predecessor is not a successful owner workflow');
  if (String(run.id) !== String(predecessor.workflowRunId) || run.head_sha !== (dispatched ? predecessor.workflowRevision : predecessor.sourceRevision) || predecessor.stage !== 'refine' || predecessor.issue !== current.issue || envelope.result?.stage !== 'refine' || envelope.result?.status !== 'passed' || envelope.result?.gate !== 'ready' || envelope.result?.runId !== predecessor.runId || marker !== predecessor.runId) throw Error('Refinement evidence identity mismatch');
  if (predecessor.sourceRevision !== current.sourceRevision || predecessor.taskDigest !== current.taskDigest) throw Error('Refinement is stale; run refine against the current source and owner intent first');
}

export async function loadStageReport(api, repo, report, current, readArtifact = readActionsJson) {
  const marker = report?.body.match(/<!-- lighthouse-actions:([a-f0-9]{64}) -->/)?.[1];
  const runId = report?.body.match(/\[Workflow run\]\(https:\/\/github\.com\/[^/]+\/[^/]+\/actions\/runs\/(\d+)\)/)?.[1];
  if (!marker || !runId) throw Error('No authenticated refinement report; run refine first');
  const run = await api(`actions/runs/${runId}`);
  const prefix = /<!-- lighthouse-stage:implement:/.test(report.body) ? 'implement-' : '';
  const request = await readArtifact(api, repo, runId, `lighthouse-${prefix}input-${current.issue}-${run.run_attempt}`, 'request.json');
  const envelope = await readArtifact(api, repo, runId, `lighthouse-${prefix}result-${current.issue}-${run.run_attempt}`, 'envelope.json');
  if (request.dispatch) {
    if (!['triage', 'refine', 'propose', 'implement'].includes(request.stage) || !report.body.includes(`<!-- lighthouse-stage:${request.stage}:`)) throw Error('Unexpected dispatched stage');
    const dispatch = await loadDispatch(api, repo, current.owner, current.issue, request.dispatch.commentId, run, readArtifact);
    const dispatchedRevision = request.baseRevision ?? request.sourceRevision;
    if (dispatch.request.stage !== request.stage || dispatch.request.id !== request.dispatch.requestId || dispatch.request.sourceRevision !== dispatchedRevision || dispatch.request.workflowRevision !== request.workflowRevision || !isDeepStrictEqual(dispatch.request.epic, request.epic)) throw Error('Dispatched report identity mismatch');
    const client = await loadClientDispatch({ api, repository: repo, owner: current.owner, native: dispatch.request, readArtifact });
    checkClientSnapshot(client, dispatch.request, request);
    await checkDispatchClaim(api, repo, current.issue, request.dispatch, run.id);
  } else if (!['issues', 'issue_comment', 'workflow_dispatch'].includes(run.event) || run.path !== '.github/workflows/lighthouse-sdlc-router.yml' || run.actor?.login !== current.owner || run.head_sha !== request.sourceRevision) throw Error('Stage report identity mismatch');
  if (run.status !== 'completed' || run.conclusion !== 'success' || String(run.id) !== String(request.workflowRunId) || request.issue !== current.issue || marker !== request.runId) throw Error('Stage report identity mismatch');
  return { request, envelope, report: report.html_url, run, marker };
}

export async function loadRefinement(api, repo, reports, current, readArtifact = readActionsJson) {
  const report = [...reports].reverse().find(c => c.user.login === 'github-actions[bot]' && (/<!-- lighthouse-stage:refine:passed -->/.test(c.body) || /^## Refinement:/m.test(c.body)) && /<!-- lighthouse-actions:[a-f0-9]{64} -->/.test(c.body));
  const evidence = await loadStageReport(api, repo, report, current, readArtifact);
  checkRefinement(evidence.request, evidence.envelope, evidence.run, current, evidence.marker, !!evidence.request.dispatch);
  return { request: evidence.request, envelope: evidence.envelope, report: evidence.report };
}

export async function createProposalPullRequest(api, snapshot, files, body, runUrl, beforeWrite) {
  const branch = await selectPublicationBranch(api, snapshot, 'propose', snapshot.productResume?.branch);
  // A fresh immutable branch per run avoids updating a human's or another run's work.
  const commit = await api(`git/commits/${snapshot.sourceRevision}`);
  const tree = await api('git/trees', 'POST', { base_tree: commit.tree.sha, tree: files.map(file => ({ path: file.path, mode: '100644', type: 'blob', content: file.content })) });
  const created = await api('git/commits', 'POST', { message: `docs: propose issue #${snapshot.issue}`, tree: tree.sha, parents: [snapshot.sourceRevision] });
  await beforeWrite();
  if (snapshot.productResume) {
    const resume = snapshot.productResume;
    const current = await api(`pulls/${resume.pullRequest}`);
    checkProductResumePullRequest(current, snapshot.repository, resume);
    await api(`git/refs/heads/${resume.branch}`, 'PATCH', { sha: created.sha, force: false });
    const proof = { schemaVersion: 1, issue: snapshot.issue, runId: snapshot.runId, applyIntent: resume.receiptIntent, head: created.sha };
    await api(`pulls/${resume.pullRequest}`, 'PATCH', { body: `${current.body}\n\n${body.trim()}\n\n[Proposal evidence](${runUrl}).\n\n<!-- lighthouse-product-proposal:${JSON.stringify(proof)} -->` });
    return { number: resume.pullRequest, html_url: current.html_url };
  }
  await api('git/refs', 'POST', { ref: `refs/heads/${branch}`, sha: created.sha });
  const pr = await api('pulls', 'POST', { title: `Proposal for #${snapshot.issue}: ${snapshot.title.slice(0, 160)}`, head: branch, base: snapshot.defaultBranch, body: `${body}\n\nRelated to #${snapshot.issue}. Proposal only; implementation requires a separate owner decision.\n\nOpenSpec 1.15.0 strict validation passed. [Execution evidence](${runUrl}).\n\n<!-- lighthouse-proposal:${snapshot.runId} -->` });
  return pr;
}
