import { digest } from './digests.mjs';
import { readActionsJson } from './actions-artifact.mjs';
import { handoff } from './handoff.mjs';
import { isDeepStrictEqual } from 'node:util';

const routerPath = '.github/workflows/lighthouse-sdlc-router.yml';
export const stages = ['triage', 'refine', 'propose', 'implement', 'integrate', 'review'];
export const workers = [...stages, 'apply-review', 'product-change', 'apply-product-change'];
export const workerFor = request => request.worker ?? request.stage ?? 'implement';
export const stagePath = stage => { if (!workers.includes(stage)) throw Error('Unknown dispatch worker'); return `.github/workflows/lighthouse-sdlc-${stage}.lock.yml`; };
export const implementPath = stagePath('implement');
export const statusText = (stage, status) => `${({ requested: 'Requested', running: 'Queued', completed: 'Stage completed', waiting: 'Waiting for your answer', blocked: 'Blocked', failed: 'Execution failed', cancelled: 'Cancelled', unknown: 'Execution status unknown' })[status] ?? 'Execution status unknown'} · ${stage}`;
const positive = value => /^[1-9][0-9]*$/.test(String(value));
export const isBotContinuation = (event, eventName, actor, triggeringActor) => eventName === 'workflow_dispatch' && actor === 'github-actions[bot]' && triggeringActor === actor && (event.inputs?.stage === 'implement' && event.inputs?.workflow !== 'product-change' || event.inputs?.stage === 'review' && event.inputs?.workflow === 'stage' || ['triage', 'refine', 'propose', 'implement'].includes(event.inputs?.stage) && ['product-change', 'resume-product', 'resume-aligned'].includes(event.inputs?.workflow)) && positive(event.inputs?.issue) && positive(event.inputs?.after_run);
export const isBotEpicTriage = (event, eventName, actor, triggeringActor) => eventName === 'workflow_dispatch' && actor === 'github-actions[bot]' && triggeringActor === actor && event.inputs?.stage === 'triage' && positive(event.inputs?.issue) && positive(event.inputs?.epic_parent) && positive(event.inputs?.epic_run);
export const isBotEpicRefinement = (event, eventName, actor, triggeringActor) => eventName === 'workflow_dispatch' && actor === 'github-actions[bot]' && triggeringActor === actor && event.inputs?.stage === 'refine' && event.inputs?.workflow === 'stage' && positive(event.inputs?.issue) && positive(event.inputs?.epic_parent) && positive(event.inputs?.epic_run);
const sha = value => /^[a-f0-9]{40}$/.test(value ?? '');
const hash = value => /^[a-f0-9]{64}$/.test(value ?? '');
export const dispatchId = (repository, runId, stage = 'implement') => digest(`${repository}:${runId}:${stage}`);
export const epicTriageKey = (repository, parent, child, planDigest) => digest(`${repository}:epic-triage:${parent}:${child}:${planDigest}`);
export const epicRefinementKey = (repository, parent, child, planDigest, runId) => digest(`${repository}:epic-refinement:${parent}:${child}:${planDigest}:${runId}`);
export const receiptId = (repository, receipt) => receipt.recovery ? digest(`${repository}:${receipt.recovery.rootId}:retry:${receipt.recovery.attempt}`) : dispatchId(repository, receipt.epicKey ?? receipt.feedbackKey ?? receipt.eventRunId ?? receipt.routerRunId, receipt.stage ?? 'implement');
export const dispatchArtifact = request => `lighthouse-dispatch-${request.id}`;

// Event/run IDs authenticate delivery, while this key reconciles equivalent grants.
export const dispatchIntent = request => digest(JSON.stringify({
  repository: request.repository, issue: request.issue, stage: request.stage, worker: workerFor(request),
  task: request.taskDigest, source: request.sourceRevision, workflow: request.workflowRevision,
  feedback: request.feedbackKey, epic: request.epic, completion: request.completionAuthorization,
  autoImplement: request.autoImplement, productChangeEnabled: request.productChangeEnabled,
  client: request.client ? { payloadDigest: request.client.payloadDigest, action: request.client.action, scope: request.client.scope } : undefined,
  integration: request.integrationRequest, productApproval: request.productApproval,
  productParent: request.productParent, productResume: request.productResume, productAlignment: request.productAlignment,
  productReview: request.productReview, productFeedback: request.productFeedback,
  model: request.event?.inputs?.model_selection || undefined,
}));

export function readDispatchReceipt(comment, repository, issue) {
  if (comment?.user?.login !== 'github-actions[bot]' || comment.user.type !== 'Bot' || comment.issue_url !== `https://api.github.com/repos/${repository}/issues/${issue}`) throw Error('Untrusted dispatch receipt');
  const matches = [...comment.body.matchAll(/<!-- lighthouse-dispatch:(\{[^\n]*\}) -->/g)];
  if (matches.length !== 1) throw Error('Missing or ambiguous dispatch receipt');
  const receipt = JSON.parse(matches[0][1]);
  const rejected = receipt.admissionRejected;
  if (rejected && (rejected.code !== 'workflow-revision-rejected' || rejected.attempt !== 1 || !sha(rejected.expectedRevision) || !sha(rejected.observedRevision) || rejected.expectedRevision === rejected.observedRevision || !positive(receipt.workerRunId) || receipt.status !== 'failed' || rejected.nextAction !== undefined && (typeof rejected.nextAction !== 'string' || rejected.nextAction.length > 1024))) throw Error('Invalid admission rejection receipt');
  if (receipt.intent !== undefined && !hash(receipt.intent)) throw Error('Invalid dispatch intent');
  if ((receipt.clientKey !== undefined || receipt.clientPayloadDigest !== undefined) && (!hash(receipt.clientKey) || !hash(receipt.clientPayloadDigest))) throw Error('Invalid client dispatch binding');
  if (receipt.recovery && (!hash(receipt.recovery.rootId) || !positive(receipt.recovery.previousComment) || !Number.isSafeInteger(receipt.recovery.attempt) || receipt.recovery.attempt < 1 || receipt.recovery.attempt > 2 || receipt.recovery.kind !== undefined && (receipt.recovery.kind !== 'before-admission' || receipt.recovery.attempt !== 1))) throw Error('Invalid recovery receipt');
  if (receipt.schemaVersion !== 1 || !hash(receipt.id) || !hash(receipt.digest) || !positive(receipt.routerRunId) || !positive(receipt.routerAttempt) || !stages.includes(receipt.stage ?? 'implement') || !workers.includes(workerFor(receipt)) || (receipt.epicKey !== undefined && !hash(receipt.epicKey)) || (receipt.feedbackKey !== undefined && !hash(receipt.feedbackKey)) || (receipt.eventRunId !== undefined && !positive(receipt.eventRunId)) || receipt.id !== receiptId(repository, receipt) || (receipt.workerRunId !== null && !positive(receipt.workerRunId))) throw Error('Invalid dispatch receipt');
  return receipt;
}

export function dispatchReceiptBody(repository, receipt) {
  const root = `https://github.com/${repository}/actions/runs/`;
  const status = receipt.status ?? (receipt.workerRunId ? 'running' : 'requested');
  const states = {
    requested: ['requested', 'The request is recorded; execution is not confirmed.', 'None. Wait for admission.', 'The workflow will report the outcome when the request is processed.'],
    running: ['queued', 'The worker admitted the request; agent execution is not yet confirmed.', 'None. Wait for the result.', 'The workflow will publish a result or an actionable stop.'],
    completed: ['completed', 'The stage published a validated result.', 'Follow the latest stage handoff.', 'The configured continuation applies only when authorized.'],
    waiting: ['blocked', 'The stage published a blocked result.', 'Follow the latest stage handoff.', 'Continuation depends on the recorded blocker and authorization.'],
    blocked: ['blocked', 'The stage published a blocker without a pending owner question.', 'The workflow maintainer should follow the latest stage handoff.', 'Work remains stopped until the blocker is resolved and continuation is authorized.'],
    failed: ['failed', 'This attempt did not publish a validated result.', 'The workflow maintainer should inspect the execution and recovery policy.', 'Any retry requires the configured authorization.'],
    cancelled: ['cancelled', 'This attempt was cancelled before a validated result was published.', 'The workflow maintainer should inspect the execution.', 'Any restart requires the configured authorization.'],
    unknown: ['unknown', 'Publication of a validated result could not be confirmed.', 'The workflow maintainer should inspect the execution.', 'Reconcile the outcome before requesting another attempt.'],
  };
  const item = receipt.admissionRejected ? ['failed', `GitHub resolved workflow revision \`${receipt.admissionRejected.observedRevision}\` instead of \`${receipt.admissionRejected.expectedRevision}\`. This worker was rejected before admission; no agent or publisher was authorized.`, receipt.admissionRejected.nextAction ?? 'The workflow maintainer should inspect the linked rejected execution and scoped recovery observation.', 'Only one authenticated review recovery is allowed after current authority and skipped effects are verified.'] : states[status];
  if (!item) throw Error('Unknown dispatch status');
  const recovery = receipt.recovery ? `\nRetry ${receipt.recovery.attempt}/${receipt.recovery.kind === 'before-admission' ? 1 : 2} · [Previous request](https://github.com/${repository}/issues/${receipt.issue ?? ''}#issuecomment-${receipt.recovery.previousComment})` : '';
  const details = `[Dispatch origin](${root}${receipt.routerRunId})${receipt.workerRunId ? ` · [Execution](${root}${receipt.workerRunId})` : ''}${recovery}\n\n<!-- lighthouse-dispatch:${JSON.stringify(receipt)} -->`;
  return handoff({ status: item[0], stage: workerFor(receipt), happened: item[1], action: item[2], next: item[3], details });
}

export async function issueComments(api, issue) {
  const all = [];
  for (let page = 1; page <= 10; page++) {
    const batch = await api(`issues/${issue}/comments?per_page=100&page=${page}`);
    all.push(...batch);
    if (batch.length < 100) return all;
  }
  throw Error('Comment history exceeds bounded intake');
}

// The router dispatch job serializes receipt creation per issue. Workers acquire
// the existing issue concurrency group before claiming a receipt.
export async function recordDispatch(api, repository, request) {
  if (request.intent !== undefined && request.intent !== dispatchIntent(request)) throw Error('Invalid dispatch intent binding');
  if (Buffer.byteLength(JSON.stringify(request)) > 128000) throw Error('Dispatch request exceeds its artifact bound');
  const comments = await issueComments(api, request.issue);
  let equivalent;
  for (const comment of comments) {
    if (comment.user?.login !== 'github-actions[bot]' || !comment.body.includes('<!-- lighthouse-dispatch:')) continue;
    const receipt = readDispatchReceipt(comment, repository, request.issue);
    if (equivalent && Number(comment.id) > Number(equivalent.comment.id)) equivalent = null;
    if (receipt.id === request.id) return { send: false, comment, receipt, reason: 'This authenticated request is already recorded; no automatic resend.' };
    if (!receipt.workerRunId) throw Error('An earlier stage dispatch is unconfirmed; reconcile it before requesting another');
    const run = await api(`actions/runs/${receipt.workerRunId}`);
    if (request.intent && !request.recovery && receipt.intent === request.intent) {
      if (run.path !== stagePath(workerFor(receipt)) || String(run.id) !== String(receipt.workerRunId) || run.repository?.full_name !== repository || run.head_sha !== request.workflowRevision) throw Error('Dispatch worker identity changed');
      if (run.status !== 'completed' || receipt.status === 'completed' && run.conclusion === 'success') equivalent = { send: false, comment, receipt, state: run.status !== 'completed' ? 'queued' : 'completed', reason: run.status !== 'completed' ? 'Equivalent work already has a queued or running execution.' : 'Equivalent work already completed; follow its retained result.' };
      else if (!['blocked', 'waiting', 'failed', 'cancelled'].includes(receipt.status)) throw Error('Previous dispatch outcome is uncertain; reconcile it before requesting another');
    }
    if (equivalent?.receipt === receipt) continue;
    if (run.path !== stagePath(workerFor(receipt)) || run.status !== 'completed' && request.queue !== true) throw Error('A stage execution is still pending or running');
  }
  if (equivalent) return equivalent;
  const receipt = { schemaVersion: 1, ...(request.client ? { clientKey: request.client.key, clientPayloadDigest: request.client.payloadDigest } : {}), ...(request.intent ? { intent: request.intent } : {}), stage: request.stage, ...(request.recovery ? { recovery: request.recovery, issue: request.issue } : {}), ...(request.worker ? { worker: request.worker } : {}), ...(request.feedbackKey ? { feedbackKey: request.feedbackKey } : {}), ...(request.epicKey ? { epicKey: request.epicKey } : {}), status: 'requested', ...(request.eventRunId ? { eventRunId: request.eventRunId } : {}), id: request.id, digest: digest(JSON.stringify(request)), routerRunId: request.routerRunId, routerAttempt: request.routerAttempt, workerRunId: null };
  const comment = await api(`issues/${request.issue}/comments`, 'POST', { body: dispatchReceiptBody(repository, receipt) });
  return { send: true, comment, receipt };
}

export async function sendDispatch(api, repository, request, commentId) {
  const receipt = readDispatchReceipt(await api(`issues/comments/${commentId}`), repository, request.issue);
  if (receipt.id !== request.id || receipt.digest !== digest(JSON.stringify(request))) throw Error('Dispatch request changed');
  if (receipt.workerRunId) return;
  // Never retry this POST automatically: its response can be lost after admission.
  const parent = epicLeaseParent(request);
  return api(`actions/workflows/lighthouse-sdlc-${workerFor(request)}.lock.yml/dispatches`, 'POST', { ref: request.ref, inputs: { issue: String(request.issue), 'dispatch-request': String(commentId), ...(parent ? { 'epic-parent': String(parent) } : {}), ...(workerFor(request) === 'apply-product-change' ? { 'pull-request': String(request.productApproval.pullRequest), head: request.productApproval.head } : {}) } });
}

export function epicLeaseParent(request) {
  if (request.epic === undefined) return null;
  const epic = request.epic;
  if (!epic || !Number.isSafeInteger(epic.parent) || epic.parent < 1 || epic.parent === request.issue || !(['triage', 'refine', 'implement'].includes(workerFor(request)) || workerFor(request) === 'apply-review' && request.stage === 'implement') || epic.base !== `lighthouse/epic-${epic.parent}` || !hash(epic.planDigest)) throw Error('Invalid epic dispatch lease');
  return epic.parent;
}

export function checkEpicWorkerLease(request, inputs) {
  const parent = epicLeaseParent(request);
  if ((inputs?.['epic-parent'] ?? '') !== (parent ? String(parent) : '')) throw Error('Worker epic lease does not match the authenticated dispatch');
}

// Called only for a dispatch whose router identity is authenticated by the host.
export function executionModelSelection(request) {
  const input = request?.event?.inputs?.model_selection;
  if (input === undefined || input === '') return undefined;
  if (request.eventName !== 'workflow_dispatch' || request.recovery || request.handoff || request.worker || request.event.inputs.after_run || (request.event.inputs.workflow && request.event.inputs.workflow !== 'stage')) throw Error('Model selection requires a direct owner stage dispatch');
  if (typeof input !== 'string' || Buffer.byteLength(input) > 512) throw Error('Invalid execution model selection');
  let value;
  try { value = JSON.parse(input); } catch { throw Error('Invalid execution model selection JSON'); }
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('Invalid execution model selection');
  return value;
}

export function verifyDispatchOrigin(request, receipt, parent, worker, repository, owner, issue) {
  const delegatedWorker = workerFor(request) === 'apply-review' && ['propose', 'implement'].includes(request.stage) || workerFor(request) === 'product-change' && ['triage', 'refine', 'propose', 'implement'].includes(request.stage);
  const applyProductWorker = workerFor(request) === 'apply-product-change' && ['propose', 'implement'].includes(request.stage);
  if (workerFor(request) !== workerFor(receipt) || request.feedbackKey !== receipt.feedbackKey || workerFor(request) !== request.stage && !delegatedWorker && !applyProductWorker) throw Error('Dispatch worker responsibility mismatch');
  if (workerFor(request) === 'product-change') {
    const idea = request.eventName === 'workflow_dispatch' && request.event?.inputs?.workflow === 'product-change';
    const feedback = request.productFeedback && ['answer', 'request-changes'].includes(request.productFeedback.action) && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(request.productFeedback.changeName ?? '') && typeof request.productFeedback.text === 'string' && request.productFeedback.text.trim().length > 0 && request.productFeedback.text.length <= 12000 && ['issue_comment', 'pull_request_review'].includes(request.eventName);
    const parent = request.productParent && request.productParent.issue === issue && request.productParent.stage === request.stage && (request.eventName === 'workflow_run' && String(request.productParent.predecessor?.runId) === String(request.event?.workflow_run?.id) || request.eventName === 'workflow_dispatch' && request.event?.inputs?.workflow === 'product-change' && String(request.productParent.predecessor?.runId) === String(request.event.inputs.after_run));
    if (!idea && !feedback && !parent) throw Error('Product Change worker needs an authorized idea, owner feedback or authenticated parent prerequisite');
  }
  if (workerFor(request) === 'apply-product-change' && (!request.productApproval || request.productApproval.kind !== 'approval' || !hash(request.productApproval.reviewKey))) throw Error('Trusted Product Change apply requires a bound approval');
  if (JSON.stringify(request.recovery) !== JSON.stringify(receipt.recovery)) throw Error('Recovery receipt identity mismatch');
  const events = ['issues', 'issue_comment', 'pull_request_review', 'pull_request_review_comment', 'workflow_dispatch', 'workflow_run'];
  if (request.schemaVersion !== 1 || request.id !== receipt.id || request.repository !== repository || request.issue !== issue || request.stage !== (receipt.stage ?? 'implement') || !stages.includes(request.stage) || !sha(request.sourceRevision) || !sha(request.workflowRevision) || !hash(request.taskDigest) || typeof request.handoff !== 'boolean' || digest(JSON.stringify(request)) !== receipt.digest) throw Error('Dispatch artifact identity mismatch');
  const recovery = !!request.recovery;
  const originPath = recovery ? '.github/workflows/lighthouse-worker-maintenance.yml' : routerPath;
  const originEvent = recovery ? request.routerEventName : request.eventName;
  const admissionWake = recovery && request.recovery.kind === 'before-admission' && request.recovery.wake && ['workflow_run', 'workflow_dispatch'].includes(parent.event) && parent.actor?.login === 'github-actions[bot]' && parent.triggering_actor?.login === parent.actor.login;
  const reviewContinuation = request.stage === 'review' && !request.worker && !request.handoff && (request.completionRecovery?.maintenance === Number(request.event?.inputs?.after_run) || !request.completionRecovery && request.completionAuthorization?.issue === issue && request.completionAuthorization?.merge === false && sha(request.completionAuthorization?.head) && positive(request.completionAuthorization?.pr) && request.eventRunId === request.event?.inputs?.after_run);
  const continuation = !recovery && isBotContinuation(request.event, parent.event, parent.actor?.login, parent.triggering_actor?.login) && Number(request.event.inputs.issue) === issue && (reviewContinuation || request.stage === 'implement' && request.worker === 'apply-review' && request.ciRepair?.run === Number(request.event.inputs.after_run) && !request.handoff || request.stage === 'implement' && request.handoff && !request.worker && !request.feedbackKey && request.predecessor?.runId === request.event.inputs.after_run || request.worker === 'product-change' && request.productParent?.predecessor?.runId === request.event.inputs.after_run || (!request.worker || request.worker === 'apply-review' && request.productResume?.parent.review) && request.event.inputs.workflow === 'resume-product' && request.productResume?.applyRun?.runId === request.event.inputs.after_run || !request.worker && request.event.inputs.workflow === 'resume-aligned' && request.productAlignment?.alignmentRun?.runId === request.event.inputs.after_run);
  const epicTriage = !recovery && isBotEpicTriage(request.event, parent.event, parent.actor?.login, parent.triggering_actor?.login) && request.stage === 'triage' && !request.handoff && !request.worker && Number(request.event.inputs.issue) === issue && Number(request.event.inputs.epic_parent) === request.epic?.parent;
  const epicRefinement = !recovery && isBotEpicRefinement(request.event, parent.event, parent.actor?.login, parent.triggering_actor?.login) && request.stage === 'refine' && !request.handoff && !request.worker && Number(request.event.inputs.issue) === issue && Number(request.event.inputs.epic_parent) === request.epic?.parent;
  const expectedEpicKey = epicTriage ? epicTriageKey(repository, request.epic.parent, issue, request.epic.planDigest) : epicRefinement ? epicRefinementKey(repository, request.epic.parent, issue, request.epic.planDigest, request.event.inputs.epic_run) : undefined;
  if (expectedEpicKey ? request.epicKey !== expectedEpicKey || receipt.epicKey !== expectedEpicKey : request.epicKey !== undefined || receipt.epicKey !== undefined) throw Error('Epic dispatch identity is invalid');
  if (String(parent.id) !== String(receipt.routerRunId) || parent.run_attempt !== receipt.routerAttempt || request.routerRunId !== receipt.routerRunId || request.routerAttempt !== receipt.routerAttempt || parent.path !== originPath || recovery && !admissionWake && (parent.actor?.login !== owner || parent.triggering_actor?.login !== owner) || (parent.event !== 'workflow_run' && !admissionWake && !continuation && !epicTriage && !epicRefinement && (parent.actor?.login !== owner || parent.triggering_actor?.login !== owner)) || !(recovery ? ['schedule', 'workflow_dispatch', ...(request.recovery.kind === 'before-admission' ? ['workflow_run'] : [])] : events).includes(parent.event) || parent.event !== originEvent || parent.head_sha !== (request.routerRevision ?? request.workflowRevision) || parent.head_branch !== (request.routerRef ?? request.ref) || parent.repository?.full_name !== repository) throw Error('Dispatch origin is not an authorized router execution');
  if (request.client?.key !== receipt.clientKey || request.client?.payloadDigest !== receipt.clientPayloadDigest) throw Error('Client dispatch receipt binding mismatch');
  if (request.intent !== receipt.intent || request.intent !== undefined && request.intent !== dispatchIntent(request)) throw Error('Dispatch intent binding mismatch');
  executionModelSelection(request);
  const eventRunId = request.eventName === 'workflow_run' ? request.event?.workflow_run?.id : request.event?.inputs?.epic_run ?? request.event?.inputs?.after_run;
  if (String(eventRunId ?? '') !== String(receipt.eventRunId ?? '') || String(request.eventRunId ?? '') !== String(receipt.eventRunId ?? '')) throw Error('Completion event identity mismatch');
  if (worker.path !== stagePath(workerFor(request)) || worker.event !== 'workflow_dispatch' || worker.head_branch !== request.ref || worker.repository?.full_name !== repository || ![owner, 'github-actions[bot]'].includes(worker.actor?.login) || ![owner, 'github-actions[bot]'].includes(worker.triggering_actor?.login)) throw Error('Dispatch worker identity mismatch');
  if (worker.head_sha !== request.workflowRevision) {
    const error = Error('Dispatch worker identity mismatch: workflow revision changed before admission');
    if (sha(worker.head_sha)) error.code = 'workflow-revision-rejected';
    throw error;
  }
}

export async function loadDispatch(api, repository, owner, issue, commentId, worker, readArtifact = readActionsJson, depth = 0) {
  if (depth > 2) throw Error('Recovery chain exceeds its bound');
  if (!positive(commentId)) throw Error('Invalid dispatch receipt identifier');
  const comment = await api(`issues/comments/${commentId}`);
  const receipt = readDispatchReceipt(comment, repository, issue);
  const parent = await api(`actions/runs/${receipt.routerRunId}/attempts/${receipt.routerAttempt}`);
  const request = await readArtifact(api, repository, receipt.routerRunId, dispatchArtifact(receipt), 'dispatch.json');
  try { verifyDispatchOrigin(request, receipt, parent, worker, repository, owner, issue); }
  catch (error) {
    if (error.code === 'workflow-revision-rejected') error.rejection = { dispatch: { request, receipt, commentId: Number(commentId) }, parent, run: worker };
    throw error;
  }
  if (isBotContinuation(request.event, parent.event, parent.actor?.login, parent.triggering_actor?.login) && request.stage !== 'review' && !request.ciRepair && !request.completionRecovery && !request.productParent && !['resume-product', 'resume-aligned'].includes(request.event?.inputs?.workflow)) {
    const predecessor = await api(`actions/runs/${request.predecessor.runId}`);
    const next = await (await import('./stage-transition.mjs')).refinementAfterRun(api, repository, owner, { action: 'completed', workflow_run: { id: predecessor.id, head_sha: predecessor.head_sha } }, readArtifact);
    if (next?.issue !== issue || JSON.stringify(next.predecessor) !== JSON.stringify(request.predecessor)) throw Error('Bot continuation lacks an authenticated refinement');
  }
  if (request.productAlignment) {
    const run = await api(`actions/runs/${request.productAlignment.alignmentRun.runId}`);
    const observed = await (await import('./stage-transition.mjs')).productAlignmentAfterRun(api, repository, owner, { action: 'completed', workflow_run: { id: run.id, head_sha: run.head_sha } }, readArtifact);
    if (JSON.stringify(observed) !== JSON.stringify(request.productAlignment) || observed.baseRevision !== request.sourceRevision || (observed.parent.feedback?.taskDigest ?? observed.parent.taskDigest) !== request.taskDigest || observed.stage !== request.stage) throw Error('Product alignment or parent authorization changed');
  }
  if (request.productResume) {
    const apply = await api(`actions/runs/${request.productResume.applyRun.runId}`);
    const observed = await (await import('./stage-transition.mjs')).productApplyAfterRun(api, repository, owner, { action: 'completed', workflow_run: { id: apply.id, head_sha: apply.head_sha } }, readArtifact);
    if (JSON.stringify(observed) !== JSON.stringify(request.productResume) || observed.baseRevision !== request.sourceRevision || (observed.parent.feedback?.taskDigest ?? observed.parent.taskDigest) !== request.taskDigest) throw Error('Applied product prerequisite or parent authorization changed');
  }
  if (request.productParent) {
    const parentRun = await api(`actions/runs/${request.productParent.predecessor.runId}`);
    const observed = await (await import('./stage-transition.mjs')).productGapAfterRun(api, repository, owner, { action: 'completed', workflow_run: { id: parentRun.id, head_sha: parentRun.head_sha } }, readArtifact);
    if (JSON.stringify(observed) !== JSON.stringify(request.productParent) || observed.baseRevision !== request.sourceRevision || observed.taskDigest !== request.taskDigest) throw Error('Product prerequisite or parent authorization changed');
  }
  if (isBotEpicTriage(request.event, parent.event, parent.actor?.login, parent.triggering_actor?.login)) {
    const verified = await (await import('./epic-dispatch.mjs')).verifyEpicTriageOrigin(api, { repository, owner, child: issue, parent: Number(request.event.inputs.epic_parent), runId: request.event.inputs.epic_run }, { readArtifact });
    if (!isDeepStrictEqual(verified.current, request.epic)) throw Error('Epic triage authority changed');
  }
  if (isBotEpicRefinement(request.event, parent.event, parent.actor?.login, parent.triggering_actor?.login)) {
    const verified = await (await import('./epic-dispatch.mjs')).verifyEpicRefinementOrigin(api, { repository, owner, child: issue, parent: Number(request.event.inputs.epic_parent), runId: request.event.inputs.epic_run }, { readArtifact });
    const { baseSha, ...epic } = request.epic;
    if (baseSha !== undefined && !sha(baseSha) || !isDeepStrictEqual(verified.current.epic, epic) || verified.current.taskDigest !== request.taskDigest) throw Error('Epic refinement authority changed');
  }
  if (request.ciRepair && isBotContinuation(request.event, parent.event, parent.actor?.login, parent.triggering_actor?.login)) {
    const ci = await api(`actions/runs/${request.ciRepair.run}/attempts/${request.ciRepair.runAttempt}`);
    const config = await api(`contents/.lighthouse/github.json?ref=${request.sourceRevision}`);
    const profile = JSON.parse(Buffer.from(config.content, 'base64').toString());
    if (ci.status !== 'completed' || ci.conclusion !== 'failure' || ci.head_sha !== request.ciRepair.head || ci.repository?.full_name !== repository || !profile.completion?.postMergeWorkflows?.some(name => ci.path === `.github/workflows/${name}`)) throw Error('Bot CI continuation lacks its original adopted failed attempt');
  }
  if (!request.recovery && request.stage === 'review' && !request.completionRecovery && isBotContinuation(request.event, parent.event, parent.actor?.login, parent.triggering_actor?.login)) {
    const run = await api(`actions/runs/${request.event.inputs.after_run}`);
    const next = await (await import('./delivery-events.mjs')).deliveryAfterChecks(api, repository, owner, { action: 'completed', workflow_run: { id: run.id, head_sha: run.head_sha } });
    const { stage, ...authorization } = next ?? {};
    if (stage !== 'review' || JSON.stringify(authorization) !== JSON.stringify(request.completionAuthorization)) throw Error('Bot review continuation lacks authenticated post-merge CI');
  }
  if (request.completionRecovery) {
    const origin = await api(`actions/runs/${request.completionRecovery.maintenance}`);
    const verified = await (await import('./completion-recovery.mjs')).recoveredCompletionEvent(api, repository, owner, origin, issue, readArtifact);
    if (request.stage !== 'review' || JSON.stringify(verified.completionRecovery) !== JSON.stringify(request.completionRecovery)) throw Error('Recovered completion authorization changed');
  }
  const dispatch = { request, receipt, commentId: Number(commentId) };
  if (request.recovery) await (await import('./worker-recovery.mjs')).verifyRecoveryOrigin(api, repository, owner, dispatch, parent, readArtifact, depth);
  return dispatch;
}

export async function claimDispatch(api, repository, dispatch, workerId) {
  const fresh = readDispatchReceipt(await api(`issues/comments/${dispatch.commentId}`), repository, dispatch.request.issue);
  if (fresh.id !== dispatch.receipt.id || fresh.digest !== dispatch.receipt.digest) throw Error('Dispatch receipt changed before admission');
  if (fresh.workerRunId) return false;
  fresh.workerRunId = String(workerId); fresh.status = 'running';
  await api(`issues/comments/${dispatch.commentId}`, 'PATCH', { body: dispatchReceiptBody(repository, fresh) });
  dispatch.receipt = fresh;
  return true;
}

export async function checkDispatchClaim(api, repository, issue, dispatch, workerId) {
  const receipt = readDispatchReceipt(await api(`issues/comments/${dispatch.commentId}`), repository, issue);
  if (receipt.id !== dispatch.requestId || receipt.digest !== dispatch.digest || String(receipt.workerRunId) !== String(workerId)) throw Error('Dispatch admission receipt revoked or changed');
}

export async function assertCurrentDispatch(api, repository, issue, dispatch, run) {
  if (!dispatch) return;
  await checkDispatchClaim(api, repository, issue, dispatch, run);
  const comments = await issueComments(api, issue);
  if (comments.some(comment => Number(comment.id) > Number(dispatch.commentId) && comment.user?.login === 'github-actions[bot]' && comment.user.type === 'Bot' && comment.body?.includes('<!-- lighthouse-dispatch:'))) throw Error('A newer dispatch superseded this attempt');
}


// Every dispatched worker shares the literal issue concurrency key before this call.
export async function admitDispatch(api, repository, owner, env, event, readArtifact = readActionsJson) {
  const issue = Number(env.LIGHTHOUSE_ISSUE);
  if (!Number.isSafeInteger(issue) || issue < 1 || String(issue) !== env.LIGHTHOUSE_ISSUE) throw Error('Dispatch issue must be a canonical positive integer');
  const worker = await api(`actions/runs/${env.GITHUB_RUN_ID}/attempts/${env.GITHUB_RUN_ATTEMPT}`);
  let dispatch;
  try { dispatch = await loadDispatch(api, repository, owner, issue, event.inputs?.['dispatch-request'], worker, readArtifact); }
  catch (error) {
    if (error.rejection && worker.run_attempt === 1) {
      const { dispatch: rejected } = error.rejection;
      if (!rejected.receipt.workerRunId && (env.LIGHTHOUSE_WORKER ? workerFor(rejected.request) === env.LIGHTHOUSE_WORKER : rejected.request.stage === env.LIGHTHOUSE_STAGE)) {
        const fresh = readDispatchReceipt(await api(`issues/comments/${rejected.commentId}`), repository, issue);
        if (!fresh.workerRunId && fresh.digest === rejected.receipt.digest) {
          fresh.workerRunId = String(worker.id); fresh.status = 'failed';
          fresh.admissionRejected = { code: error.code, attempt: worker.run_attempt, expectedRevision: rejected.request.workflowRevision, observedRevision: worker.head_sha };
          await api(`issues/comments/${rejected.commentId}`, 'PATCH', { body: dispatchReceiptBody(repository, fresh) });
        }
      }
    }
    throw error;
  }
  checkEpicWorkerLease(dispatch.request, event.inputs);
  if (env.LIGHTHOUSE_WORKER ? workerFor(dispatch.request) !== env.LIGHTHOUSE_WORKER : dispatch.request.stage !== env.LIGHTHOUSE_STAGE) throw Error('Dispatch targets a different stage or worker');
  if (dispatch.request.recovery || dispatch.request.completionRecovery) {
    if (env.LIGHTHOUSE_RECOVERY_ENABLED !== 'true') throw Error('Automatic recovery has been disabled');
    const scope = (await import('./worker-recovery.mjs')).recoveryIssues(env.LIGHTHOUSE_MAINTENANCE_ISSUES);
    if (scope && !scope.includes(Number(issue))) throw Error('Recovery is outside the configured maintenance scope');
    if (dispatch.request.recovery) {
      const parent = await api(`actions/runs/${dispatch.receipt.routerRunId}/attempts/${dispatch.receipt.routerAttempt}`);
      const proof = await (await import('./worker-recovery.mjs')).verifyRecoveryOrigin(api, repository, owner, dispatch, parent, readArtifact, 0, true);
      if (proof) dispatch.admissionProof = proof;
    }
  }
  const admitted = await claimDispatch(api, repository, dispatch, env.GITHUB_RUN_ID);
  return { ...dispatch, admitted };
}

export async function finishDispatch(api, repository, issue, commentId, workerId, outcome) {
  if (!positive(commentId)) return;
  const receipt = readDispatchReceipt(await api(`issues/comments/${commentId}`), repository, issue);
  if (String(receipt.workerRunId) !== String(workerId)) return;
  receipt.status = outcome === 'passed' ? 'completed' : outcome === 'question' ? 'waiting' : outcome === 'blocked' ? 'blocked' : outcome === 'failed' ? 'failed' : outcome === 'cancelled' ? 'cancelled' : 'unknown';
  await api(`issues/comments/${commentId}`, 'PATCH', { body: dispatchReceiptBody(repository, receipt) });
}

// An owner can replay a completed run on a reviewed workflow branch for acceptance.
// Automated events and manual replays use the same fresh GitHub observation.
export async function completedEvent(api, event, env, wait = ms => new Promise(resolve => setTimeout(resolve, ms))) {
  if (env.GITHUB_EVENT_NAME === 'workflow_run') return event;
  const id = event.inputs?.after_run;
  if (!id) return null;
  const bot = isBotContinuation(event, env.GITHUB_EVENT_NAME, env.GITHUB_ACTOR, env.GITHUB_TRIGGERING_ACTOR);
  if (!bot && (env.GITHUB_EVENT_NAME !== 'workflow_dispatch' || env.GITHUB_ACTOR !== env.GITHUB_REPOSITORY_OWNER || env.GITHUB_TRIGGERING_ACTOR !== env.GITHUB_REPOSITORY_OWNER || !positive(id))) throw Error('Completion replay requires an owner and a run ID, or an authenticated bot continuation');
  let run = await api(`actions/runs/${id}`);
  if (event.inputs?.stage === 'review' && run.path === '.github/workflows/lighthouse-worker-maintenance.yml') {
    for (let attempt = 0; run.status !== 'completed' && attempt < 24; attempt++) { await wait(5000); run = await api(`actions/runs/${id}`); }
    if (run.status !== 'completed') throw Error('Maintenance completion timed out; inspect its original execution before replay');
    return (await import('./completion-recovery.mjs')).recoveredCompletionEvent(api, env.GITHUB_REPOSITORY, env.GITHUB_REPOSITORY_OWNER, run, Number(event.inputs.issue));
  }
  if (bot) {
    let adoptedCi = false;
    if (!['resume-product', 'resume-aligned', 'product-change'].includes(event.inputs?.workflow) && run.path !== stagePath('refine') && run.repository?.full_name === env.GITHUB_REPOSITORY && ['push', 'pull_request', 'workflow_dispatch'].includes(run.event)) {
      const metadata = await api('');
      const config = await api(`contents/.lighthouse/github.json?ref=${metadata.default_branch}`, 'GET', undefined, true);
      const profile = config ? JSON.parse(Buffer.from(config.content, 'base64').toString()) : null;
      adoptedCi = run.repository?.full_name === env.GITHUB_REPOSITORY && ['push', 'pull_request', 'workflow_dispatch'].includes(run.event) && profile?.completion?.postMergeWorkflows?.some(name => run.path === `.github/workflows/${name}`);
    }
    if (event.inputs?.stage === 'review' && !adoptedCi) throw Error('Bot review continuation must reference adopted CI or its native maintenance proof');
    if (event.inputs?.workflow === 'resume-product' ? run.path !== stagePath('apply-product-change') : event.inputs?.workflow === 'resume-aligned' ? run.path !== stagePath('product-change') : event.inputs?.workflow === 'product-change' ? !['triage', 'refine', 'propose', 'implement', 'apply-review'].some(stage => run.path === stagePath(stage)) : run.path !== stagePath('refine') && !adoptedCi) throw Error(event.inputs?.workflow === 'resume-product' ? 'Bot continuation must reference a product apply' : event.inputs?.workflow === 'resume-aligned' ? 'Bot continuation must reference a product alignment' : event.inputs?.workflow === 'product-change' ? 'Bot continuation must reference a supported parent execution' : 'Bot continuation must reference a refinement or adopted CI');
    // The publisher signals before its own workflow has finished its final jobs.
    for (let attempt = 0; run.status !== 'completed' && attempt < 24; attempt++) {
      await wait(5000); run = await api(`actions/runs/${id}`);
    }
    if (run.status !== 'completed') throw Error('Parent completion timed out; replay after the execution completes');
  }
  return { action: 'completed', workflow_run: { id: run.id, head_sha: run.head_sha } };
}
