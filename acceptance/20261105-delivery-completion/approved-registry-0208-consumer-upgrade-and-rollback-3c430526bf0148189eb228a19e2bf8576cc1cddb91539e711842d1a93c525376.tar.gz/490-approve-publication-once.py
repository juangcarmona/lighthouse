from pathlib import Path
import subprocess,json,base64,urllib.request,urllib.error,datetime
D=Path('/tmp/lighthouse-closeout');p=D/'490-final-publication-approval.json';assert not p.exists(),'Reconcile saved approval intent'
repo='repos/juangcarmona/lighthouse/';revision='650dd1533297a1d8f4877b1be97ecd48e1aeb991';run=42163171121
def api(path,body=None):
 a=['gh','api',repo+path]
 if body is not None:a+=['--method','POST','--input','-']
 return json.loads(subprocess.check_output(a,input=None if body is None else json.dumps(body).encode(),timeout=45))
r=api('actions/runs/'+str(run));assert r['head_sha']==revision and r['status']=='waiting';assert api('git/ref/heads/main')['object']['sha']==revision
for pkg,version in [('cli','0.12.41'),('sdlc','0.20.8'),('ui','0.2.0')]:
 d=json.loads(base64.b64decode(api(f'contents/src/packages/{pkg}/package.json?ref={revision}')['content']));assert d['version']==version
 if pkg=='cli':assert d['dependencies']['@juangcarmona/lighthouse-sdlc']=='0.20.8'
for n in [42162817560,42162817563]:
 c=api('actions/runs/'+str(n));assert c['head_sha']==revision and c['conclusion']=='success'
for name,v in [('lighthouse','0.12.41'),('lighthouse-sdlc','0.20.8')]:
 try:urllib.request.urlopen('https://registry.npmjs.org/@juangcarmona%2F'+name+'/'+v,timeout=30)
 except urllib.error.HTTPError as e:assert e.code==404
 else:raise RuntimeError('Version already published; reconcile')
pending=api(f'actions/runs/{run}/pending_deployments');assert len(pending)==1 and pending[0]['environment']['id']==24897005419
s={'state':'intent','approvedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':run,'source':revision,'cli':'0.12.41','sdlc':'0.20.8','ui':'0.2.0 unchanged','userAuthorization':'Apruebo publicar CLI 0.12.41 y SDLC 0.20.8','environment':24897005419};p.write_text(json.dumps(s,indent=2)+'\n')
try:s['response']=api(f'actions/runs/{run}/pending_deployments',{'environment_ids':[24897005419],'state':'approved','comment':'Owner explicitly approved publishing CLI 0.12.41 and SDLC 0.20.8 in the task conversation. UI remains 0.2.0.'});s['state']='approved'
except (OSError,subprocess.SubprocessError) as e:s.update(state='uncertain',error=type(e).__name__)
p.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s))
