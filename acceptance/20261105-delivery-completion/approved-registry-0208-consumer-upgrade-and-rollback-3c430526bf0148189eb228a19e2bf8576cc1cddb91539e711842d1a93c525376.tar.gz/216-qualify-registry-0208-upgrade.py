from pathlib import Path
import subprocess,json,hashlib,os,datetime,urllib.request
D=Path('/tmp/lighthouse-closeout');root=Path('/srv/workspaces/juangcarmona/lighthouse/consumer-registry-0208');proof=D/'216-registry-0208-upgrade-qualified.json';assert not proof.exists(),'Reconcile prior upgrade'
env=dict(os.environ);env['PATH']='/opt/bastion-ai/releases/foundation-20261010/node-v24.21.0-linux-x64/bin:'+env['PATH'];log=D/'216-registry-0208-qualification.log';log.write_text('')
s={'state':'running','root':str(root),'baseline':'9082a4fd087862b1e0692f6ebf323d2c00c66ff4','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
def save():proof.write_text(json.dumps(s,indent=2)+'\n')
def run(args,expected=0):
 p=subprocess.run(args,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 with log.open('a') as f:f.write('\n$ '+' '.join(args)+'\n'+p.stdout)
 s['commands'].append({'args':args,'exitCode':p.returncode});save();assert p.returncode==expected,p.stdout[-3000:];return p.stdout
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def tracked():return {p:h(root/p) for p in subprocess.check_output(['git','ls-files','-z'],cwd=root,text=True).split('\0') if p}
def preserved():
 for name,digest in expected.items():assert h(root/name)==digest and (root/name).stat().st_mode&0o777==modes[name],name
 assert subprocess.check_output(['git','config','--get','core.hooksPath'],cwd=root,text=True).strip()=='.consumer-hooks'
def verify():
 for args in [['npm','run','verify'],['npx','--no-install','lighthouse','verify'],['node','scripts/lighthouse-guard.mjs','verify']]:run(args)
 preserved()
def tuples():
 lock=json.loads((root/'package-lock.json').read_text())['packages'];return {n:{k:lock['node_modules/@juangcarmona/'+n][k] for k in ['version','resolved','integrity']} for n in ['lighthouse','lighthouse-sdlc','lighthouse-ui']}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==s['baseline']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert not (root/'src/packages').exists() and not (root/'.lighthouse-harness').exists()
expected=json.loads((D/'216-native-preserved-files.json').read_text());modes={name:(root/name).stat().st_mode&0o777 for name in expected};baseline=tracked();s['baselineTuple']=tuples();s['noSourceCheckout']=True;save()
try:
 registry={}
 for n,v in [('lighthouse','0.12.41'),('lighthouse-sdlc','0.20.8'),('lighthouse-ui','0.2.0')]:
  d=json.load(urllib.request.urlopen('https://registry.npmjs.org/@juangcarmona%2F'+n+'/'+v,timeout=40));assert d['version']==v;registry[n]={'version':v,**{k:d['dist'][k] for k in ['integrity','tarball']}}
 s['registry']=registry;save()
 run(['npm','install','--ignore-scripts','--prefer-online','--save-exact','@juangcarmona/lighthouse@0.12.41'])
 p=root/'lighthouse.json';m=json.loads(p.read_text());assert m['packages']['sdlc']['version']=='0.20.7';m['packages']['sdlc']['version']='0.20.8';p.write_text(json.dumps(m,indent=2)+'\n')
 before=tracked();preview=run(['npx','--no-install','lighthouse','upgrade','--scope','all','--format','json']);assert tracked()==before;s['dryRunUnchanged']=True;plan=json.loads(preview);assert plan['source']['package']['version']=='0.12.40' and plan['target']['package']['version']=='0.12.41';(D/'216-registry-0208-upgrade-preview.json').write_text(preview)
 run(['npx','--no-install','lighthouse','upgrade','--scope','all','--apply'])
 run(['node','node_modules/@juangcarmona/lighthouse-sdlc/src/install-workflows.mjs','.','package','--apply','--replace-reviewed','--with-completion','--with-product-change','--with-maintenance'])
 verify();s['targetTuple']=tuples()
 for n,d in s['targetTuple'].items():assert d['version']==registry[n]['version'] and d['integrity']==registry[n]['integrity'] and d['resolved']==registry[n]['tarball']
 workflows=list((root/'.github/workflows').glob('*'));texts=[p.read_text() for p in workflows if p.is_file()];assert not any('repository: juangcarmona/lighthouse\n' in t for t in texts);assert not any('@juangcarmona/lighthouse-sdlc@0.20.7' in t for t in texts)
 assert not (root/'.github/workflows/lighthouse-sdlc-epic.yml').exists() and not (root/'.github/workflows/lighthouse-sdlc-unattended.yml').exists()
 assert (root/'.github/workflows/ci.yml').read_bytes()==subprocess.check_output(['git','show',s['baseline']+':.github/workflows/ci.yml'],cwd=root)
 s['selectedRegistryWorkflowsOnly']=True;s['customizationsPreserved']=len(expected);s['customizationModesPreserved']=True
 stale=root/'.github/workflows/lighthouse-sdlc-router.yml';original=stale.read_bytes();stale.write_bytes(original+b'\n# consumer-owned drift sentinel\n');drift=tracked()
 rejected=run(['node','node_modules/@juangcarmona/lighthouse-sdlc/src/install-workflows.mjs','.','package','--with-completion','--with-product-change','--with-maintenance'],1)
 assert 'Existing workflow differs' in rejected and tracked()==drift;stale.write_bytes(original);s['workflowDriftRejectedWithoutWrites']=True
 run(['git','diff','--check']);run(['git','add','.']);run(['git','commit','-m','chore: qualify registry CLI 0.12.41 and SDLC 0.20.8'])
 target=run(['git','rev-parse','HEAD']).strip();s['targetCommit']=target;target_files=tracked()
 assert str(root)=='/srv/workspaces/juangcarmona/lighthouse/consumer-registry-0208'
 run(['git','reset','--hard',s['baseline']]);run(['npm','ci','--ignore-scripts']);verify();assert tracked()==baseline and tuples()==s['baselineTuple'];s['rollbackExact']=True
 run(['git','reset','--hard',target]);run(['npm','ci','--ignore-scripts']);verify();assert tracked()==target_files and tuples()==s['targetTuple'];s['restoredQualifiedTarget']=True
 assert not run(['git','status','--porcelain']).strip();s['state']='verified'
except Exception as e:s.update(state='failed',error=str(e));raise
finally:s['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({k:v for k,v in s.items() if k!='commands'}))

