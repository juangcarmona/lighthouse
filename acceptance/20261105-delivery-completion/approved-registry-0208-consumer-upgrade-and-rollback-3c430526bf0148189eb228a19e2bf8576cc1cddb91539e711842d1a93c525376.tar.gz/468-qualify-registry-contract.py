from pathlib import Path
import tempfile,subprocess,json,os,tarfile,io,shutil,hashlib
D=Path('/tmp/lighthouse-closeout');origin=Path('/srv/workspaces/juangcarmona/lighthouse/consumer-registry-0208');p=D/'468-registry-contract-qualified.json';assert not p.exists();root=Path(tempfile.mkdtemp(prefix='lighthouse-468-registry-'));env=dict(os.environ);env['PATH']='/opt/bastion-ai/releases/foundation-20261010/node-v24.21.0-linux-x64/bin:'+env['PATH'];log=D/'468-registry-contract.log';s={'state':'running','root':str(root),'classification':'Registry-installed CLI contract with a strict local GitHub label adapter; real GitHub stock preview recorded separately.','commands':[]}
def run(args,code=0):
 r=subprocess.run(args,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);log.open('a').write('\n$ '+' '.join(args)+'\n'+r.stdout);s['commands'].append({'args':args,'exitCode':r.returncode});assert r.returncode==code,r.stdout[-3000:];return r.stdout
data=subprocess.check_output(['git','archive','8df4dd4a4691fb20b8d240c3b335f104b4aff548'],cwd=origin)
with tarfile.open(fileobj=io.BytesIO(data)) as t:t.extractall(root,filter='data')
assert not (root/'node_modules').exists() and not (root/'src/packages').exists()
run(['npm','ci','--ignore-scripts']);catalog=json.loads((root/'node_modules/@juangcarmona/lighthouse-sdlc/capabilities.json').read_text());assert json.loads((root/'node_modules/@juangcarmona/lighthouse-sdlc/package.json').read_text())['version']=='0.20.8'
state=root/'local-provider.json';calls=root/'provider-writes.json';state.write_text(json.dumps([{'name':'triage','color':'8B949E','description':'consumer-owned'}]));calls.write_text('[]');binary=root/'fixture-bin';binary.mkdir();gh=binary/'gh'
gh.write_text("""#!/usr/bin/env node
import {readFileSync,writeFileSync} from 'node:fs';
const file=process.env.LH_LABEL_STATE,calls=process.env.LH_LABEL_CALLS,args=process.argv.slice(2);if(args[0]!=='api')process.exit(2);
const labels=JSON.parse(readFileSync(file));if(args[1]==='--method'&&args[2]==='POST'){
const field=n=>args.find(v=>v.startsWith(n+'='))?.slice(n.length+1)??'';
const label={name:field('name'),color:field('color'),description:field('description')};if([...label.description].length>100)throw Error('GitHub description limit');
if(labels.some(x=>x.name===label.name))throw Error('Duplicate create');labels.push(label);const writes=JSON.parse(readFileSync(calls));writes.push(label);writeFileSync(calls,JSON.stringify(writes));writeFileSync(file,JSON.stringify(labels));console.log(JSON.stringify(label));
}else console.log(JSON.stringify(labels));
""");gh.chmod(0o755);env.update(PATH=str(binary)+':'+env['PATH'],LH_LABEL_STATE=str(state),LH_LABEL_CALLS=str(calls))
cli=['npx','--no-install','lighthouse','capabilities'];flags=['--id','labels','--provider','github','--repo','juangcarmona/lighthouse-published-consumer-20261104'];new=root/'stock.plan.json';planned=json.loads(run(cli+['plan',*flags,'--plan-file',str(new),'--format','json']))
assert planned['reconciliation']['canApply'];assert all(len(x.get('description',''))<=100 for x in planned['reconciliation']['operations'])
invalid={'schemaVersion':1,'capabilities':[next(x for x in catalog['capabilities'] if x['id']=='labels')]};next(x for x in invalid['capabilities'][0]['configuration']['labels'] if x['name']=='integrate')['description']='x'*101;ip=root/'invalid.json';ip.write_text(json.dumps(invalid));bad=root/'invalid.plan.json'
blocked=json.loads(run(cli+['plan',*flags,'--input',str(ip),'--plan-file',str(bad),'--format','json'],1));assert any(x['code']=='labels.description' for x in blocked['reconciliation']['errors'])
run(cli+['apply','--plan-file',str(bad),'--authorize',blocked['authorization']['planHash']],1);assert json.loads(calls.read_text())==[]
old=json.loads((Path('/srv/workspaces/juangcarmona/lighthouse/published-consumer-216')/'.lighthouse/reconciliation/labels-final.plan.json').read_text());op=root/'actual-old.plan.json';op.write_text(json.dumps(old));out=run(cli+['apply','--plan-file',str(op),'--authorize',old['authorization']['planHash']],1);assert 'description' in out and '100' in out;assert json.loads(calls.read_text())==[]
s['invalidAndActualOldPlanZeroWrites']=True
adopted=json.loads(run(cli+['apply','--plan-file',str(new),'--authorize',planned['authorization']['planHash'],'--format','json']));assert adopted['status']=='adopted';created=len(json.loads(calls.read_text()));assert created==32;labels=json.loads(state.read_text());assert len(labels)==33 and labels[0]['description']=='consumer-owned'
replay=json.loads(run(cli+['apply','--plan-file',str(new),'--authorize',planned['authorization']['planHash'],'--format','json']));assert len(json.loads(calls.read_text()))==created and replay['reconciliation']['operations']==[]
s.update(state='verified',sdk='0.20.8',cli='0.12.41',created=created,labels=33,stockDefaultsFitGitHubLimit=True,customLabelPreserved=True,replayZeroWrites=True,lockSha256=hashlib.sha256((root/'package-lock.json').read_bytes()).hexdigest());p.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='commands'}))

