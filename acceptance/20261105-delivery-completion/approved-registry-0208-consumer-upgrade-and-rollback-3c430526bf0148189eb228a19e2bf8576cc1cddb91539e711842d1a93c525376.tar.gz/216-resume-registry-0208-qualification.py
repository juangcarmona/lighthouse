from pathlib import Path
import subprocess,json,hashlib,os,datetime,urllib.request
D=Path('/tmp/lighthouse-closeout');root=Path('/srv/workspaces/juangcarmona/lighthouse/consumer-registry-0208');proof=D/'216-registry-0208-upgrade-qualified.json'
env=dict(os.environ);env['PATH']='/opt/bastion-ai/releases/foundation-20261010/node-v24.21.0-linux-x64/bin:'+env['PATH'];log=D/'216-registry-0208-qualification.log';
s=json.loads(proof.read_text());assert s['state']=='failed' and s['error']=='AGENTS.md';s['originalOperatorFailure']='216-registry-0208-upgrade-original-branch-failure.json';s['state']='resumed';s['resolvedBranch']='chore/216-registry-0208';s.pop('error')
def save():proof.write_text(json.dumps(s,indent=2)+'\n')
def run(args,expected=0):
 p=subprocess.run(args,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 with log.open('a') as f:f.write('\n$ '+' '.join(args)+'\n'+p.stdout)
 s['commands'].append({'args':args,'exitCode':p.returncode});save();assert p.returncode==expected,p.stdout[-3000:];return p.stdout
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def tracked():return {p:h(root/p) for p in subprocess.check_output(['git','ls-files','-z'],cwd=root,text=True).split('\0') if p}
def preserved():
 for name,digest in expected.items():assert h(root/name)==digest and bool((root/name).stat().st_mode&0o100)==bool(modes[name]&0o100),name
 assert subprocess.check_output(['git','config','--get','core.hooksPath'],cwd=root,text=True).strip()=='.consumer-hooks'
def verify():
 for args in [['npm','run','verify'],['npx','--no-install','lighthouse','verify'],['node','scripts/lighthouse-guard.mjs','verify']]:run(args)
 preserved()
def tuples():
 lock=json.loads((root/'package-lock.json').read_text())['packages'];return {n:{k:lock['node_modules/@juangcarmona/'+n][k] for k in ['version','resolved','integrity']} for n in ['lighthouse','lighthouse-sdlc','lighthouse-ui']}
import tarfile,io
archive=subprocess.check_output(['git','archive',s['baseline']],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as t:
 baseline={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t.getmembers() if m.isfile()};base_modes={m.name:m.mode for m in t.getmembers() if m.isfile()}
expected=json.loads((D/'216-native-preserved-files.json').read_text());modes={name:base_modes[name] for name in expected};registry=s['registry']
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='chore/216-registry-0208'
try:
 verify();s['targetTuple']=tuples()
 for n,d in s['targetTuple'].items():assert d['version']==registry[n]['version'] and d['integrity']==registry[n]['integrity'] and d['resolved']==registry[n]['tarball']
 workflows=list((root/'.github/workflows').glob('*'));texts=[p.read_text() for p in workflows if p.is_file()];assert not any('repository: juangcarmona/lighthouse\n' in t for t in texts);assert not any('@juangcarmona/lighthouse-sdlc@0.20.7' in t for t in texts)
 assert not (root/'.github/workflows/lighthouse-sdlc-epic.yml').exists() and not (root/'.github/workflows/lighthouse-sdlc-unattended.yml').exists()
 assert (root/'.github/workflows/ci.yml').read_bytes()==subprocess.check_output(['git','show',s['baseline']+':.github/workflows/ci.yml'],cwd=root)
 s['selectedRegistryWorkflowsOnly']=True;s['customizationsPreserved']=len(expected);s['customizationModesPreserved']='Git executable modes preserved; filesystem permission masks are checkout-specific'
 stale=root/'.github/workflows/lighthouse-sdlc-router.yml';original=stale.read_bytes();stale.write_bytes(original+b'\n# consumer-owned drift sentinel\n');drift=tracked()
 rejected=run(['node','node_modules/@juangcarmona/lighthouse-sdlc/src/install-workflows.mjs','.','package','--with-completion','--with-product-change','--with-maintenance'],1)
 assert 'Existing workflow differs' in rejected and tracked()==drift;stale.write_bytes(original);s['workflowDriftRejectedWithoutWrites']=True
 run(['git','diff','--check']);run(['git','add','.']);run(['git','commit','-m','chore: qualify registry CLI 0.12.41 and SDLC 0.20.8'])
 target=run(['git','rev-parse','HEAD']).strip();s['targetCommit']=target;target_files=tracked()
 assert str(root)=='/srv/workspaces/juangcarmona/lighthouse/consumer-registry-0208'
 run(['git','reset','--hard',s['baseline']]);run(['npm','ci','--ignore-scripts']);verify();assert tracked()==baseline and tuples()==s['baselineTuple'];s['rollbackExact']=True
 run(['git','reset','--hard',target]);run(['npm','ci','--ignore-scripts']);verify();assert tracked()==target_files and tuples()==s['targetTuple'];s['restoredQualifiedTarget']=True
 assert not run(['git','status','--porcelain']).strip();s['state']='verified'
except Exception as e:s.update(state='failed',error=str(e));raise
finally:s['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps({k:v for k,v in s.items() if k!='commands'}))

