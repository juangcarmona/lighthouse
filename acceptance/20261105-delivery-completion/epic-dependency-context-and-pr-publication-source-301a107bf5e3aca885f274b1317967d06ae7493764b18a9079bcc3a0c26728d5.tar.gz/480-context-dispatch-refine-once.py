from pathlib import Path
import subprocess,json,datetime,time,sys
root=Path('/tmp/lighthouse-closeout');tag,stage=sys.argv[1:];assert tag.replace('-','').isalnum() and stage == 'refine';proof=root/f'480-context-native-child-b-{tag}.json';assert not proof.exists(),'Reconcile the retained intent; never repeat POST'
repo='repos/juangcarmona/lighthouse-serial-epic-20261105/';main='1baa746403e134c13015f0e9a9237956fd090a5f';ref='codex/480-child-refinement-runtime';workflow='365ec6773db8ae13bb24042d07b4d0418e8f1e22';harness='7cfee9f97f5de1c5f3325c6fb17e4f4f5091c9fa'
def api(path):return json.loads(subprocess.check_output(['gh','api',repo+path],timeout=40))
assert json.loads((root/'480-context-source-merge-proof.json').read_text())['state']=='verified'
assert json.loads((root/'480-context-serial-runtime-review.json').read_text())['state']=='verified'
assert api('git/ref/heads/main')['object']['sha']==main and api('git/ref/heads/'+ref)['object']['sha']==workflow
assert api('actions/runs/42148510977')['conclusion']=='success'
accepted=json.loads((root/'146-fixed-source-child-a-accepted.json').read_text());assert accepted['state']=='verified' and accepted['settingsRestored'] is True
assert api('issues/20')['state']=='closed' and api('git/ref/heads/lighthouse/epic-19')['object']['sha']==accepted['merge']
issue=api('issues/21');assert issue['state']=='open' and issue['user']['login']=='github-actions[bot]' and api('issues/21/parent')['number']==19 and not {'agent-working','human-working','future','needs-info'}&{x['name'] for x in issue['labels']}
created=datetime.datetime.now(datetime.timezone.utc);s={'state':'intent','createdAt':created.isoformat(),'repository':'juangcarmona/lighthouse-serial-epic-20261105','issue':21,'stage':stage,'defaultSourceRevision':main,'acceptedDependencyBase':accepted['merge'],'workflowRef':ref,'workflowRevision':workflow,'sourceHarness':harness,'autoImplementation':False,'reason':'Explicit owner branch-ref dispatch supplies the reviewed host-verified dependency context while keeping the original parent, main, triage, accepted A and current scope unchanged.'}
def save():proof.write_text(json.dumps(s,indent=2)+'\n')
save()
try:subprocess.run(['gh','api',repo+'actions/workflows/lighthouse-sdlc-router.yml/dispatches','--method','POST','--input','-'],input=json.dumps({'ref':ref,'inputs':{'issue':'21','stage':stage,'workflow':'stage'}}).encode(),check=True,timeout=40);s['state']='sent';save()
except (subprocess.SubprocessError,OSError) as e:s.update(state='uncertain',error=type(e).__name__);save()
for _ in range(8):
 rows=api('actions/workflows/lighthouse-sdlc-router.yml/runs?event=workflow_dispatch&per_page=10')['workflow_runs'];matches=[x for x in rows if x['head_sha']==workflow and x['actor']['login']=='juangcarmona' and x.get('display_title')=='stage #21 · juangcarmona' and datetime.datetime.fromisoformat(x['created_at'].replace('Z','+00:00'))>=created-datetime.timedelta(seconds=2)];assert len(matches)<=1
 if matches:s.update(state='observed',routerRun=matches[0]['id'],url=matches[0]['html_url']);save();print(json.dumps(s),flush=True);break
 time.sleep(4)
else:raise RuntimeError('No confirmed dispatch yet; reconcile the saved intent instead of repeating the request')
