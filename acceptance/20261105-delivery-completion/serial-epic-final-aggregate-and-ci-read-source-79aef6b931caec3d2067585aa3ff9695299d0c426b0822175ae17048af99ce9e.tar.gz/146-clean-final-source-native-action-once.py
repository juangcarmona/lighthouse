from pathlib import Path
import subprocess,json,datetime,time,sys
root=Path('/tmp/lighthouse-closeout');tag=sys.argv[1];assert tag.replace('-','').isalnum();inputs=json.loads(sys.argv[2]);assert inputs['issue']=='19';assert inputs['action'] in ['recover-publication','register-pr','ready-child','accept-child','publish-aggregate','ready-aggregate','accept-aggregate','reconcile']
p=root/f'146-clean-final-source-epic-{tag}.json';assert not p.exists(),'Reconcile the saved intent; never repeat a dispatch'
repo='repos/juangcarmona/lighthouse-serial-epic-20261105/';main='1baa746403e134c13015f0e9a9237956fd090a5f';ref='codex/480-child-refinement-runtime';workflow='e64679ae549ef7accbeee57de2d44f7d77b13aed';harness='490206bfe49b44cf02ea2dc7d2469c3961334da4'
def api(path):return json.loads(subprocess.check_output(['gh','api',repo+path],timeout=40))
assert json.loads((root/'488-summary-source-merge-proof.json').read_text())['state']=='verified'
assert json.loads((root/'146-clean-final-native-runtime-review.json').read_text())['state']=='verified'
assert api('git/ref/heads/'+ref)['object']['sha']==workflow and api('actions/runs/42159761773')['conclusion']=='success'
if inputs['action']!='accept-aggregate':assert api('git/ref/heads/main')['object']['sha']==main
assert api('actions/runs/42132617247')['conclusion']=='success' and api('issues/19')['state']=='open'
created=datetime.datetime.now(datetime.timezone.utc);s={'state':'intent','createdAt':created.isoformat(),'repository':'juangcarmona/lighthouse-serial-epic-20261105','deliverySourceRevision':main,'workflowRef':ref,'workflowRevision':workflow,'sourceHarness':harness,'inputs':inputs,'scope':'Existing case; preserve frozen delivery source, original parent/A/B/PRs and separate current checks/review/merge gates.'}
def save():p.write_text(json.dumps(s,indent=2)+'\n')
save()
try:subprocess.run(['gh','api',repo+'actions/workflows/lighthouse-sdlc-epic.yml/dispatches','--method','POST','--input','-'],input=json.dumps({'ref':ref,'inputs':inputs}).encode(),check=True,timeout=40);s['state']='sent';save()
except (subprocess.SubprocessError,OSError) as e:s.update(state='uncertain',error=type(e).__name__);save()
for _ in range(8):
 rows=api('actions/workflows/lighthouse-sdlc-epic.yml/runs?event=workflow_dispatch&per_page=10')['workflow_runs'];matches=[r for r in rows if r['actor']['login']=='juangcarmona' and r['head_sha']==workflow and datetime.datetime.fromisoformat(r['created_at'].replace('Z','+00:00'))>=created-datetime.timedelta(seconds=2)];assert len(matches)<=1
 if matches:s.update(state='observed',run=matches[0]['id'],url=matches[0]['html_url']);save();print(json.dumps(s),flush=True);break
 time.sleep(4)
else:raise RuntimeError('No confirmed dispatch yet; reconcile saved intent instead of resending')
