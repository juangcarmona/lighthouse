from pathlib import Path
import subprocess,json,datetime,time
D=Path('/tmp/lighthouse-closeout');p=D/'146-default-main-parent-acceptance-dispatch.json';assert not p.exists(),'Reconcile saved dispatch intent'
repo='repos/juangcarmona/lighthouse-serial-epic-20261105/'
def api(path):return json.loads(subprocess.check_output(['gh','api',repo+path],timeout=40))
source=json.loads((D/'490-source-merge-proof.json').read_text());adoption=json.loads((D/'490-native-adoption-merge-proof.json').read_text());aggregate=json.loads((D/'146-aggregate-normal-merge-proof.json').read_text());assert all(x['state']=='verified' for x in [source,adoption,aggregate])
head=adoption['merge'];assert api('git/ref/heads/main')['object']['sha']==head
runs=api('actions/workflows/ci.yml/runs?head_sha='+head+'&per_page=20')['workflow_runs'];ci=[r for r in runs if r['head_sha']==head and r['event']=='push' and r['head_branch']=='main' and r['status']=='completed' and r['conclusion']=='success'];assert len(ci)==1,'Need successful exact current default post-merge CI'
assert api('issues/19')['state']=='open';assert api('issues/20')['state']=='closed' and api('issues/21')['state']=='closed';assert api('pulls/26')['merged'] and api('pulls/26')['merge_commit_sha']==aggregate['merge']
variables=api('actions/variables')['variables'];assert not any(x['name']=='LIGHTHOUSE_ACCEPTANCE_HOLD_AGGREGATE' for x in variables)
created=datetime.datetime.now(datetime.timezone.utc);s={'state':'intent','createdAt':created.isoformat(),'repository':'juangcarmona/lighthouse-serial-epic-20261105','workflowRef':'main','workflowRevision':head,'sourceHarness':'848cb1e0c6cdb2ed32f5e5be22b07c4f1f593d12','postMergeCi':ci[0]['id'],'historicalDeliveryRevision':'1baa746403e134c13015f0e9a9237956fd090a5f','aggregateMerge':aggregate['merge'],'inputs':{'action':'accept-aggregate','issue':'19'}}
def save():p.write_text(json.dumps(s,indent=2)+'\n')
save()
try:subprocess.run(['gh','api',repo+'actions/workflows/lighthouse-sdlc-epic.yml/dispatches','--method','POST','--input','-'],input=json.dumps({'ref':'main','inputs':s['inputs']}).encode(),check=True,timeout=40);s['state']='sent';save()
except (OSError,subprocess.SubprocessError) as e:s.update(state='uncertain',error=type(e).__name__);save()
for _ in range(8):
 rows=api('actions/workflows/lighthouse-sdlc-epic.yml/runs?event=workflow_dispatch&per_page=10')['workflow_runs'];matches=[r for r in rows if r['actor']['login']=='juangcarmona' and r['head_sha']==head and datetime.datetime.fromisoformat(r['created_at'].replace('Z','+00:00'))>=created-datetime.timedelta(seconds=2)];assert len(matches)<=1
 if matches:s.update(state='observed',run=matches[0]['id'],url=matches[0]['html_url']);save();print(json.dumps(s),flush=True);break
 time.sleep(4)
else:raise RuntimeError('No confirmed run yet; reconcile existing intent instead of resending')
