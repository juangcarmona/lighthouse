from pathlib import Path
import json,re,subprocess
D=Path('/tmp/lighthouse-closeout'); old='e64679ae549ef7accbeee57de2d44f7d77b13aed';base='76fbee571f3b0f1ed3e8021d1a200cca7e35a241';source='848cb1e0c6cdb2ed32f5e5be22b07c4f1f593d12';previous='490206bfe49b44cf02ea2dc7d2469c3961334da4'
def git(*a):return subprocess.check_output(['git',*a],text=True)
expected=json.loads((D/'146-clean-final-native-runtime-review.json').read_text())['changedFiles']
changed=git('diff','--name-only',base).splitlines();assert sorted(changed)==sorted(expected)
assert not git('ls-files','--others','--exclude-standard').strip()
for name in changed:
 before=git('show',old+':'+name);after=Path(name).read_text();normalize=lambda s:re.sub(r'"frontmatter_hash":"[a-f0-9]{64}"','"frontmatter_hash":"normalized"',s.replace(source,previous))
 assert normalize(before)==normalize(after),name
 assert 'LIGHTHOUSE_ACCEPTANCE_HOLD_AGGREGATE' not in after and 'Hold confirmed aggregate' not in after
assert 'LIGHTHOUSE_AUTO_IMPLEMENT: false' in Path('.github/workflows/lighthouse-sdlc-router.yml').read_text()
assert Path('.github/workflows/lighthouse-sdlc-epic.yml').read_text()==Path('/srv/workspaces/juangcarmona/lighthouse/ci-workflow-read-retry/src/packages/sdlc/workflows/lighthouse-sdlc-epic.yml').read_text().replace('__LIGHTHOUSE_REF__',source)
raw=git('diff','--raw',base);assert all(line.split()[0:2]==[':100644','100644'] for line in raw.splitlines())
s={'state':'verified','base':base,'sourceHarness':source,'previousReviewedWorkflow':old,'changedFiles':changed,'result':'Exactly 16 selected workflows: source pins and owning compiler metadata only versus prior audited runtime. Application, 16 tests, plans, policy, customized files and modes equal accepted main. No fixture hold or new files; AUTO_IMPLEMENT false.'};(D/'490-native-adoption-review.json').write_text(json.dumps(s,indent=2)+'\n');(D/'490-native-adoption-reviewed.diff').write_text(git('diff',base));print(json.dumps(s))
