from pathlib import Path
import subprocess,json,datetime,time,base64,urllib.request,urllib.error
D=Path('/tmp/lighthouse-closeout');proof=D/'490-final-registry-release-dispatch.json';assert not proof.exists(),'Reconcile saved release intent'
repo='repos/juangcarmona/lighthouse/';revision='650dd1533297a1d8f4877b1be97ecd48e1aeb991'
def api(path):return json.loads(subprocess.check_output(['gh','api',repo+path],timeout=40))
assert json.loads((D/'146-final-native-aggregate-acceptance-qualified.json').read_text())['state']=='verified'
assert api('git/ref/heads/main')['object']['sha']==revision
for pkg,version in [('cli','0.12.41'),('sdlc','0.20.8'),('ui','0.2.0')]:
 data=json.loads(base64.b64decode(api(f'contents/src/packages/{pkg}/package.json?ref={revision}')['content']));assert data['version']==version
 if pkg=='cli':assert data['dependencies']['@juangcarmona/lighthouse-sdlc']=='0.20.8'
for pkg,version in [('lighthouse','0.12.41'),('lighthouse-sdlc','0.20.8')]:
 try:urllib.request.urlopen('https://registry.npmjs.org/@juangcarmona%2F'+pkg+'/'+version,timeout=30)
 except urllib.error.HTTPError as e:assert e.code==404
 else:raise RuntimeError('Version present; reconcile before publication')
checks=api(f'commits/{revision}/check-runs?per_page=100')['check_runs']
for name in ['repository','Check package contents','Exercise a clean consumer']:assert any(x['name']==name and x['conclusion']=='success' for x in checks)
runs=api('actions/workflows/release.yml/runs?event=workflow_dispatch&per_page=10')['workflow_runs'];assert all(r['status']=='completed' for r in runs),'Another protected release remains active'
created=datetime.datetime.now(datetime.timezone.utc);s={'state':'intent','createdAt':created.isoformat(),'repository':'juangcarmona/lighthouse','head':revision,'tuple':{'cli':'0.12.41','sdlc':'0.20.8','ui':'0.2.0 unchanged'},'sourceFixes':[467,468,472,473,475,478,480,483,485,488,490],'registryVersionsAbsent':True,'checks':checks,'nativeAcceptance':'146-final-native-aggregate-acceptance-qualified.json','reason':'Concrete protected publisher prepared after recovered native aggregate acceptance. No approval for this tuple has been received; npm-publish environment must remain waiting.'}
def save():proof.write_text(json.dumps(s,indent=2)+'\n')
save()
try:subprocess.run(['gh','api',repo+'actions/workflows/release.yml/dispatches','--method','POST','--input','-'],input=json.dumps({'ref':'main','inputs':{'task':'publish-current-stable'}}).encode(),check=True,timeout=40);s['state']='sent';save()
except (OSError,subprocess.SubprocessError) as e:s.update(state='uncertain',error=type(e).__name__);save()
for _ in range(8):
 rows=api('actions/workflows/release.yml/runs?event=workflow_dispatch&per_page=10')['workflow_runs'];matches=[x for x in rows if x['head_sha']==revision and x['actor']['login']=='juangcarmona' and datetime.datetime.fromisoformat(x['created_at'].replace('Z','+00:00'))>=created-datetime.timedelta(seconds=2)];assert len(matches)<=1
 if matches:s.update(state='observed',run=matches[0]['id'],url=matches[0]['html_url']);save();print(json.dumps({k:v for k,v in s.items() if k!='checks'}),flush=True);break
 time.sleep(4)
else:raise RuntimeError('No confirmed release; reconcile instead of resending')
