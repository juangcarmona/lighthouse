from pathlib import Path
import subprocess,json,re,datetime,time,io,zipfile
root=Path('/tmp/lighthouse-closeout');proof=root/'146-confirmed-aggregate-interruption.json';assert not proof.exists(),'Reconcile the existing control; do not repeat publication or cancellation'
repo='juangcarmona/lighthouse-serial-epic-20261105';main='1baa746403e134c13015f0e9a9237956fd090a5f'
def api(path,body=None,method='POST'):
 args=['gh','api','repos/'+repo+'/'+path]
 if body is not None:args+=['--method',method,'--input','-']
 raw=subprocess.check_output(args,input=None if body is None else json.dumps(body).encode(),timeout=40);return json.loads(raw) if raw.strip() else None
b=json.loads((root/'146-fixed-source-child-b-accepted.json').read_text());assert b['state']=='verified'
assert api('git/ref/heads/main')['object']['sha']==main and api('git/ref/heads/lighthouse/epic-19')['object']['sha']==b['merge']
assert api('issues/19')['state']=='open' and api('issues/20')['state']=='closed' and api('issues/21')['state']=='closed'
s={'state':'intent','repository':repo,'parent':19,'main':main,'aggregateHead':b['merge'],'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Interrupt only after a confirmed aggregate resource, linked journal and parent handoff; then reconcile the same publication without a duplicate. Never cancel an unconfirmed resource write.','cancellationReference':'https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-cancellation'}
def save():proof.write_text(json.dumps(s,indent=2)+'\n')
save();subprocess.run(['python3',str(root/'146-final-source-native-action-once.py'),'aggregate-interrupted',json.dumps({'issue':'19','action':'publish-aggregate'})],check=True,timeout=90)
origin=json.loads((root/'146-final-source-epic-aggregate-interrupted.json').read_text());run=origin['run'];s.update(state='publication-requested',run=run);save();confirmed=None
for iteration in range(180):
 comments=api('issues/19/comments?per_page=100');records=[]
 for comment in comments:
  if comment['user']['login']!='github-actions[bot]' or comment['user']['type']!='Bot':continue
  match=re.search(r'<!-- lighthouse-epic-journal:(\{[^\n]*\}) -->',comment['body'])
  if not match:continue
  record=json.loads(match[1]);receipt=record.get('receipt',{})
  if record.get('runId')==str(run) and receipt.get('correlation',{}).get('kind')=='aggregate':records.append((comment,record))
 assert len(records)<=1
 if records:
  comment,record=records[0];receipt=record['receipt'];resource=receipt.get('resource');s['lastJournalState']=receipt['state'];save()
  notice='<!-- lighthouse-epic-aggregate:'+receipt['correlation']['planDigest']+' -->'
  handoffs=[c for c in comments if c['user']['login']=='github-actions[bot]' and c['user']['type']=='Bot' and notice in c['body']]
  if receipt['state']=='linked' and resource and len(handoffs)==1:
   pr=api('pulls/'+str(resource['number']));assert pr['id']==resource['id'] and pr['user']['login']=='github-actions[bot]' and pr['head']['sha']==b['merge'] and pr['head']['ref']=='lighthouse/epic-19' and pr['base']['ref']=='main' and not pr['merged'] and pr['html_url'] in handoffs[0]['body']
   current=api('actions/runs/'+str(run))
   if current['status']=='completed':s.update(state='window-missed-no-interruption',originalConclusion=current['conclusion']);save();print(json.dumps(s));raise SystemExit(0)
   s.update(state='cancellation-intent',resource=resource,journalComment=comment['id'],confirmedRecord=record,parentHandoff=handoffs[0]['id']);save()
   try:api('actions/runs/'+str(run)+'/cancel',{},'POST');s['state']='cancellation-requested'
   except subprocess.SubprocessError:s['state']='cancellation-response-uncertain'
   save();confirmed=resource;print(json.dumps({'state':s['state'],'run':run,'pr':resource['number']}),flush=True);break
 if iteration%6==0:
  current=api('actions/runs/'+str(run))
  if current['status']=='completed':s.update(state='completed-without-controlled-interruption',originalConclusion=current['conclusion']);save();print(json.dumps(s));raise SystemExit(0)
 time.sleep(0.5 if records and records[0][1]['receipt'].get('resource') else 3)
else:raise RuntimeError('Publication observation window elapsed; preserve the original request and reconcile it without another POST')
for _ in range(60):
 current=api('actions/runs/'+str(run))
 if current['status']=='completed':break
 time.sleep(5)
else:raise RuntimeError('Original cancellation not terminal yet; retain and observe it without force-cancel or a new publication')
s['originalConclusion']=current['conclusion'];save();assert current['conclusion']=='cancelled','Control did not interrupt the original run; do not claim recovery acceptance'
artifacts=api('actions/runs/'+str(run)+'/artifacts')['artifacts'];artifact=next(x for x in artifacts if x['name']=='lighthouse-epic-journal-19-1' and not x['expired'])
raw=subprocess.check_output(['gh','api',f'repos/{repo}/actions/artifacts/{artifact["id"]}/zip'],timeout=60);(root/'146-interrupted-aggregate-journal.zip').write_bytes(raw)
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 assert z.testzip() is None;journal=json.loads(z.read('journal.json'))
entry=journal['entries'][s['confirmedRecord']['key']];assert entry['commentId']==s['journalComment'] and entry['receipt']['resource']==confirmed and entry['receipt']['state']=='linked'
remote=api('issues/comments/'+str(s['journalComment']));record=json.loads(re.search(r'<!-- lighthouse-epic-journal:(\{[^\n]*\}) -->',remote['body'])[1]);assert record['receipt']==entry['receipt']
assert api('git/ref/heads/main')['object']['sha']==main and api('issues/19')['state']=='open'
s.update(state='verified-controlled-interruption',retainedReceipt=entry['receipt'],artifact=artifact['id'],claim='Original workflow cancelled after confirmed publication and retained matching linked journal; native resumption and no-duplicate proof still required.');save();print(json.dumps({'state':s['state'],'run':run,'pr':confirmed['number']}),flush=True)
