from pathlib import Path
import json,subprocess,zipfile,io
D=Path('/tmp/lighthouse-closeout');repo='repos/juangcarmona/lighthouse-serial-epic-20261105/'
def api(path):return json.loads(subprocess.check_output(['gh','api',repo+path],timeout=45))
s=json.loads((D/'146-default-main-parent-acceptance-dispatch.json').read_text());r=api('actions/runs/'+str(s['run']));cb=api('actions/runs/42162992014')
assert r['status']==cb['status']=='completed' and r['conclusion']==cb['conclusion']=='success';assert r['head_sha']==cb['head_sha']==s['workflowRevision'] and r['head_branch']==cb['head_branch']=='main';assert cb['event']=='workflow_run' and cb['path']=='.github/workflows/lighthouse-sdlc-router.yml'
for path,name in [('actions/artifacts/13477502864/zip','146-default-main-accepted-action.zip'),('actions/runs/'+str(s['run'])+'/logs','146-default-main-parent-acceptance-original-logs.zip'),('actions/runs/42162992014/logs','146-default-main-acceptance-callback-original-logs.zip')]:
 p=D/name
 if not p.exists():
  data=subprocess.check_output(['gh','api',repo+path],timeout=50);assert zipfile.is_zipfile(io.BytesIO(data));p.write_bytes(data)
z=zipfile.ZipFile(D/'146-default-main-accepted-action.zip');result=json.loads(z.read('result.json'));assert result['action']=='accept-aggregate' and result['workflowRevision']==s['workflowRevision'] and result['workflowRef']=='main' and result['runId']==str(s['run']) and result['result']=={'status':'accepted','pullRequest':26,'parent':'closed'}
z=zipfile.ZipFile(D/'146-default-main-acceptance-callback-original-logs.zip');text='\n'.join(z.read(x).decode(errors='replace') for x in z.namelist());assert 'epic-dispatch.mjs' in text and 'settled' in text
(D/'146-default-main-acceptance-callback-original.log').write_text(text)
parent=api('issues/19');children=api('issues/19/sub_issues');assert parent['state']=='closed' and parent['state_reason']=='completed';assert sorted(x['number'] for x in children)==[20,21] and all(x['state']=='closed' for x in children)
assert api('git/ref/heads/main')['object']['sha']==s['workflowRevision'];assert api('git/ref/heads/lighthouse/epic-19')['object']['sha']=='cccdc5d688a15c00d828e9a6eb98714e849f1f1d'
prs=api('pulls?state=all&head=juangcarmona%3Alighthouse%2Fepic-19&base=main&per_page=100');assert len(prs)==1 and prs[0]['number']==26 and prs[0]['merged_at']
for n in [22,24]:assert api('pulls/'+str(n))['merged']
s.update(state='verified',parentClosedAt=parent['closed_at'],children=[20,21],aggregatePr=26,aggregatePrCount=1,callback={'run':cb['id'],'conclusion':cb['conclusion'],'url':cb['html_url'],'result':'Authenticated typed action settled; no child stage dispatched'},result=result['result'],classification='Recovered native serial dependent-child delivery using source-pinned workflows and controllers. Consumer package metadata remains CLI 0.12.38 / SDK 0.20.5; these package versions do not identify the executing source-pinned harness. This is not uninterrupted delivery or final registry-only consumer qualification.');(D/'146-final-native-aggregate-acceptance-qualified.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s))
