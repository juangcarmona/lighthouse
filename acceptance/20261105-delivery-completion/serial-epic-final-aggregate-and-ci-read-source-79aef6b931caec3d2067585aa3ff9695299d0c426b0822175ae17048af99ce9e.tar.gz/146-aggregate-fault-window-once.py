from pathlib import Path
import json,subprocess,datetime
r=Path('/tmp/lighthouse-closeout');p=r/'146-aggregate-fault-variable.json';assert not p.exists(),'Reconcile the saved variable intent before changing it'
repo='repos/juangcarmona/lighthouse-serial-epic-20261105/';name='LIGHTHOUSE_ACCEPTANCE_HOLD_AGGREGATE'
def api(path,body=None,method='POST',optional=False):
 args=['gh','api',repo+path]
 if body is not None:args+=['--method',method,'--input','-']
 result=subprocess.run(args,input=None if body is None else json.dumps(body).encode(),capture_output=True,timeout=40)
 data=json.loads(result.stdout) if result.stdout.strip() else None
 if optional and result.returncode and str(data.get('status'))=='404':return None
 if result.returncode:raise RuntimeError('GitHub variable operation failed; reconcile the saved intent')
 return data
old=api('actions/variables/'+name,optional=True);assert old is None or old['value']=='false'
assert api('actions/runs/42159141881')['conclusion']=='success'
assert api('git/ref/heads/main')['object']['sha']=='1baa746403e134c13015f0e9a9237956fd090a5f'
s={'state':'intent','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':'juangcarmona/lighthouse-serial-epic-20261105','name':name,'before':None if old is None else old['value'],'scope':'Fixture-only45-second pause after confirmed aggregate publication, before workflow acknowledgement. Restore variable regardless of control outcome; remove the hold step before default adoption.'}
def save():p.write_text(json.dumps(s,indent=2)+'\n')
save()
try:
 api('actions/variables' if old is None else 'actions/variables/'+name,{'name':name,'value':'true'},'POST' if old is None else 'PATCH')
 assert api('actions/variables/'+name)['value']=='true';s['state']='armed';save()
 subprocess.run(['python3',str(r/'146-interrupt-confirmed-aggregate-final.py')],check=True)
finally:
 s['state']='restore-intent';save()
 if old is None:api('actions/variables/'+name,{},'DELETE');assert api('actions/variables/'+name,optional=True) is None
 else:api('actions/variables/'+name,{'name':name,'value':'false'},'PATCH');assert api('actions/variables/'+name)['value']=='false'
 s.update(state='restored',restored=True);save();print(json.dumps({'state':s['state'],'variableRestored':True}),flush=True)
