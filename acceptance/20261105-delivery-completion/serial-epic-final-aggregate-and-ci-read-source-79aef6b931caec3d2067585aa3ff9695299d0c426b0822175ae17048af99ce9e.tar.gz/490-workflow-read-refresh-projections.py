import pathlib,re,subprocess,sys,os
root=pathlib.Path(sys.argv[1]).resolve();revision=sys.argv[2]
assert re.fullmatch('[a-f0-9]{40}',revision)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==revision
maintenance=root/'.github/workflows/lighthouse-worker-maintenance.yml'
original=maintenance.read_text()
pathlib.Path('/tmp/lighthouse-closeout/490-workflow-read-maintenance-before.yml').write_text(original)
inputs=original[original.index('      recovery_pr:'):original.index('permissions:\n')]
job=original[original.index('  recover-product-publication:\n'):original.index('  scan:\n')]
env=os.environ.copy();env['PATH']='/opt/bastion-ai/releases/foundation-20261010/node-v24.21.0-linux-x64/bin:'+env['PATH']
subprocess.run(['node','src/packages/sdlc/src/install-workflows.mjs','.',revision,'--apply','--replace-reviewed','--with-unattended','--with-product-change','--with-maintenance','--with-epic'],cwd=root,env=env,check=True)
s=maintenance.read_text();assert 'recovery_pr:' not in s and '  recover-product-publication:' not in s
s=s.replace('permissions:\n',inputs+'permissions:\n',1).replace('jobs:\n','jobs:\n'+job,1)
needle="    if: vars.LIGHTHOUSE_AUTOMATION_ENABLED == 'true' && vars.LIGHTHOUSE_MAINTENANCE_ENABLED == 'true' && github.actor == github.repository_owner"
assert s.count(needle)==1
s=s.replace(needle,"    if: inputs.recovery_pr == '' && vars.LIGHTHOUSE_AUTOMATION_ENABLED == 'true' && vars.LIGHTHOUSE_MAINTENANCE_ENABLED == 'true' && github.actor == github.repository_owner")
maintenance.write_text(s)
ci=root/'.github/workflows/ci.yml';s=ci.read_text();s,n=re.subn(r'(?m)^(          ref: )[a-f0-9]{40}$',lambda m:m[1]+revision,s);assert n==2,n;ci.write_text(s)
print('Regenerated root workflows and preserved explicit product-publication recovery; both CI callback pins:',revision)
