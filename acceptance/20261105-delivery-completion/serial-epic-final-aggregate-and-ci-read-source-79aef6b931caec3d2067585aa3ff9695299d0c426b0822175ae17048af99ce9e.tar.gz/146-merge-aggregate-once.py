import json,subprocess
from pathlib import Path
D=Path('/tmp/lighthouse-closeout'); p=D/'146-aggregate-normal-merge-proof.json'
def api(path,method=None,data=None):
 a=['gh','api','repos/juangcarmona/lighthouse-serial-epic-20261105/'+path]
 if method:a+=['--method',method,'--input','-']
 return json.loads(subprocess.check_output(a,input=json.dumps(data).encode() if method else None,timeout=45))
s=json.loads((D/'146-aggregate-technical-approval.json').read_text());pr=api('pulls/26')
assert not p.exists(),'Reconcile existing merge intent'
assert pr['head']['sha']==s['head'] and pr['base']['sha']==s['base'] and not pr['draft'] and not pr['merged'] and pr['mergeable'] is True
assert api('git/ref/heads/main')['object']['sha']==s['base']
reviews=api('pulls/26/reviews?per_page=100'); owner=[r for r in reviews if r['user']['login']=='juangcarmona' and r['state'] in ['APPROVED','CHANGES_REQUESTED']];review=owner[-1]
assert review['state']=='APPROVED' and review['commit_id']==s['head'] and review['id']==5795726825
s.update(state='verified',review=review['id'],reviewUrl=review['html_url']);(D/'146-aggregate-technical-approval.json').write_text(json.dumps(s,indent=2)+'\n')
for run,sha in [(s['headCi'],s['head']),(s['candidateCi'],s['candidate'])]:
 r=api('actions/runs/'+str(run));assert r['head_sha']==sha and r['status']=='completed' and r['conclusion']=='success' and r['event']=='push' and r['path']=='.github/workflows/ci.yml'
c=api('git/commits/'+s['candidate']);assert [x['sha'] for x in c['parents']]==[s['base'],s['head']]
assert c['tree']['sha']==api('git/commits/'+s['head'])['tree']['sha']
s.update(state='intent');p.write_text(json.dumps(s,indent=2)+'\n')
try:s['response']=api('pulls/26/merge','PUT',{'sha':s['head'],'merge_method':'merge'})
except (OSError,subprocess.SubprocessError) as e:s['uncertain']=type(e).__name__
p.write_text(json.dumps(s,indent=2)+'\n');pr=api('pulls/26');assert pr['merged'] and pr['head']['sha']==s['head'];m=api('git/commits/'+pr['merge_commit_sha']);assert [x['sha'] for x in m['parents']]==[s['base'],s['head']] and m['tree']['sha']==c['tree']['sha']
assert api('git/ref/heads/main')['object']['sha']==pr['merge_commit_sha'];assert api('issues/19')['state']=='open'
s.update(state='verified',merge=pr['merge_commit_sha'],parentStillOpen=True);p.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s))
