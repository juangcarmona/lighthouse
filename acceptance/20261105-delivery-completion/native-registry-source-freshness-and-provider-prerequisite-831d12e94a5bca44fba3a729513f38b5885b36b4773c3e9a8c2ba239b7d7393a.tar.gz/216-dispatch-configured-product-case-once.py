from pathlib import Path
import subprocess,json,datetime,time,sys
D=Path('/tmp/lighthouse-closeout');tag,stage=sys.argv[1:];assert tag.replace('-','').isalnum();assert stage in ['triage','refine','implement'];p=D/f'216-product-configured-native-{tag}.json';assert not p.exists(),'Reconcile saved dispatch instead of repeating it';repo='repos/juangcarmona/lighthouse-published-consumer-20261104/';source=json.loads((D/'216-provider-integration-merge-proof.json').read_text())['merge']
def api(path):return json.loads(subprocess.check_output(['gh','api',repo+path],timeout=40))
assert json.loads((D/'216-product-scope-merge-proof.json').read_text())['state']=='verified'
assert json.loads((D/'490-approved-publication-registry-qualified.json').read_text())['state']=='verified'
assert api('git/ref/heads/main')['object']['sha']==source
ci=[r for r in api('actions/workflows/ci.yml/runs?head_sha='+source+'&per_page=10')['workflow_runs'] if r['head_sha']==source and r['head_branch']=='main' and r['event']=='push' and r['conclusion']=='success'];assert len(ci)==1,'Wait for exact current main CI'
issue=api('issues/12');assert issue['state']=='open' and issue['user']['login']=='juangcarmona' and not {'agent-working','human-working','future','needs-info'}&{x['name'] for x in issue['labels']}
flags={v['name']:v['value'] for v in api('actions/variables')['variables']};assert all(flags.get(n)=='true' for n in ['LIGHTHOUSE_AUTOMATION_ENABLED','LIGHTHOUSE_MAINTENANCE_ENABLED','LIGHTHOUSE_RECOVERY_ENABLED']);assert flags.get('LIGHTHOUSE_ACCEPTANCE_MISSING_RUNTIME')!='true'
created=datetime.datetime.now(datetime.timezone.utc);s={'state':'intent','createdAt':created.isoformat(),'repository':'juangcarmona/lighthouse-published-consumer-20261104','issue':12,'stage':stage,'sourceRevision':source,'postMergeCi':ci[0]['id'],'cli':'0.12.41','harnessPackage':'@juangcarmona/lighthouse-sdlc@0.20.8','scope':'Formalize existing behavior through a new separately approved ProductShape proposal, then behavior-preserving private refactor; no transfer of old approval.'}
def save():p.write_text(json.dumps(s,indent=2)+'\n')
save()
try:subprocess.run(['gh','api',repo+'actions/workflows/lighthouse-sdlc-router.yml/dispatches','--method','POST','--input','-'],input=json.dumps({'ref':'main','inputs':{'issue':'12','stage':stage,'workflow':'stage'}}).encode(),check=True,timeout=40);s['state']='sent';save()
except (OSError,subprocess.SubprocessError) as e:s.update(state='uncertain',error=type(e).__name__);save()
for _ in range(10):
 rows=api('actions/workflows/lighthouse-sdlc-router.yml/runs?event=workflow_dispatch&per_page=10')['workflow_runs'];matches=[a for a in rows if a['head_sha']==source and a['actor']['login']=='juangcarmona' and a.get('display_title')=='stage #12 · juangcarmona' and datetime.datetime.fromisoformat(a['created_at'].replace('Z','+00:00'))>=created-datetime.timedelta(seconds=2)];assert len(matches)<=1
 if matches:s.update(state='observed',routerRun=matches[0]['id'],url=matches[0]['html_url']);save();print(json.dumps(s),flush=True);break
 time.sleep(4)
else:raise RuntimeError('No confirmed dispatch; reconcile retained intent, never repeat POST')

