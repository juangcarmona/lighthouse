from pathlib import Path
import subprocess,json,time,zipfile,io
D=Path('/tmp/lighthouse-closeout');repo='repos/juangcarmona/lighthouse-published-consumer-20261104/';run=42169958247;proof=D/'216-product-case-fresh-triage-qualified.json';assert not proof.exists(),'Reconcile existing handoff'
def api(path):return json.loads(subprocess.check_output(['gh','api',repo+path],timeout=40))
for _ in range(120):
 r=api('actions/runs/'+str(run))
 if r['status']=='completed':break
 time.sleep(5)
else:raise RuntimeError('Fresh triage still active; no dispatch sent')
assert r['conclusion']=='success' and r['head_sha']=='09aff4f6efb12d1f5b47a91812f59a442d047696','No new refinement after a failed or mismatched triage'
inventory=api('actions/runs/'+str(run)+'/artifacts')['artifacts'];records={}
for kind in ['input','result']:
 a=[x for x in inventory if x['name']==f'lighthouse-{kind}-12-1' and not x['expired']];assert len(a)==1
 data=subprocess.check_output(['gh','api',repo+'actions/artifacts/'+str(a[0]['id'])+'/zip'],timeout=45);z=zipfile.ZipFile(io.BytesIO(data));(D/f'216-product-case-fresh-triage-{kind}.zip').write_bytes(data)
 for f in ['request.json','envelope.json','runtime.json']:
  if f in z.namelist():records[f]=json.loads(z.read(f))
q,e,t=records['request.json'],records['envelope.json'],records['runtime.json'];assert q['issue']==12 and q['sourceRevision']==r['head_sha'] and q['stage']=='triage';assert e['result']['status']=='passed' and e['result']['gate']=='triaged';assert t['distribution']['type']=='package' and t['distribution']['integrity']=='sha512-520yCIuOgIv2lKLaAAcSEYTRY21bKibOIzeWxjCF2NxDiT+swtQ8LVNMdzPsAXRrSY8rGLyu+Ffd9455pSTnSg==';assert t['cleanup']['status']=='clean' and t['cleanup']['remaining']==[]
s={'state':'verified','run':run,'source':q['sourceRevision'],'status':'passed','gate':'triaged','runtimePackage':t['package'],'distribution':t['distribution'],'cleanup':'clean','removedResources':len(t['cleanup']['resources']),'scope':'Fresh native triage after the real stale-source rejection; same owner issue12, no product approval or implementation grant inferred.'};proof.write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s),flush=True)
subprocess.run(['python3',str(D/'216-dispatch-current-product-case-once.py'),'refine','refine'],check=True)

