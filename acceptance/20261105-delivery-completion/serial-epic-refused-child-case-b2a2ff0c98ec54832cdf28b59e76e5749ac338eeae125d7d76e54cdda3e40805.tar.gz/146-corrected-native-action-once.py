from pathlib import Path
import subprocess,json,datetime,time,sys
root=Path('/tmp/lighthouse-closeout');tag=sys.argv[1];assert tag.replace('-','').isalnum();inputs=json.loads(sys.argv[2]);assert inputs['issue']=='14';assert inputs['action'] in ['reconcile','refine-child','register-pr','ready-child','accept-child','publish-aggregate','ready-aggregate','accept-aggregate'];p=root/f'146-corrected-native-{tag}.json';assert not p.exists(),'Reconcile retained action before any repeat'
repo='repos/juangcarmona/lighthouse-serial-epic-20261105/';source='274ba4affe6ec2ca5caae4ac18e589dee002e277'
def api(path):return json.loads(subprocess.check_output(['gh','api',repo+path],timeout=40))
if inputs['action']!='accept-aggregate':assert api('git/ref/heads/main')['object']['sha']==source
assert api('actions/runs/42115338833')['conclusion']=='success'
created=datetime.datetime.now(datetime.timezone.utc);s={'state':'intent','createdAt':created.isoformat(),'repository':'juangcarmona/lighthouse-serial-epic-20261105','sourceRevision':source,'inputs':inputs}
def save():p.write_text(json.dumps(s,indent=2)+'\n')
save()
try:subprocess.run(['gh','api',repo+'actions/workflows/lighthouse-sdlc-epic.yml/dispatches','--method','POST','--input','-'],input=json.dumps({'ref':'main','inputs':inputs}).encode(),check=True,timeout=40);s['state']='sent';save()
except (subprocess.SubprocessError,OSError) as e:s.update(state='uncertain',error=type(e).__name__);save()
for _ in range(12):
 rows=api('actions/workflows/lighthouse-sdlc-epic.yml/runs?event=workflow_dispatch&per_page=10')['workflow_runs'];matches=[r for r in rows if r['actor']['login']=='juangcarmona' and datetime.datetime.fromisoformat(r['created_at'].replace('Z','+00:00'))>=created-datetime.timedelta(seconds=2)];assert len(matches)<=1
 if matches:s.update(state='observed',run=matches[0]['id'],url=matches[0]['html_url']);save();print(json.dumps(s),flush=True);break
 time.sleep(5)
else:raise RuntimeError('No confirmed action yet; reconcile intent, do not repeat POST')
