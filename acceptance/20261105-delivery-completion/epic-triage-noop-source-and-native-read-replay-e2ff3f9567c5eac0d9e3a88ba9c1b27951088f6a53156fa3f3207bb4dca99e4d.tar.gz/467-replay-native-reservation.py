from pathlib import Path
import subprocess,json,os
r=Path('/tmp/lighthouse-closeout');d=r/'467-native-reservation-replay';d.mkdir(exist_ok=False)
repo='juangcarmona/lighthouse-serial-epic-20261105';revision='274ba4affe6ec2ca5caae4ac18e589dee002e277'
(d/'event.json').write_text(json.dumps({'inputs':{'issue':'16','stage':'triage','workflow':'stage','epic_parent':'14','epic_run':'42116331921'}}))
(d/'read-only-fetch.mjs').write_text('''import {appendFileSync} from 'node:fs';
const original=globalThis.fetch;
globalThis.fetch=async(url,options)=>{
 const method=options?.method??'GET';if(method!=='GET')throw Error('Read-only qualification forbids '+method);
 const response=await original(url,options);
 appendFileSync(process.env.LIGHTHOUSE_REPLAY_READS,JSON.stringify({path:new URL(url).pathname,status:response.status})+'\\n');
 if(new URL(url).pathname==='/repos/juangcarmona/lighthouse-serial-epic-20261105/issues/16'&&response.ok){const issue=await response.json();if(!issue.labels.some(l=>l.name==='agent-working'))issue.labels.push({name:'agent-working'});return Response.json(issue);}
 return response;
};''')
env=dict(os.environ);env.update({'PATH':'/opt/bastion-ai/releases/foundation-20261010/node-v24.21.0-linux-x64/bin:'+env['PATH'],'GH_TOKEN':subprocess.check_output(['gh','auth','token']).decode().strip(),'GITHUB_REPOSITORY':repo,'GITHUB_REPOSITORY_OWNER':'juangcarmona','GITHUB_ACTOR':'github-actions[bot]','GITHUB_TRIGGERING_ACTOR':'github-actions[bot]','GITHUB_EVENT_NAME':'workflow_dispatch','GITHUB_RUN_ID':'42116510695','GITHUB_RUN_ATTEMPT':'1','GITHUB_SHA':revision,'GITHUB_REF':'refs/heads/main','GITHUB_EVENT_PATH':str(d/'event.json'),'RUNNER_TEMP':str(d),'LIGHTHOUSE_ISSUE':'16','LIGHTHOUSE_STAGE':'triage','LIGHTHOUSE_EPIC_PARENT':'14','LIGHTHOUSE_EPIC_ENABLED':'true','LIGHTHOUSE_EPIC_CAPACITY':'1','LIGHTHOUSE_ENABLED_STAGES':'triage,refine,propose,implement,integrate,review','LIGHTHOUSE_AUTO_IMPLEMENT':'false','LIGHTHOUSE_COMPLETION_ENABLED':'true','LIGHTHOUSE_PRODUCT_CHANGE_ENABLED':'false'})
trials=[]
for label,module in [('published-before','/srv/workspaces/juangcarmona/lighthouse/published-consumer-216/node_modules/@juangcarmona/lighthouse-sdlc/src/issue-actions.mjs'),('fixed-source','/srv/workspaces/juangcarmona/lighthouse/epic-triage-noop/src/packages/sdlc/src/issue-actions.mjs')]:
 env.update({'GITHUB_OUTPUT':str(d/(label+'-outputs')),'GITHUB_STEP_SUMMARY':str(d/(label+'-summary')),'LIGHTHOUSE_REPLAY_READS':str(d/(label+'-reads.jsonl'))})
 with (d/(label+'.log')).open('w') as f:a=subprocess.run(['node','--import',str(d/'read-only-fetch.mjs'),module,'dispatch-prepare'],env=env,cwd='/srv/workspaces/juangcarmona/lighthouse/epic-triage-noop',stdout=f,stderr=subprocess.STDOUT,timeout=300)
 log=(d/(label+'.log')).read_text();trial={'label':label,'exit':a.returncode,'metadataReads':len((d/(label+'-reads.jsonl')).read_text().splitlines())};trials.append(trial)
 if label=='published-before':assert a.returncode!=0 and 'Issue not eligible for dispatch' in log,log[-1000:]
 else:assert a.returncode==0 and 'send=false' in (d/(label+'-outputs')).read_text() and 'Existing triage request' in (d/(label+'-summary')).read_text(),log[-1000:]
 print(json.dumps(trial),flush=True)
proof={'kind':'Read-only replay of actual redundant router event and retained native authority, restoring its original reservation in process; not a new native execution or write authority','originalFailedRouter':42116510695,'originalEpicReconcile':42116331921,'source':revision,'trials':trials,'effectWrites':0};(r/'467-native-reservation-replay.json').write_text(json.dumps(proof,indent=2)+'\n')
