import {appendFileSync} from 'node:fs';
const original=globalThis.fetch;
globalThis.fetch=async(url,options)=>{
 const method=options?.method??'GET';if(method!=='GET')throw Error('Read-only qualification forbids '+method);
 const response=await original(url,options);
 appendFileSync(process.env.LIGHTHOUSE_REPLAY_READS,JSON.stringify({path:new URL(url).pathname,status:response.status})+'\n');
 if(new URL(url).pathname==='/repos/juangcarmona/lighthouse-serial-epic-20261105/issues/16'&&response.ok){const issue=await response.json();if(!issue.labels.some(l=>l.name==='agent-working'))issue.labels.push({name:'agent-working'});return Response.json(issue);}
 return response;
};