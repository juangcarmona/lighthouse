import test from 'node:test';
import assert from 'node:assert/strict';
import { access, chmod, cp, lstat, mkdir, mkdtemp, readFile, readdir, rm, stat, symlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { initialReviewStatus, readGuardrailCatalog } from '../packages/cli/src/guardrails.mjs';
import { composeProfiles, readProfileCatalog } from '../packages/cli/src/profiles.mjs';
import { buildEvidenceIndex } from '../packages/sdlc/src/evidence.mjs';

const tool = new URL('../packages/cli/src/lighthouse.mjs', import.meta.url).pathname;
const sdlcPackage = JSON.parse(await readFile(new URL('../packages/sdlc/package.json', import.meta.url), 'utf8'));
const uiPackage = JSON.parse(await readFile(new URL('../packages/ui/package.json', import.meta.url), 'utf8'));
const manifest = {
  schemaVersion: 1,
  baseline: '0.1.0',
  product: 'fixture',
  profiles: [],
  integrations: { productShape: null, arcShape: null },
  managed: ['LIGHTHOUSE.md'],
  repository: {
    layout: ['src', 'docs', 'infra', 'scripts'],
    publicSite: { enabled: false },
    conventions: {
      commits: 'conventional',
      branchPattern: '^(feat|fix|docs|refactor|test|chore|build|ci|perf|revert)/[1-9]\\d*-[a-z0-9]+(?:-[a-z0-9]+)*$'
    }
  }
};
async function fixture() { const dir = await mkdtemp(join(tmpdir(), 'lighthouse-test-')); await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(manifest)); return dir; }
function run(dir, command, args = [], options = {}) { return spawnSync(process.execPath, [tool, command, ...args], { cwd: dir, encoding: 'utf8', ...options, env: { ...process.env, ...options.env } }); }

for (const entry of ['legacy', 'semantic']) {
  test(`${entry} init activates installed hooks in a fresh Git repository`, async t => {
    for (const scenario of ['unset', 'local-custom', 'local-empty', 'global-custom', 'global-empty', 'non-git', 'nested', 'preview', 'conflict', ...(entry === 'semantic' ? ['unresolved'] : [])]) {
      await t.test(scenario, async () => {
        const sandbox = await mkdtemp('/tmp/opencode/lighthouse-hooks-');
        const repository = join(sandbox, 'repository');
        const dir = scenario === 'nested' ? join(repository, 'target') : repository;
        const globalConfig = join(sandbox, 'gitconfig');
        const env = {
          ...Object.fromEntries(Object.keys(process.env).filter(key => key.startsWith('GIT_')).map(key => [key, undefined])),
          GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_SYSTEM: '/dev/null', GIT_CONFIG_GLOBAL: globalConfig,
          GIT_CONFIG_COUNT: '0', GIT_CEILING_DIRECTORIES: sandbox,
        };
        const git = args => spawnSync('git', args, { cwd: repository, encoding: 'utf8', env: { ...process.env, ...env } });
        const checkedGit = args => { const result = git(args); assert.equal(result.status, 0, result.stderr); return result; };
        try {
          await mkdir(dir, { recursive: true });
          await writeFile(globalConfig, '');
          if (scenario !== 'non-git') checkedGit(['init', '--initial-branch=main']);
          const customHooks = join(sandbox, 'user-hooks');
          await mkdir(customHooks);
          await writeFile(join(customHooks, 'pre-push'), '#!/bin/sh\nexit 0\n');
          await chmod(join(customHooks, 'pre-push'), 0o755);
          if (/^(local|global)-/.test(scenario)) {
            checkedGit(['config', scenario.startsWith('global') ? '--global' : '--local', 'core.hooksPath', scenario.endsWith('empty') ? '' : customHooks]);
          }
          const planPath = join(sandbox, 'init.plan.json');
          await writeFile(planPath, JSON.stringify({
            schemaVersion: 1, product: 'Hook contract probe', intent: 'Activate installed baseline hooks.',
            application: { shape: 'unknown', stacks: [] }, profiles: [],
            openQuestions: scenario === 'unresolved' ? ['Which deployment target?'] : [],
          }));
          const args = entry === 'legacy' ? ['--name', 'Hook contract probe'] : ['--plan-file', planPath, '--apply'];
          if (scenario === 'preview') {
            if (entry === 'semantic') args.pop();
            args.push('--dry-run');
          }
          if (scenario === 'conflict') await writeFile(join(dir, 'LIGHTHOUSE.md'), 'User-owned baseline\n');
          const beforeGlobal = await readFile(globalConfig);
          const beforeConfig = scenario === 'non-git' ? null : await readFile(join(repository, '.git/config'));
          const beforeHooks = await initializationSnapshot(customHooks);
          const beforeTarget = ['preview', 'conflict', 'unresolved'].includes(scenario) ? await initializationSnapshot(dir) : null;
          const beforePath = git(['config', '--get', 'core.hooksPath']);
          if (scenario === 'unset') {
            assert.equal(beforePath.status, 1, beforePath.stderr);
            assert.equal(beforePath.stdout, '');
          }
          const initialized = run(dir, 'init', args, { env });
          assert.equal(initialized.status, ['conflict', 'unresolved'].includes(scenario) ? 1 : 0, initialized.stderr);
          if (beforeTarget) {
            assert.deepEqual(await initializationSnapshot(dir), beforeTarget);
          } else {
            for (const hook of ['commit-msg', 'pre-push']) {
              assert.equal((await stat(join(dir, '.husky', hook))).mode & 0o111, 0o111);
            }
          }
          assert.deepEqual(await readFile(globalConfig), beforeGlobal);
          assert.deepEqual(await initializationSnapshot(customHooks), beforeHooks);
          const configured = git(['config', '--get', 'core.hooksPath']);
          if (scenario === 'unset') {
            assert.deepEqual(
              { status: configured.status, value: configured.stdout.trim() },
              { status: 0, value: '.husky' },
              'Initialization must activate installed hooks by setting core.hooksPath to .husky in a fresh Git repository.',
            );
            const local = checkedGit(['config', '--local', '--get', 'core.hooksPath']);
            assert.equal(local.stdout.trim(), '.husky');
          } else {
            assert.deepEqual({ status: configured.status, value: configured.stdout }, { status: beforePath.status, value: beforePath.stdout });
            if (beforeConfig) assert.deepEqual(await readFile(join(repository, '.git/config')), beforeConfig);
            else await assert.rejects(access(join(dir, '.git')), { code: 'ENOENT' });
          }
        } finally { await rm(sandbox, { recursive: true, force: true }); }
      });
    }
  });
}

async function initializationSnapshot(dir) {
  const entries = [];
  async function visit(path = '') {
    for (const name of (await readdir(join(dir, path))).sort()) {
      const relative = join(path, name), info = await lstat(join(dir, relative));
      entries.push({ path: relative, mode: info.mode, bytes: info.isFile() ? (await readFile(join(dir, relative))).toString('base64') : null });
      if (info.isDirectory()) await visit(relative);
    }
  }
  await visit();
  return entries;
}

async function initializationPreviewFixture() {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-init-preview-'));
  const env = { GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_COUNT: '0' };
  for (const args of [['init', '--initial-branch=main'], ['config', '--local', 'core.hooksPath', 'user-hooks']]) {
    const result = spawnSync('git', args, { cwd: dir, encoding: 'utf8', env: { ...process.env, ...env } });
    assert.equal(result.status, 0, result.stderr);
  }
  for (const file of ['.product/sentinel.json', 'docs/architecture/sentinel.md', 'user-hooks/pre-commit']) {
    await mkdir(join(dir, file, '..'), { recursive: true });
    await writeFile(join(dir, file), `User/provider owned: ${file}\n`);
  }
  await chmod(join(dir, 'user-hooks/pre-commit'), 0o755);
  return { dir, env };
}

function assertTextInitialization(text, report, status) {
  assert.equal(text.status, status, text.stderr);
  assert.match(text.stdout, /^Lighthouse initialization plan:\n/);
  const operations = [...text.stdout.matchAll(/^  (create) (.+)$/gm)].map(([, action, path]) => ({ path, action }));
  assert.deepEqual(operations, report.operations);
  const gaps = report.adoptionGaps.map(({ authority, nextAction }) => `  adoption gap ${authority}: ${nextAction}`);
  assert.deepEqual(text.stdout.trimEnd().split('\n').filter(line => line.startsWith('  adoption gap ')), gaps);
  assert.equal(text.stderr, report.conflicts.map(conflict => `  conflict ${conflict}\n`).join(''));
}

test('legacy init JSON previews project the local plan and preserve target bytes, modes and Git configuration', async () => {
  for (const existing of [false, true]) {
    const { dir, env } = await initializationPreviewFixture();
    try {
      const selected = {
        ...manifest,
        product: 'Published delivery consumer',
        application: { shape: 'frontend', stacks: ['react'] },
        profiles: ['visual-theme', 'react-web-platform'],
        packages: { sdlc: { name: sdlcPackage.name, version: sdlcPackage.version }, ui: { name: uiPackage.name, version: uiPackage.version } },
      };
      if (existing) await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(selected));
      for (const format of [['--format', 'json'], ['--format=json']]) {
        const before = await initializationSnapshot(dir);
        const args = ['--name', 'Published delivery consumer', '--dry-run'];
        const result = run(dir, 'init', [...args, ...format], { env });
        assert.equal(result.status, 0, result.stderr);
        assert.equal(result.stderr, '');
        const report = JSON.parse(result.stdout);
        assert.deepEqual(Object.keys(report).sort(), ['adoptionGaps', 'conflicts', 'manifest', 'operations', 'repository', 'schemaVersion', 'status']);
        assert.equal(report.schemaVersion, 1);
        assert.equal(report.status, 'ready');
        assert.equal(report.manifest.product, 'Published delivery consumer');
        assert.deepEqual(report.manifest.application, existing ? selected.application : { shape: 'unknown', stacks: [] });
        assert.deepEqual(report.manifest.profiles, existing ? selected.profiles : []);
        if (existing) assert.deepEqual(report.manifest, selected);
        assert.deepEqual(report.repository, report.manifest.repository);
        assert.deepEqual(report.conflicts, []);
        assert.deepEqual(report.adoptionGaps, existing ? [] : ['ProductShape', 'ArcShape'].map(authority => ({ authority, nextAction: 'review lighthouse authorities --dry-run, then run lighthouse authorities --apply' })));
        assert.equal(report.operations.some(operation => operation.path === 'lighthouse.json'), !existing);
        for (const path of ['src/', 'infra/.gitkeep', 'LIGHTHOUSE.md', '.lighthouse/upgrade.json', '.husky/pre-push']) {
          assert.ok(report.operations.some(operation => operation.path === path && operation.action === 'create'), path);
        }
        for (const operation of report.operations) assert.deepEqual(Object.keys(operation).sort(), ['action', 'path']);
        assertTextInitialization(run(dir, 'init', args, { env }), report, 0);
        assert.deepEqual(await initializationSnapshot(dir), before);
      }
      // Recorded authorities and public-site selection are context, not new blockers.
      if (existing) {
        for (const integrations of [{ productShape: null, arcShape: null }, { productShape: '1.0.0', arcShape: null }, { productShape: '1.0.0', arcShape: '1.0.0' }]) {
          selected.repository = { ...selected.repository, publicSite: { enabled: true } };
          selected.integrations = integrations;
          await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(selected));
          const before = await initializationSnapshot(dir);
          const result = run(dir, 'init', ['--dry-run', '--format=json'], { env });
          assert.equal(result.status, 0, result.stderr);
          const report = JSON.parse(result.stdout);
          assert.deepEqual(report.manifest, selected);
          assert.equal(report.status, 'ready');
          assert.deepEqual(report.adoptionGaps.map(gap => gap.authority), Object.entries(integrations).filter(([, version]) => version === null).map(([key]) => key === 'productShape' ? 'ProductShape' : 'ArcShape'));
          assertTextInitialization(run(dir, 'init', ['--dry-run'], { env }), report, 0);
          assert.deepEqual(await initializationSnapshot(dir), before);
        }
      }
    } finally { await rm(dir, { recursive: true, force: true }); }
  }
});

test('legacy init JSON and text conflicts preserve files and exit one', async () => {
  for (const collision of ['src', 'LIGHTHOUSE.md']) {
    const { dir, env } = await initializationPreviewFixture();
    try {
      await writeFile(join(dir, collision), 'Existing user work\n');
      const before = await initializationSnapshot(dir);
      const args = ['--name', 'Published delivery consumer', '--dry-run'];
      const result = run(dir, 'init', [...args, '--format=json'], { env });
      assert.equal(result.status, 1, result.stderr);
      assert.equal(result.stderr, '');
      const report = JSON.parse(result.stdout);
      assert.equal(report.status, 'blocked');
      assert.deepEqual(report.conflicts, [collision === 'src' ? 'src exists but is not a directory' : 'LIGHTHOUSE.md already exists; refusing to overwrite it']);
      assert.ok(report.operations.length > 0);
      assertTextInitialization(run(dir, 'init', args, { env }), report, 1);
      assert.deepEqual(await initializationSnapshot(dir), before);
    } finally { await rm(dir, { recursive: true, force: true }); }
  }
});

test('legacy init rejects every JSON apply mode before writes', async () => {
  for (const existing of [false, true]) {
    const { dir, env } = await initializationPreviewFixture();
    try {
      if (existing) await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(manifest));
      const before = await initializationSnapshot(dir);
      for (const format of [['--format', 'json'], ['--format=json']]) {
        for (const mode of [[], ['--apply'], ['--apply', '--dry-run']]) {
          const result = run(dir, 'init', ['--name', 'Published delivery consumer', ...format, ...mode], { env });
          assert.equal(result.status, 1);
          assert.equal(result.stdout, '');
          assert.match(result.stderr, /use --dry-run --format json to preview/);
          assert.match(result.stderr, /apply in text mode/);
          assert.deepEqual(await initializationSnapshot(dir), before);
        }
      }
    } finally { await rm(dir, { recursive: true, force: true }); }
  }
});

test('init creates a projection and refuses to overwrite product work', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    assert.equal(run(dir, 'verify').status, 0);
    const baseline = await readFile(join(dir, 'LIGHTHOUSE.md'), 'utf8');
    assert.match(baseline, /# fixture repository baseline/);
    assert.match(baseline, /assets\/profiles\/identity\.md/);
    for (const file of [
      'scripts/lighthouse-guard.mjs', '.husky/commit-msg', '.husky/pre-push', '.github/workflows/lighthouse.yml',
    ]) {
      await access(join(dir, file));
    }
    const guard = join(dir, 'scripts/lighthouse-guard.mjs');
    assert.equal(spawnSync(process.execPath, [guard, 'verify'], { cwd: dir }).status, 0);
    const message = join(dir, 'message.txt');
    await writeFile(message, 'feat: add a fixture\n');
    assert.equal(spawnSync(process.execPath, [guard, 'commit-msg', message], { cwd: dir }).status, 0);
    await writeFile(message, 'not conventional\n');
    assert.notEqual(spawnSync(process.execPath, [guard, 'commit-msg', message], { cwd: dir }).status, 0);
    const again = run(dir, 'init');
    assert.equal(again.status, 1);
    assert.match(again.stderr, /refusing to overwrite/);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('required repository boundaries survive committing and cloning a fresh initialization', async () => {
  for (const brownfield of [false, true]) {
    const dir = await fixture(), clone = `${dir}-clone`, outside = `${dir}-external`;
    const env = { ...process.env, GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_COUNT: '0' };
    const git = args => { const result = spawnSync('git', ['-C', dir, ...args], { encoding: 'utf8', env }); assert.equal(result.status, 0, result.stderr); };
    try {
      git(['init', '--initial-branch=main']);
      let args = [];
      if (brownfield) {
        await mkdir(join(dir, 'infra')); await writeFile(join(dir, 'infra/.gitkeep'), 'Repository-owned marker\n');
        await mkdir(outside); await symlink(outside, join(dir, 'src'));
        const planPath = join(dir, 'init.plan.json');
        await writeFile(planPath, JSON.stringify({ schemaVersion: 1, product: 'fixture', intent: 'Retain the initialized repository through Git.', application: { shape: 'unknown', stacks: [] }, profiles: [], openQuestions: [] }));
        args = ['--plan-file', planPath];
      }
      const preview = run(dir, 'init', [...args, '--dry-run'], { env });
      assert.equal(preview.status, 0, preview.stderr);
      if (!brownfield) await assert.rejects(access(join(dir, 'infra/.gitkeep')), { code: 'ENOENT' });
      const initialized = run(dir, 'init', [...args, ...(brownfield ? ['--apply'] : [])], { env });
      assert.equal(initialized.status, 0, initialized.stderr);
      if (brownfield) await assert.rejects(access(join(outside, '.gitkeep')), { code: 'ENOENT' });
      git(['add', '--all']);
      git(['-c', 'core.hooksPath=/dev/null', '-c', 'user.name=Test', '-c', 'user.email=test@example.invalid', 'commit', '-m', 'chore: initialize the consumer']);
      git(['clone', '--no-local', dir, clone]);
      const verified = run(clone, 'verify', [], { env });
      assert.equal(verified.status, 0, verified.stderr);
      if (brownfield) assert.equal(await readFile(join(clone, 'infra/.gitkeep'), 'utf8'), 'Repository-owned marker\n');
      else assert.match(preview.stdout, /infra\/\.gitkeep/);
    } finally { await rm(dir, { recursive: true, force: true }); await rm(clone, { recursive: true, force: true }); await rm(outside, { recursive: true, force: true }); }
  }
});

test('verify reports projection drift and invalid manifests', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    await writeFile(join(dir, 'LIGHTHOUSE.md'), 'product edit');
    assert.match(run(dir, 'verify').stderr, /drifted/);
    await writeFile(join(dir, 'lighthouse.json'), '{"schemaVersion":2}');
    assert.match(run(dir, 'verify').stderr, /Invalid lighthouse.json/);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('manifest cannot advertise unsupported checks or unverified managed files', async () => {
  const dir = await fixture();
  try {
    for (const changed of [
      { ...manifest, profiles: ['imaginary-profile'] },
      { ...manifest, managed: ['LIGHTHOUSE.md', 'unverified.md'] },
      { ...manifest, baseline: '99.0.0' },
      { ...manifest, integrations: { ...manifest.integrations, arcShape: 'latest' } },
      { ...manifest, integrations: { ...manifest.integrations, agenticSdlc: null } },
      { ...manifest, unexpected: true }
    ]) {
      await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(changed));
      const result = run(dir, 'verify');
      assert.equal(result.status, 1);
      assert.match(result.stderr, /Invalid lighthouse.json/);
    }
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('greenfield init creates the repository boundaries and a default manifest', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-greenfield-'));
  try {
    const result = spawnSync(process.execPath, [tool, 'init', '--name', 'Greenfield'], { cwd: dir, encoding: 'utf8' });
    assert.equal(result.status, 0, result.stderr);
    for (const directory of ['src', 'docs', 'infra', 'scripts']) assert.equal((await stat(join(dir, directory))).isDirectory(), true);
    const generated = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    assert.equal(generated.repository.publicSite.enabled, true);
    assert.deepEqual(generated.application, { shape: 'unknown', stacks: [] });
    assert.deepEqual(generated.packages.sdlc, { name: sdlcPackage.name, version: sdlcPackage.version });
    assert.match(await readFile(join(dir, '.lighthouse/sdlc.json'), 'utf8'), /"provider": "agent-host"/);
    const baseline = await readFile(join(dir, 'LIGHTHOUSE.md'), 'utf8');
    assert.match(baseline, /Repository roots/);
    assert.match(baseline, /node_modules\/@juangcarmona\/lighthouse-sdlc\/README\.md/);
    assert.match(baseline, /workflow source pin and current branch/);
    assert.equal(spawnSync(process.execPath, [tool, 'verify'], { cwd: dir }).status, 0);
    assert.match(await readFile(join(dir, '.github/workflows/lighthouse.yml'), 'utf8'), /npx --no-install lighthouse verify/);
    const aliases = JSON.parse(await readFile(join(dir, '.lighthouse/commands.json'), 'utf8'));
    assert.equal(aliases.aliases.find((item) => item.alias === '/lh:init').canonical, '/lighthouse:init');
    assert.equal(aliases.aliases.find((item) => item.alias === '/lh:control').canonical, '/lighthouse:control-plane');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('aliases reports the harness and SDLC command contracts without duplicating implementations', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-aliases-'));
  try {
    const result = run(dir, 'aliases', ['--format', 'json']);
    assert.equal(result.status, 0, result.stderr);
    const report = JSON.parse(result.stdout);
    assert.equal(report.status, 'valid');
    assert.deepEqual(report.aliases.find((item) => item.alias === '/lh:init'), {
      alias: '/lh:init',
      canonical: '/lighthouse:init',
      asset: 'skills/init/SKILL.md',
      owner: '@juangcarmona/lighthouse',
      packageVersion: JSON.parse(await readFile(new URL('../packages/cli/package.json', import.meta.url), 'utf8')).version,
    });
    assert.equal(report.aliases.find((item) => item.alias === '/lh:impl').canonical, '/lighthouse:implement');
    assert.equal(report.aliases.filter((item) => item.alias === '/lh:impl').length, 1);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('semantic init previews without a reference and applies only after explicit authorization', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-semantic-init-'));
  try {
    const planPath = join(dir, 'init-plan.json');
    await writeFile(planPath, JSON.stringify({
      schemaVersion: 1,
      product: 'Semantic Web',
      intent: 'A small authenticated web application for managing work.',
      application: { shape: 'frontend', stacks: ['react'] },
      profiles: ['visual-theme', 'react-web-platform'],
      openQuestions: [],
    }));
    const preview = run(dir, 'init', ['--plan-file', planPath, '--format', 'json']);
    assert.equal(preview.status, 0, preview.stderr);
    const report = JSON.parse(preview.stdout);
    assert.equal(report.reference, null);
    assert.deepEqual(report.application, { shape: 'frontend', stacks: ['react'] });
    assert.ok(report.operations.some((operation) => operation.path === 'lighthouse.json'));
    assert.equal(await access(join(dir, 'lighthouse.json')).then(() => true).catch(() => false), false);
    const applied = run(dir, 'init', ['--plan-file', planPath, '--apply']);
    assert.equal(applied.status, 0, applied.stderr);
    const manifest = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    assert.deepEqual(manifest.application, { shape: 'frontend', stacks: ['react'] });
    assert.deepEqual(manifest.profiles, ['visual-theme', 'react-web-platform']);
    await access(join(dir, '.agents/skills/lighthouse-init/SKILL.md'));
    assert.equal(run(dir, 'verify').status, 0);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('semantic init stops on unresolved questions before writing', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-semantic-questions-'));
  try {
    const planPath = join(dir, 'init-plan.json');
    await writeFile(planPath, JSON.stringify({
      schemaVersion: 1,
      product: 'Needs Answers',
      intent: 'A project whose deployment target is not known yet.',
      application: { shape: 'unknown', stacks: [] },
      profiles: [],
      reference: { kind: 'none' },
      openQuestions: ['Which deployment target should the project support?'],
    }));
    const preview = run(dir, 'init', ['--plan-file', planPath, '--format', 'json']);
    assert.equal(preview.status, 1);
    assert.match(preview.stdout, /Which deployment target/);
    assert.equal(await access(join(dir, 'lighthouse.json')).then(() => true).catch(() => false), false);
    const applied = run(dir, 'init', ['--plan-file', planPath, '--apply']);
    assert.equal(applied.status, 1);
    assert.match(applied.stderr, /answer the open questions/);
    assert.equal(await access(join(dir, 'lighthouse.json')).then(() => true).catch(() => false), false);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('semantic init does not require a declared reference to exist', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-semantic-reference-'));
  try {
    const planPath = join(dir, 'init-plan.json');
    await writeFile(planPath, JSON.stringify({
      schemaVersion: 1,
      product: 'Reference Optional',
      intent: 'A command-line tool with a declared but unavailable reference.',
      application: { shape: 'cli', stacks: ['node'] },
      profiles: [],
      reference: { kind: 'local', location: '/tmp/reference-that-does-not-exist', purpose: 'Compare naming only when available.' },
      openQuestions: [],
    }));
    const applied = run(dir, 'init', ['--plan-file', planPath, '--apply']);
    assert.equal(applied.status, 0, applied.stderr);
    assert.equal(JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8')).product, 'Reference Optional');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('authority initialization JSON previews report real providers and preserve text and consumer state', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-authority-preview-'));
  try {
    assert.equal(run(dir, 'init', ['--name', 'Preview']).status, 0);
    const env = { GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null', GIT_CONFIG_COUNT: '0' };
    for (const args of [['init', '--initial-branch=main'], ['config', '--local', 'core.hooksPath', 'user-hooks']]) {
      assert.equal(spawnSync('git', args, { cwd: dir, env: { ...process.env, ...env } }).status, 0);
    }
    await mkdir(join(dir, 'user-hooks'));
    await writeFile(join(dir, 'user-hooks/pre-commit'), '#!/bin/sh\nexit 0\n');
    await chmod(join(dir, 'user-hooks/pre-commit'), 0o755);
    await writeFile(join(dir, 'AGENTS.md'), '# User guidance\n');
    const before = await initializationSnapshot(dir);
    let report;
    for (const args of [['--dry-run', '--format', 'json'], ['--dry-run', '--format=json'], ['--format', 'json']]) {
      const preview = run(dir, 'authorities', args, { env });
      assert.equal(preview.status, 0, `${preview.stdout}\n${preview.stderr}`);
      assert.equal(preview.stderr, '');
      report = JSON.parse(preview.stdout);
      assert.deepEqual(Object.keys(report), ['schemaVersion', 'command', 'dryRun', 'status', 'authorities', 'apply']);
      assert.equal(report.schemaVersion, 1);
      assert.equal(report.command, 'lighthouse authorities');
      assert.equal(report.dryRun, true);
      assert.equal(report.status, 'ready');
      assert.equal(report.apply, 'lighthouse authorities --apply');
      assert.deepEqual(report.authorities.map(({ label, provider, version, command, repair }) => ({ label, provider, version, command, repair })), [
        { label: 'ProductShape', provider: '@prodshape/cli', version: '0.23.0', command: 'prodshape init --full --sdd none --gitignore --dry-run', repair: 'prodshape init --full --sdd none --gitignore' },
        { label: 'ArcShape', provider: '@arcshape/cli', version: '0.4.0', command: 'arcshape init --no-agents --dry-run', repair: 'arcshape init --no-agents --yes' },
      ]);
      for (const authority of report.authorities) {
        assert.equal(authority.preflight.ok, true);
        assert.equal(authority.preflight.status, 0);
        assert.ok(authority.preflight.output.trim());
      }
      assert.deepEqual(await initializationSnapshot(dir), before);
    }
    for (const args of [[], ['--dry-run'], ['--dry-run', '--format', 'text']]) {
      const text = run(dir, 'authorities', args, { env });
      assert.equal(text.status, 0, text.stderr);
      assert.match(text.stdout, /^Lighthouse authority plan:\n  ProductShape: initialize the full ProductShape layout without an SDD integration\n  ArcShape: initialize arc42 documentation without installing agent capabilities\n  Provider-owned files remain under provider control; Lighthouse records only exact versions\./);
      for (const authority of report.authorities) {
        assert.ok(text.stdout.includes(`\n${authority.label} preflight:\n`));
        assert.ok(`${text.stdout}${text.stderr}`.includes(authority.preflight.output.trim()));
      }
      assert.match(text.stdout, /Dry run: nothing was changed\. Re-run with --apply to apply both provider plans\.\n$/);
      assert.deepEqual(await initializationSnapshot(dir), before);
    }
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('authority JSON previews preserve unsuccessful, conflicting and missing provider outcomes and refuse apply', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-authority-outcomes-'));
  try {
    const cli = join(dir, 'cli');
    await cp(new URL('../packages/cli', import.meta.url), cli, { recursive: true });
    const consumer = join(dir, 'consumer');
    await mkdir(consumer);
    await writeFile(join(consumer, 'lighthouse.json'), JSON.stringify(manifest));
    await writeFile(join(consumer, 'LIGHTHOUSE.md'), '# Preserve customized guidance\n');
    const execute = (args) => spawnSync(process.execPath, [join(cli, 'src/lighthouse.mjs'), 'authorities', ...args], { cwd: consumer, encoding: 'utf8' });
    const providers = [['@prodshape/cli', 'prodshape'], ['@arcshape/cli', 'arcshape']];
    for (const [name, command] of providers) {
      const target = join(cli, 'node_modules', name);
      await mkdir(target, { recursive: true });
      await writeFile(join(target, 'package.json'), JSON.stringify({ name, version: '9.8.7', bin: { [command]: 'bin.cjs' } }));
      await writeFile(join(target, 'bin.cjs'), `if (!process.argv.includes('--dry-run')) { require('node:fs').writeFileSync('unexpected-apply', 'mutation'); process.exit(99); }\nconsole.log(JSON.stringify(process.argv.slice(2))); console.error('provider diagnostic');\n`);
    }
    const before = await initializationSnapshot(consumer);
    for (const [script, expected] of [
      ["console.log('failed provider'); process.exit(7);", { ok: false, output: 'failed provider\n', status: 7 }],
      ["console.log('  conflict existing file');", { ok: false, output: '  conflict existing file\n', status: 0 }],
      ["console.error('Conflicts (1)');", { ok: false, output: 'Conflicts (1)\n', status: 0 }],
    ]) {
      await writeFile(join(cli, 'node_modules/@prodshape/cli/bin.cjs'), script);
      const preview = execute(['--dry-run', '--format', 'json']);
      assert.equal(preview.status, 1);
      const report = JSON.parse(preview.stdout);
      assert.equal(report.status, 'blocked');
      assert.deepEqual(report.authorities[0].preflight, expected);
      assert.equal(report.authorities[1].preflight.ok, true);
      assert.equal(report.authorities[1].preflight.status, 0);
      assert.equal(report.authorities[1].preflight.output, '["init","--no-agents","--dry-run"]\nprovider diagnostic\n');
      assert.deepEqual(report.authorities.map(authority => authority.version), ['9.8.7', '9.8.7']);
      assert.match(preview.stderr, /ProductShape preflight failed; repair with: prodshape init --full --sdd none --gitignore/);
      const text = execute(['--dry-run']);
      assert.equal(text.status, 1);
      assert.match(text.stdout, /ProductShape preflight:/);
      assert.match(text.stderr, /ProductShape preflight failed/);
      assert.deepEqual(await initializationSnapshot(consumer), before);
    }
    for (const [name] of providers) {
      await rm(join(cli, 'node_modules', name), { recursive: true });
      const preview = execute(['--dry-run', '--format', 'json']);
      assert.equal(preview.status, 1);
      const report = JSON.parse(preview.stdout);
      assert.equal(report.status, 'blocked');
      const missing = report.authorities.find(authority => authority.provider === name);
      assert.equal(missing.version, null);
      assert.equal(missing.preflight.ok, false);
      assert.equal(missing.preflight.status, null);
      assert.match(missing.preflight.output, /Cannot find module/);
      assert.equal(report.authorities.length, 2);
      assert.deepEqual(await initializationSnapshot(consumer), before);
    }
    for (const args of [['--apply', '--format', 'json'], ['--apply', '--format=json'], ['--apply', '--dry-run', '--format', 'json']]) {
      const rejected = execute(args);
      assert.equal(rejected.status, 1);
      assert.equal(rejected.stdout, '');
      assert.match(rejected.stderr, /dry runs|cannot be used together/);
      assert.doesNotMatch(rejected.stderr, /Cannot find module|preflight failed/);
      assert.deepEqual(await initializationSnapshot(consumer), before);
    }
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('existing-authority adoption is dry-run by default and does not initialize missing providers', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-authority-adoption-absent-'));
  try {
    assert.equal(run(dir, 'init', ['--name', 'Existing']).status, 0);
    const before = await readFile(join(dir, 'lighthouse.json'), 'utf8');
    const plan = run(dir, 'authorities', ['--adopt-existing', '--format', 'json']);
    assert.equal(plan.status, 1);
    const report = JSON.parse(plan.stdout);
    assert.equal(report.status, 'blocked');
    assert.deepEqual(report.authorities.map((authority) => authority.status), ['absent', 'absent']);
    assert.equal(await readFile(join(dir, 'lighthouse.json'), 'utf8'), before);
    const applied = run(dir, 'authorities', ['--adopt-existing', '--apply']);
    assert.equal(applied.status, 1);
    assert.equal(await readFile(join(dir, 'lighthouse.json'), 'utf8'), before);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('existing-authority adoption validates providers, records only Lighthouse files and is idempotent', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-authority-adoption-valid-'));
  try {
    await mkdir(join(dir, 'docs'), { recursive: true });
    await cp(join(process.cwd(), 'docs/product'), join(dir, 'docs/product'), { recursive: true });
    await cp(join(process.cwd(), 'docs/architecture'), join(dir, 'docs/architecture'), { recursive: true });
    await cp(join(process.cwd(), 'docs/roadmap'), join(dir, 'docs/roadmap'), { recursive: true });
    for (const path of ['docs/process', 'src/tests']) {
      await cp(join(process.cwd(), path), join(dir, path), { recursive: true });
    }
    await mkdir(join(dir, 'src/examples/opencode-engine'), { recursive: true });
    await cp(join(process.cwd(), 'src/examples/opencode-engine/README.md'), join(dir, 'src/examples/opencode-engine/README.md'));
    await cp(join(process.cwd(), 'src/examples/opencode-engine/ENVIRONMENTS.md'), join(dir, 'src/examples/opencode-engine/ENVIRONMENTS.md'));
    await mkdir(join(dir, 'src/packages/sdlc'), { recursive: true });
    await cp(join(process.cwd(), 'src/packages/sdlc/host-contract.md'), join(dir, 'src/packages/sdlc/host-contract.md'));
    for (const file of ['handoffs.md', 'completion.md', 'request-triage.md', 'epic-delivery.md']) {
      await cp(join(process.cwd(), 'src/packages/sdlc', file), join(dir, 'src/packages/sdlc', file));
    }
    await cp(join(process.cwd(), 'src/packages/sdlc/execution-environments.md'), join(dir, 'src/packages/sdlc/execution-environments.md'));
    await cp(join(process.cwd(), 'src/packages/sdlc/README.md'), join(dir, 'src/packages/sdlc/README.md'));
    await cp(join(process.cwd(), 'src/packages/sdlc/unattended.md'), join(dir, 'src/packages/sdlc/unattended.md'));
    await cp(join(process.cwd(), 'src/packages/sdlc/github-actions.md'), join(dir, 'src/packages/sdlc/github-actions.md'));
    await cp(join(process.cwd(), 'src/packages/sdlc/workflows'), join(dir, 'src/packages/sdlc/workflows'), { recursive: true });
    await cp(join(process.cwd(), 'src/packages/sdlc/skills'), join(dir, 'src/packages/sdlc/skills'), { recursive: true });
    await cp(join(process.cwd(), 'src/packages/sdlc/src'), join(dir, 'src/packages/sdlc/src'), { recursive: true });
    await cp(join(process.cwd(), 'docs/releasing.md'), join(dir, 'docs/releasing.md'));
    await cp(join(process.cwd(), '.product'), join(dir, '.product'), { recursive: true });
    await mkdir(join(dir, 'src/packages/cli'), { recursive: true });
    await mkdir(join(dir, 'src/packages/ui'), { recursive: true });
    for (const pkg of ['cli', 'sdlc']) {
      await mkdir(join(dir, 'src/packages', pkg, 'src'), { recursive: true });
      await cp(join(process.cwd(), 'src/packages', pkg, 'src/github-profile.mjs'), join(dir, 'src/packages', pkg, 'src/github-profile.mjs'));
    }
    await cp(join(process.cwd(), 'src/packages/cli/README.md'), join(dir, 'src/packages/cli/README.md'));
    await mkdir(join(dir, 'src/packages/cli/assets/profiles'), { recursive: true });
    await cp(join(process.cwd(), 'src/packages/cli/assets/profiles/identity.md'), join(dir, 'src/packages/cli/assets/profiles/identity.md'));
    await cp(join(process.cwd(), 'src/packages/ui/README.md'), join(dir, 'src/packages/ui/README.md'));
    await cp(join(process.cwd(), 'src/packages/ui/DESIGN.md'), join(dir, 'src/packages/ui/DESIGN.md'));
    await symlink(join(process.cwd(), 'node_modules'), join(dir, 'node_modules'), 'dir');
    assert.equal(run(dir, 'init', ['--name', 'Existing']).status, 0);
    const providerFiles = [
      'docs/product/model/requirements/functional/fr-verify-foundation.md',
      'docs/architecture/README.md',
    ];
    const before = await Promise.all(providerFiles.map(async (path) => [path, await readFile(join(dir, path), 'utf8')]));
    const preview = run(dir, 'authorities', ['--adopt-existing', '--format', 'json']);
    assert.equal(preview.status, 0, `${preview.stdout}\n${preview.stderr}`);
    const plan = JSON.parse(preview.stdout);
    assert.equal(plan.status, 'ready');
    assert.deepEqual(plan.authorities.map((authority) => authority.status), ['ready', 'ready']);
    const manifestBeforeApply = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    assert.deepEqual(manifestBeforeApply.integrations, { productShape: null, arcShape: null });
    assert.equal(run(dir, 'authorities', ['--adopt-existing', '--apply']).status, 0);
    const manifest = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    assert.deepEqual(manifest.integrations, { productShape: '0.23.0', arcShape: '0.4.0' });
    for (const [path, content] of before) assert.equal(await readFile(join(dir, path), 'utf8'), content);
    const verified = run(dir, 'verify', ['--format', 'json']);
    assert.equal(verified.status, 0, `${verified.stdout}\n${verified.stderr}`);
    assert.equal(JSON.parse(verified.stdout).results.find((result) => result.id === 'foundation.authorities').status, 'passed');
    const repeated = run(dir, 'authorities', ['--adopt-existing', '--apply']);
    assert.equal(repeated.status, 0, `${repeated.stdout}\n${repeated.stderr}`);
    assert.match(repeated.stdout, /Recorded and verified/);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('profiles exposes applicability and verification layers without making them all mandatory', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-profiles-'));
  try {
    const initialized = run(dir, 'init', ['--name', 'FullStack', '--profile', 'dotnet-backend']);
    assert.equal(initialized.status, 0, initialized.stderr);
    let composition = JSON.parse(run(dir, 'profiles', ['--format', 'json']).stdout);
    assert.equal(composition.status, 'unconfigured');
    assert.equal(composition.selected[0].status, 'unconfigured');
    assert.deepEqual(composition.selected[0].verification.layers.map((layer) => layer.id), ['static', 'unit', 'architecture', 'integration', 'functional']);
    const selectedManifest = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    selectedManifest.application = { shape: 'full-stack', stacks: ['dotnet'] };
    await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(selectedManifest));
    composition = JSON.parse(run(dir, 'profiles', ['--format', 'json']).stdout);
    assert.equal(composition.status, 'passed');
    const report = JSON.parse(run(dir, 'verify', ['--format', 'json']).stdout);
    assert.equal(report.profiles.status, 'passed');
    assert.equal(report.results.find((item) => item.id === 'foundation.profile-composition').status, 'passed');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('profile catalog exposes adoptable metadata and rejects missing or incompatible composition', () => {
  const catalog = readProfileCatalog();
  for (const profile of catalog.profiles) {
    assert.ok(Array.isArray(profile.prerequisites));
    assert.ok(Array.isArray(profile.dependencies));
    assert.ok(Array.isArray(profile.incompatibleWith));
    assert.ok(Array.isArray(profile.commands));
    assert.ok(profile.guardrails.length > 0);
    assert.equal(typeof profile.consumerFixture, 'string');
    assert.equal(typeof profile.upgradeStrategy, 'string');
  }

  const custom = {
    schemaVersion: 1,
    profiles: [
      { ...catalog.profiles[0], id: 'web', dependencies: ['api'], incompatibleWith: ['mobile'] },
      { ...catalog.profiles[0], id: 'mobile', dependencies: [], incompatibleWith: [] },
    ],
  };
  const composition = composeProfiles(custom, { application: { shape: 'tooling', stacks: ['node'] }, profiles: ['web', 'mobile'] });
  assert.equal(composition.status, 'failed');
  assert.match(composition.selected[0].problems.join(' '), /requires the api profile/);
  assert.match(composition.selected[0].problems.join(' '), /incompatible with the mobile profile/);
  assert.match(composition.selected[0].nextAction, /required profiles/);
});

test('visual-theme init projects the UI guide and skill and verifies the token contract', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-ui-profile-'));
  try {
    const initialized = run(dir, 'init', ['--name', 'Visual', '--profile', 'visual-theme']);
    assert.equal(initialized.status, 0, initialized.stderr);
    const generated = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    assert.deepEqual(generated.profiles, ['visual-theme']);
    assert.deepEqual(generated.packages.ui, { name: '@juangcarmona/lighthouse-ui', version: uiPackage.version });
    assert.ok(generated.managed.includes('docs/design/DESIGN.md'));
    assert.ok(generated.managed.includes('.agents/skills/lighthouse-ui/SKILL.md'));
    assert.match(await readFile(join(dir, 'docs/design/DESIGN.md'), 'utf8'), /--lh-action/);
    assert.match(await readFile(join(dir, '.agents/skills/lighthouse-ui/SKILL.md'), 'utf8'), /semantic `--lh-\*` roles/);
    const report = JSON.parse(run(dir, 'verify', ['--format', 'json']).stdout);
    assert.equal(report.results.find((item) => item.id === 'visual.design-contract').status, 'passed');
    const skill = await readFile(join(dir, '.agents/skills/lighthouse-ui/SKILL.md'), 'utf8');
    await rm(join(dir, '.agents/skills/lighthouse-ui/SKILL.md'));
    const missing = JSON.parse(run(dir, 'verify', ['--format', 'json']).stdout);
    assert.equal(missing.results.find((item) => item.id === 'visual.design-contract').status, 'failed');
    await writeFile(join(dir, '.agents/skills/lighthouse-ui/SKILL.md'), skill);
    await writeFile(join(dir, 'docs/design/DESIGN.md'), 'project-owned visual guide');
    const drift = JSON.parse(run(dir, 'verify', ['--format', 'json']).stdout);
    assert.equal(drift.results.find((item) => item.id === 'visual.design-contract').status, 'drift');
    assert.equal(run(dir, 'verify', ['--format', 'json']).status, 1);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('react web profile projects its guidance and requires the visual contract', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-react-web-profile-'));
  try {
    const initialized = run(dir, 'init', ['--name', 'Web', '--profile', 'visual-theme', '--profile', 'react-web-platform']);
    assert.equal(initialized.status, 0, initialized.stderr);
    for (const file of [
      'docs/profiles/react-web-platform/README.md',
      'docs/profiles/react-web-platform/adoption.md',
      'docs/profiles/react-web-platform/structure.md',
      'docs/profiles/react-web-platform/guardrails.md',
      'docs/profiles/react-web-platform/testing.md',
      '.agents/skills/lighthouse-react-web/SKILL.md'
    ]) await access(join(dir, file));
    const selectedManifest = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    selectedManifest.application = { shape: 'frontend', stacks: ['react'] };
    await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(selectedManifest));
    const composition = JSON.parse(run(dir, 'profiles', ['--format', 'json']).stdout);
    assert.equal(composition.status, 'passed');
    assert.equal(composition.selected.find((profile) => profile.id === 'react-web-platform').dependencies[0], 'visual-theme');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('web BFF profile projects its security contract and requires the private web composition', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-web-bff-profile-'));
  try {
    const initialized = run(dir, 'init', ['--name', 'PrivateWeb', '--profile', 'visual-theme', '--profile', 'react-web-platform', '--profile', 'dotnet-backend', '--profile', 'web-bff']);
    assert.equal(initialized.status, 0, initialized.stderr);
    for (const file of [
      'docs/profiles/web-bff/README.md',
      'docs/profiles/web-bff/adoption.md',
      'docs/profiles/web-bff/security.md',
      'docs/profiles/web-bff/testing.md',
      '.agents/skills/lighthouse-web-bff/SKILL.md'
    ]) await access(join(dir, file));
    const selectedManifest = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    selectedManifest.application = { shape: 'full-stack', stacks: ['react', 'dotnet'] };
    await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(selectedManifest));
    const composition = JSON.parse(run(dir, 'profiles', ['--format', 'json']).stdout);
    assert.equal(composition.status, 'passed');
    assert.deepEqual(composition.selected.find((profile) => profile.id === 'web-bff').dependencies, ['react-web-platform', 'dotnet-backend']);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('PWA capability projects its offline contract as an optional React extension', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-pwa-profile-'));
  try {
    const initialized = run(dir, 'init', ['--name', 'Pwa', '--profile', 'visual-theme', '--profile', 'react-web-platform', '--profile', 'pwa-capability']);
    assert.equal(initialized.status, 0, initialized.stderr);
    for (const file of [
      'docs/profiles/pwa-capability/README.md',
      'docs/profiles/pwa-capability/adoption.md',
      'docs/profiles/pwa-capability/guardrails.md',
      'docs/profiles/pwa-capability/offline.md',
      'docs/profiles/pwa-capability/testing.md',
      '.agents/skills/lighthouse-pwa/SKILL.md'
    ]) await access(join(dir, file));
    const selectedManifest = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    selectedManifest.application = { shape: 'frontend', stacks: ['react'] };
    await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(selectedManifest));
    const composition = JSON.parse(run(dir, 'profiles', ['--format', 'json']).stdout);
    assert.equal(composition.status, 'passed');
    assert.deepEqual(composition.selected.find((profile) => profile.id === 'pwa-capability').dependencies, ['react-web-platform']);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('Expo mobile profile projects native guidance without selecting the React web profile', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-expo-profile-'));
  try {
    const initialized = run(dir, 'init', ['--name', 'Mobile', '--profile', 'mobile-expo', '--profile', 'dotnet-backend']);
    assert.equal(initialized.status, 0, initialized.stderr);
    for (const file of [
      'docs/profiles/mobile-expo/README.md',
      'docs/profiles/mobile-expo/adoption.md',
      'docs/profiles/mobile-expo/guardrails.md',
      'docs/profiles/mobile-expo/testing.md',
      '.agents/skills/lighthouse-mobile-expo/SKILL.md'
    ]) await access(join(dir, file));
    const selectedManifest = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    selectedManifest.application = { shape: 'full-stack', stacks: ['expo', 'dotnet'] };
    await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(selectedManifest));
    const composition = JSON.parse(run(dir, 'profiles', ['--format', 'json']).stdout);
    assert.equal(composition.status, 'passed');
    assert.equal(composition.selected.some((profile) => profile.id === 'react-web-platform'), false);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('MAUI mobile profile projects native guidance and rejects the Expo combination', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-maui-profile-'));
  try {
    const initialized = run(dir, 'init', ['--name', 'Maui', '--profile', 'mobile-maui', '--profile', 'dotnet-backend']);
    assert.equal(initialized.status, 0, initialized.stderr);
    for (const file of [
      'docs/profiles/mobile-maui/README.md',
      'docs/profiles/mobile-maui/adoption.md',
      'docs/profiles/mobile-maui/guardrails.md',
      'docs/profiles/mobile-maui/testing.md',
      '.agents/skills/lighthouse-mobile-maui/SKILL.md'
    ]) await access(join(dir, file));
    const selectedManifest = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    selectedManifest.application = { shape: 'full-stack', stacks: ['maui', 'dotnet'] };
    await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(selectedManifest));
    let composition = JSON.parse(run(dir, 'profiles', ['--format', 'json']).stdout);
    assert.equal(composition.status, 'passed');
    selectedManifest.profiles.push('mobile-expo');
    await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(selectedManifest));
    composition = JSON.parse(run(dir, 'profiles', ['--format', 'json']).stdout);
    assert.equal(composition.status, 'failed');
    assert.match(composition.selected.find((profile) => profile.id === 'mobile-maui').problems.join(' '), /incompatible with the mobile-expo profile/);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('visual-theme init reports a brownfield design conflict without overwriting it', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-ui-brownfield-'));
  try {
    await mkdir(join(dir, 'docs/design'), { recursive: true });
    await writeFile(join(dir, 'docs/design/DESIGN.md'), 'project-owned design');
    const preview = run(dir, 'init', ['--name', 'Visual', '--profile', 'visual-theme', '--dry-run']);
    assert.equal(preview.status, 1);
    assert.match(preview.stderr, /docs\/design\/DESIGN\.md already exists/);
    assert.equal(await readFile(join(dir, 'docs/design/DESIGN.md'), 'utf8'), 'project-owned design');
    assert.equal(await access(join(dir, 'lighthouse.json')).then(() => true).catch(() => false), false);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('visual-theme validation requires its pinned UI package', async () => {
  const dir = await fixture();
  try {
    const selected = { ...manifest, profiles: ['visual-theme'] };
    await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(selected));
    const missing = run(dir, 'verify', ['--format', 'json']);
    assert.equal(missing.status, 1);
    assert.match(missing.stdout, /packages must declare/);
    selected.packages = { sdlc: { name: sdlcPackage.name, version: sdlcPackage.version }, ui: { name: '@wrong/ui', version: '0.1.0' } };
    await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(selected));
    const invalid = run(dir, 'verify', ['--format', 'json']);
    assert.equal(invalid.status, 1);
    assert.match(invalid.stdout, /packages\.ui must declare/);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('init dry-run reports brownfield conflicts without writing', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-brownfield-'));
  try {
    await writeFile(join(dir, 'src'), 'project-owned file');
    const result = spawnSync(process.execPath, [tool, 'init', '--name', 'Brownfield', '--dry-run'], { cwd: dir, encoding: 'utf8' });
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /src exists but is not a directory/);
    assert.equal(await readFile(join(dir, 'src'), 'utf8'), 'project-owned file');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('reconcile previews and applies missing managed paths without overwriting drift', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    const missing = join(dir, '.github/workflows/lighthouse.yml');
    await rm(missing);
    const preview = run(dir, 'reconcile');
    assert.equal(preview.status, 0, preview.stderr);
    assert.match(preview.stdout, /create \.github\/workflows\/lighthouse\.yml/);
    assert.equal(await access(missing).then(() => true).catch(() => false), false);
    const applied = spawnSync(process.execPath, [tool, 'reconcile', '--apply'], { cwd: dir, encoding: 'utf8' });
    assert.equal(applied.status, 0, applied.stderr);
    assert.match(applied.stdout, /Reconciled missing/);
    const drifted = join(dir, 'LIGHTHOUSE.md');
    await writeFile(drifted, 'project-owned content');
    const conflict = run(dir, 'reconcile');
    assert.equal(conflict.status, 1);
    assert.match(conflict.stderr, /LIGHTHOUSE\.md exists with different content/);
    assert.equal(await readFile(drifted, 'utf8'), 'project-owned content');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('upgrade previews and applies a missing owned projection', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    const missing = join(dir, '.github/workflows/lighthouse.yml');
    await rm(missing);
    const preview = run(dir, 'upgrade', ['--scope', 'harness']);
    assert.equal(preview.status, 0, preview.stderr);
    assert.match(preview.stdout, /additive add \.github\/workflows\/lighthouse\.yml/);
    const machine = run(dir, 'upgrade', ['--scope', 'harness', '--format', 'json']);
    assert.equal(machine.status, 0, machine.stderr);
    assert.equal(JSON.parse(machine.stdout).changes.find((change) => change.path === '.github/workflows/lighthouse.yml').classification, 'additive');
    assert.equal(await access(missing).then(() => true).catch(() => false), false);
    const applied = run(dir, 'upgrade', ['--scope', 'harness', '--apply']);
    assert.equal(applied.status, 0, applied.stderr);
    assert.equal(await access(missing).then(() => true).catch(() => false), true);
    const state = JSON.parse(await readFile(join(dir, '.lighthouse/upgrade.json'), 'utf8'));
    assert.equal(state.files['.github/workflows/lighthouse.yml'].scope, 'harness');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('foundation initialization and upgrade preserve optional workflow ownership', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'lighthouse-optional-workflows-'));
  try {
    assert.equal(run(dir, 'init').status, 0);
    const path = join(dir, '.github/workflows/lighthouse-sdlc-refine.md');
    await assert.rejects(access(path));
    await writeFile(path, 'product-owned workflow');
    const manifest = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    manifest.managed.splice(manifest.managed.indexOf('.lighthouse/sdlc.json') + 1, 0, '.github/workflows/lighthouse-sdlc-router.yml', '.github/workflows/lighthouse-sdlc-refine.md', '.github/workflows/lighthouse-sdlc-refine.lock.yml', '.github/workflows/shared/lighthouse-sdlc-stage.md');
    await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(manifest));
    const result = run(dir, 'upgrade', ['--scope', 'sdlc', '--apply']);
    assert.equal(result.status, 0, result.stdout + result.stderr);
    assert.equal(await readFile(path, 'utf8'), 'product-owned workflow');
    const upgraded = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
    assert.equal(upgraded.managed.includes('.github/workflows/lighthouse-sdlc-refine.md'), false);
    await assert.rejects(access(join(dir, '.github/workflows/lighthouse-sdlc-implement.lock.yml')));
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('upgrade projects the alias map as an SDLC-owned projection', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    const aliasesPath = join(dir, '.lighthouse/commands.json');
    await rm(aliasesPath);
    const preview = run(dir, 'upgrade', ['--scope', 'sdlc', '--format', 'json']);
    assert.equal(preview.status, 0, preview.stderr);
    const plan = JSON.parse(preview.stdout);
    assert.equal(plan.changes.find((change) => change.path === '.lighthouse/commands.json').classification, 'additive');
    assert.equal(run(dir, 'upgrade', ['--scope', 'sdlc', '--apply']).status, 0);
    const aliases = JSON.parse(await readFile(aliasesPath, 'utf8'));
    assert.equal(aliases.aliases.find((item) => item.alias === '/lh:impl').canonical, '/lighthouse:implement');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('upgrade discovers pending SDLC capability adoption without writing remote or reconciliation state', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    const statePath = join(dir, '.lighthouse/upgrade.json');
    const state = JSON.parse(await readFile(statePath, 'utf8'));
    delete state.adoption;
    await writeFile(statePath, JSON.stringify(state));
    const preview = run(dir, 'upgrade', ['--format', 'json']);
    assert.equal(preview.status, 0, preview.stderr);
    const plan = JSON.parse(preview.stdout);
    assert.equal(plan.adoption.status, 'pending');
    assert.equal(plan.adoption.capabilities.labels.status, 'pending-adoption');
    assert.match(plan.adoption.capabilities.labels.nextAction, /lighthouse capabilities plan/);
    assert.equal(await access(join(dir, '.lighthouse/reconciliation/labels.plan.json')).then(() => true).catch(() => false), false);
    assert.equal(run(dir, 'upgrade', ['--apply']).status, 0);
    const applied = JSON.parse(await readFile(statePath, 'utf8'));
    assert.equal(applied.adoption.labels.status, 'pending-adoption');
    assert.equal(await access(join(dir, '.lighthouse/reconciliation/labels.json')).then(() => true).catch(() => false), false);
    const verified = JSON.parse(run(dir, 'verify', ['--format', 'json']).stdout);
    const adoption = verified.results.find((item) => item.id === 'foundation.capability-adoption');
    assert.equal(adoption.status, 'unconfigured');
    assert.equal(adoption.adoptionStatus, 'pending-adoption');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('a new label capability version requests adoption review without resetting other capabilities', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    const path = join(dir, '.lighthouse/upgrade.json');
    const state = JSON.parse(await readFile(path, 'utf8'));
    state.adoption.labels.version = '2';
    state.adoption.labels.status = 'adopted';
    state.adoption['github-profile'].status = 'declined';
    await writeFile(path, JSON.stringify(state));
    const before = await readFile(path, 'utf8');
    const preview = run(dir, 'upgrade', ['--format', 'json']);
    assert.equal(preview.status, 0, preview.stderr);
    const adoption = JSON.parse(preview.stdout).adoption.capabilities;
    assert.equal(adoption.labels.version, '4');
    assert.equal(adoption.labels.status, 'pending-adoption');
    assert.equal(adoption['github-profile'].status, 'declined');
    assert.equal(await readFile(path, 'utf8'), before);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('capability adoption requires the plan hash, creates only missing labels and is idempotent', async () => {
  const dir = await fixture();
  const labelsPath = join(dir, 'github-labels.json');
  const ghDirectory = join(dir, 'bin');
  const gh = join(ghDirectory, 'gh');
  try {
    await mkdir(ghDirectory);
    await writeFile(labelsPath, JSON.stringify([{ name: 'triage', color: '8B949E', description: 'project-owned' }]));
    await writeFile(gh, `#!/usr/bin/env node
import { readFileSync, writeFileSync } from 'node:fs';
const file = process.env.LIGHTHOUSE_TEST_LABELS;
const args = process.argv.slice(2);
let labels = JSON.parse(readFileSync(file, 'utf8'));
if (args[0] !== 'api') process.exit(2);
if (args[1] === '--method' && args[2] === 'POST') {
  const name = args.find((item) => item.startsWith('name='))?.slice(5);
  const color = args.find((item) => item.startsWith('color='))?.slice(6);
  const description = args.find((item) => item.startsWith('description='))?.slice(12) ?? '';
  if (!labels.some((label) => label.name === name)) labels.push({ name, color, description });
  writeFileSync(file, JSON.stringify(labels));
  console.log(JSON.stringify({ name, color, description }));
} else {
  console.log(JSON.stringify(labels));
}
`);
    await chmod(gh, 0o755);
    assert.equal(run(dir, 'init').status, 0);
    const environment = { PATH: `${ghDirectory}:${process.env.PATH}`, LIGHTHOUSE_TEST_LABELS: labelsPath };
    const planned = run(dir, 'capabilities', ['plan', '--id', 'labels', '--provider', 'github', '--repo', 'juan/demo', '--plan-file', '.lighthouse/reconciliation/labels.plan.json', '--format', 'json'], { env: environment });
    assert.equal(planned.status, 0, planned.stderr);
    const plan = JSON.parse(planned.stdout);
    const catalog = JSON.parse(await readFile(new URL('../packages/sdlc/capabilities.json', import.meta.url), 'utf8'));
    assert.equal(plan.reconciliation.operations.length, catalog.capabilities.find((item) => item.id === 'labels').configuration.labels.length - 1);
    assert.equal(run(dir, 'capabilities', ['apply', '--plan-file', '.lighthouse/reconciliation/labels.plan.json', '--authorize', 'wrong'], { env: environment }).status, 1);
    const applied = run(dir, 'capabilities', ['apply', '--plan-file', '.lighthouse/reconciliation/labels.plan.json', '--authorize', plan.authorization.planHash, '--format', 'json'], { env: environment });
    assert.equal(applied.status, 0, applied.stderr);
    assert.equal(JSON.parse(applied.stdout).status, 'adopted');
    assert.equal(JSON.parse(await readFile(join(dir, '.lighthouse/upgrade.json'), 'utf8')).adoption.labels.status, 'adopted');
    assert.equal(JSON.parse(await readFile(join(dir, '.lighthouse/reconciliation/labels.json'), 'utf8')).verified, true);
    const second = run(dir, 'capabilities', ['apply', '--plan-file', '.lighthouse/reconciliation/labels.plan.json', '--authorize', plan.authorization.planHash, '--format', 'json'], { env: environment });
    assert.equal(second.status, 0, second.stderr);
    assert.equal(JSON.parse(second.stdout).reconciliation.operations.length, 0);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('capability selection and decline are explicit local decisions', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    const declined = run(dir, 'capabilities', ['decline', '--id', 'labels', '--provider', 'github', '--format', 'json']);
    assert.equal(declined.status, 0, declined.stderr);
    assert.equal(JSON.parse(declined.stdout).status, 'declined');
    const verified = JSON.parse(run(dir, 'verify', ['--format', 'json']).stdout);
    const adoption = verified.results.find((item) => item.id === 'foundation.capability-adoption');
    assert.equal(adoption.status, 'not-applicable');
    assert.equal(adoption.adoptionStatus, 'declined');
    assert.equal(run(dir, 'capabilities', ['select', '--id', 'labels', '--provider', 'github']).status, 0);
    const selected = JSON.parse(run(dir, 'verify', ['--format', 'json']).stdout).results.find((item) => item.id === 'foundation.capability-adoption');
    assert.equal(selected.adoptionStatus, 'pending-adoption');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('upgrade preserves customized projections and reports missing ownership evidence', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    const projection = join(dir, 'LIGHTHOUSE.md');
    await writeFile(projection, 'project-owned content');
    const preview = run(dir, 'upgrade', ['--scope=harness']);
    assert.equal(preview.status, 0, preview.stderr);
    assert.match(preview.stdout, /customized preserve LIGHTHOUSE\.md/);
    assert.equal(run(dir, 'upgrade', ['--scope', 'harness', '--apply']).status, 0);
    assert.equal(await readFile(projection, 'utf8'), 'project-owned content');
    await rm(join(dir, '.lighthouse/upgrade.json'));
    const missing = run(dir, 'upgrade');
    assert.equal(missing.status, 1);
    assert.match(`${missing.stdout}${missing.stderr}`, /adoption gap/);
    assert.match(`${missing.stdout}${missing.stderr}`, /reconcile --apply/);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('upgrade stops a baseline mismatch for human review', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    const statePath = join(dir, '.lighthouse/upgrade.json');
    const state = JSON.parse(await readFile(statePath, 'utf8'));
    state.baseline = '0.0.0';
    await writeFile(statePath, JSON.stringify(state));
    const preview = run(dir, 'upgrade');
    assert.equal(preview.status, 0, preview.stderr);
    assert.match(preview.stdout, /breaking review baseline/);
    const applied = run(dir, 'upgrade', ['--apply']);
    assert.equal(applied.status, 1);
    assert.match(applied.stderr, /Upgrade stopped/);
    assert.equal(JSON.parse(await readFile(statePath, 'utf8')).baseline, '0.0.0');
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('verify keeps the human output and exposes the existing catalog as JSON', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    const text = run(dir, 'verify');
    assert.equal(text.status, 0, text.stderr);
    assert.equal(text.stdout.trim(), 'Lighthouse manifest, repository boundaries and managed projection are valid.');
    const json = run(dir, 'verify', ['--format', 'json']);
    assert.equal(json.status, 0, json.stderr);
    const report = JSON.parse(json.stdout);
    assert.equal(report.summary.failed, 0);
    assert.equal(report.summary.drift, 0);
    assert.ok(report.results.some((item) => item.id === 'foundation.manifest' && item.status === 'passed'));
    assert.ok(report.results.some((item) => item.id === 'repository.managed-projection' && item.status === 'passed'));
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('verify JSON distinguishes managed projection drift', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    await writeFile(join(dir, 'LIGHTHOUSE.md'), 'project-owned content');
    const result = run(dir, 'verify', ['--format=json']);
    assert.equal(result.status, 1);
    const report = JSON.parse(result.stdout);
    const managed = report.results.find((item) => item.id === 'repository.managed-projection');
    assert.equal(managed.status, 'drift');
    assert.match(managed.problems.join('\n'), /LIGHTHOUSE\.md has drifted/);
    assert.deepEqual(report.blocking, ['repository.managed-projection']);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('verify validates evidence indexes and reports drift without blocking delivery', async () => {
  const dir = await fixture();
  try {
    assert.equal(run(dir, 'init').status, 0);
    const evidence = {
      schemaVersion: 1,
      id: 'stage-1',
      runId: 'run-1',
      kind: 'stage-result',
      scope: 'delivery',
      status: 'passed',
      producer: 'fixture',
      subject: { type: 'product-requirement', id: 'FR-1' },
      payload: { status: 'passed' }
    };
    const built = buildEvidenceIndex([evidence], { indexId: 'index-1', repository: 'fixture/project', revision: 'abc123' });
    assert.deepEqual(built.errors, []);
    await mkdir(join(dir, '.lighthouse/evidence/records'), { recursive: true });
    await writeFile(join(dir, '.lighthouse/evidence/records/stage-1.json'), `${JSON.stringify(evidence, null, 2)}\n`);
    await writeFile(join(dir, '.lighthouse/evidence/index.json'), `${JSON.stringify(built.index, null, 2)}\n`);
    const verified = run(dir, 'verify', ['--format', 'json']);
    assert.equal(verified.status, 0, verified.stderr);
    const report = JSON.parse(verified.stdout);
    assert.equal(report.results.find((item) => item.id === 'foundation.evidence').status, 'passed');
    await writeFile(join(dir, '.lighthouse/evidence/records/stage-1.json'), `${JSON.stringify({ ...evidence, status: 'failed', nextAction: 'Repair the check.' }, null, 2)}\n`);
    const drift = run(dir, 'verify', ['--format', 'json']);
    assert.equal(drift.status, 0, drift.stderr);
    const driftReport = JSON.parse(drift.stdout);
    const evidenceResult = driftReport.results.find((item) => item.id === 'foundation.evidence');
    assert.equal(evidenceResult.status, 'failed');
    assert.equal(driftReport.blocking.includes('foundation.evidence'), false);
  } finally { await rm(dir, { recursive: true, force: true }); }
});

test('catalog keeps level and kind independent and records pending human review', () => {
  const catalog = readGuardrailCatalog();
  const layout = catalog.guardrails.find((item) => item.id === 'repository.layout');
  assert.equal(layout.level, 'required');
  assert.equal(layout.kind, 'hard');
  assert.equal(initialReviewStatus({ level: 'required', kind: 'soft', verification: 'human' }), 'pending-review');
  assert.equal(initialReviewStatus({ level: 'required', kind: 'hard', verification: 'semantic' }), 'pending-review');
  assert.equal(initialReviewStatus({ level: 'recommended', kind: 'soft', verification: 'deterministic' }), 'unavailable');
});

test('generated guidance follows adopted authorities and scopes the documentation-site gate', async () => {
  for (const integrations of [{ productShape: null, arcShape: null }, { productShape: '0.23.0', arcShape: null }, { productShape: '0.23.0', arcShape: '0.4.0' }]) {
    for (const enabled of [false, true]) {
      const dir = await fixture();
      try {
        const configured = { ...manifest, integrations, repository: { ...manifest.repository, publicSite: { enabled } } };
        await writeFile(join(dir, 'lighthouse.json'), JSON.stringify(configured));
        const result = run(dir, 'init');
        assert.equal(result.status, 0, result.stderr);
        const guide = await readFile(join(dir, 'LIGHTHOUSE.md'), 'utf8');
        for (const [key, name] of [['productShape', 'ProductShape'], ['arcShape', 'ArcShape']]) {
          assert.match(guide, new RegExp(integrations[key] ? `${name} is the adopted authority` : `${name} is not adopted`));
        }
        assert.match(guide, /Lighthouse documentation site/);
        assert.match(guide, /Application deployment follows the repository.s own delivery policy/);
        if (!enabled) assert.match(guide, /documentation site is disabled/);
        else if (Object.values(integrations).some(v => v === null)) assert.match(guide, /unavailable until both authorities are adopted and validate successfully/);
        else assert.match(guide, /publication requires successful ProductShape and ArcShape validation/);
        const after = JSON.parse(await readFile(join(dir, 'lighthouse.json'), 'utf8'));
        assert.deepEqual(after.integrations, integrations);
        assert.equal(after.repository.publicSite.enabled, enabled);
        await assert.rejects(access(join(dir, '.product')));
      } finally { await rm(dir, { recursive: true, force: true }); }
    }
  }
});
