from pathlib import Path
import subprocess,json,datetime,time,re,zipfile
root=Path('/tmp/lighthouse-closeout');p=root/'146-child-b-ci-interruption-control.json';assert not p.exists(),'Reconcile the saved control; never repeat a rerun/cancellation'
repo='repos/juangcarmona/lighthouse-serial-epic-20261105/';ci=42155003762;head='3c2ed8d2594d89ff1832ec350d14b8971986e80f';base='a5541fe979bda3439e0eaa2521d34ed27a0a38ee'
def api(path,body=None,method='POST'):
 args=['gh','api',repo+path]
 if body is not None:args+=['--method',method,'--input','-']
 raw=subprocess.check_output(args,input=None if body is None else json.dumps(body).encode(),timeout=40);return json.loads(raw) if raw.strip() else None
assert json.loads((root/'146-current-source-child-b-technical-approval.json').read_text())['state']=='verified'
r=api(f'actions/runs/{ci}');assert r['run_attempt']==1 and r['conclusion']=='success' and r['event']=='push' and r['head_sha']==head and r['head_branch']==f'lighthouse/verification-24-{head}'
assert api('git/ref/heads/main')['object']['sha']=='1baa746403e134c13015f0e9a9237956fd090a5f';pr=api('pulls/24');assert pr['head']['sha']==head and pr['base']['sha']==base and not pr['draft'] and not pr['merged']
s={'state':'intent','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':'juangcarmona/lighthouse-serial-epic-20261105','pr':24,'head':head,'base':base,'ci':ci,'originalAttempt':1,'originalConclusion':'success','classification':'Intentional cancellation of a running CI repetition, not a failing application test. Prove that a real nonpassing required check blocks native acceptance, then restore the same eligible push CI.','originalPR':{'head':pr['head']['sha'],'base':pr['base']['sha'],'candidate':pr['merge_commit_sha']}}
def save():p.write_text(json.dumps(s,indent=2)+'\n')
save();api(f'actions/runs/{ci}/rerun',{});s['state']='rerun-requested';save()
for _ in range(90):
 r=api(f'actions/runs/{ci}')
 if r['run_attempt']==2:
  jobs=api(f'actions/runs/{ci}/attempts/2/jobs?per_page=100')['jobs']
  if any(j['status']=='in_progress' for j in jobs):break
  if r['status']=='completed':s.update(state='window-missed',attempt2Conclusion=r['conclusion']);save();raise RuntimeError('No controlled interruption; do not claim a failure')
 time.sleep(2)
else:raise RuntimeError('CI repetition not running; observe the saved request without repeating it')
s.update(state='cancellation-intent',attempt2Jobs=jobs);save();api(f'actions/runs/{ci}/cancel',{});s['state']='cancellation-requested';save()
for _ in range(90):
 r=api(f'actions/runs/{ci}')
 if r['run_attempt']==2 and r['status']=='completed':break
 time.sleep(2)
else:raise RuntimeError('Cancellation not terminal; retain and observe without force cancellation')
assert r['conclusion']=='cancelled';s.update(state='ci-cancelled',cancelledAttempt=2);save();print(json.dumps({'state':s['state'],'ci':ci,'attempt':2}),flush=True)
observed=json.loads(subprocess.check_output(['/opt/bastion-ai/releases/foundation-20261010/node-v24.21.0-linux-x64/bin/node',str(root/'146-ci-gate-readonly.mjs')],timeout=90));assert observed=={'passed':False},'Do not send an acceptance request unless the real configured native check observer is blocking'
s.update(state='gate-confirmed-blocked',readOnlyGate=observed);save()
subprocess.run(['python3',str(root/'146-current-source-native-action-once.py'),'reject-b-ci',json.dumps({'issue':'19','action':'accept-child','child':'21','pull-request':'24','review':'5795377093','head':head,'base':base})],check=True,timeout=90)
request=json.loads((root/'146-current-source-epic-reject-b-ci.json').read_text());blocked=request['run'];s.update(state='negative-accept-dispatched',acceptanceRun=blocked);save()
for _ in range(100):
 native=api('actions/runs/'+str(blocked))
 if native['status']=='completed':break
 time.sleep(8)
else:raise RuntimeError('Negative acceptance remains active; leave CI cancelled until its outcome is known')
assert native['conclusion']=='failure','Unexpected native outcome; inspect actual PR/base before any restoration'
log=subprocess.check_output(['gh','run','view',str(blocked),'--repo','juangcarmona/lighthouse-serial-epic-20261105','--log-failed'],timeout=60);(root/'146-child-b-ci-rejection-original.log').write_bytes(log)
assert b'Epic merge checks are missing, pending or failed' in log,'A different guard blocked; do not claim CI enforcement'
current=api('pulls/24');assert not current['merged'] and current['head']['sha']==head and api('git/ref/heads/lighthouse/epic-19')['object']['sha']==base and api('issues/21')['state']=='open'
s.update(state='native-ci-rejection-verified',nativeError='Epic merge checks are missing, pending or failed',resourceUnchanged=True);save();print(json.dumps({'state':s['state'],'run':blocked}),flush=True)
assert api(f'actions/runs/{ci}')['run_attempt']==2
s['state']='restore-rerun-intent';save();api(f'actions/runs/{ci}/rerun',{});s['state']='restore-rerun-requested';save()
for _ in range(100):
 restored=api(f'actions/runs/{ci}')
 if restored['run_attempt']==3 and restored['status']=='completed':break
 time.sleep(5)
else:raise RuntimeError('Restore rerun still active; observe without another request')
assert restored['conclusion']=='success';assert json.loads(subprocess.check_output(['/opt/bastion-ai/releases/foundation-20261010/node-v24.21.0-linux-x64/bin/node',str(root/'146-ci-gate-readonly.mjs')],timeout=90))=={'passed':True}
s.update(state='verified-and-restored',restoredAttempt=3,restoredConclusion='success',configuredGatePassed=True);save();print(json.dumps({'state':s['state'],'negativeAcceptance':blocked,'ci':ci,'restoredAttempt':3}),flush=True)
