import { spawnSync } from 'node:child_process';
import { verifyEpicChecks } from '/srv/workspaces/juangcarmona/lighthouse/epic-completion-routing/src/packages/sdlc/src/epic-native.mjs';
const repository='juangcarmona/lighthouse-serial-epic-20261105';
const api=async(path,method='GET',body,optional=false)=>{if(method!=='GET')throw Error('Read-only CI observation');const r=spawnSync('gh',['api',`repos/${repository}/${path}`],{encoding:'utf8',timeout:40000});let value;try{value=JSON.parse(r.stdout);}catch{} if(optional&&value?.status==='404')return null;if(r.status!==0)throw Error(`Read ${path} failed: ${r.status}`);return value;};
const passed=await verifyEpicChecks(api,{repository,sourceRevision:'1baa746403e134c13015f0e9a9237956fd090a5f',base:'lighthouse/epic-19',head:'3c2ed8d2594d89ff1832ec350d14b8971986e80f',candidate:'51bcdc5e12881497e3382f17ad6233316023b3b1'});
process.stdout.write(JSON.stringify({passed})+'\n');
