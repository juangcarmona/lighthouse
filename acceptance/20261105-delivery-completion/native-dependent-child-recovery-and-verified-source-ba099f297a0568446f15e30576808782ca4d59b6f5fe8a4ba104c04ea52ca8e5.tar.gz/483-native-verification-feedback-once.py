from pathlib import Path
import subprocess,json,datetime
root=Path('/tmp/lighthouse-closeout');proof=root/'483-native-verification-feedback.json';assert not proof.exists(),'Reconcile saved review intent instead of resending'
repo='repos/juangcarmona/lighthouse-serial-epic-20261105/'
def api(path):return json.loads(subprocess.check_output(['gh','api',repo+path],timeout=40))
refine=api('actions/runs/42149988066');assert refine['conclusion']=='success'
p=api('pulls/24');head='3c2ed8d2594d89ff1832ec350d14b8971986e80f';base='a5541fe979bda3439e0eaa2521d34ed27a0a38ee'
assert p['state']=='open' and p['draft'] and p['head']['sha']==head and p['base']['sha']==base and p['base']['ref']=='lighthouse/epic-19'
assert api('git/ref/heads/main')['object']['sha']=='1baa746403e134c13015f0e9a9237956fd090a5f'
assert api('git/ref/heads/lighthouse/epic-19')['object']['sha']==base and api('issues/20')['state']=='closed'
assert not {'agent-working','human-working','future','needs-info'}&{x['name'] for x in api('issues/21')['labels']}
assert api('actions/runs/42147948486')['conclusion']=='failure'
body='''The formatter correction is present at this exact head. The original apply-review run passed its 16 tests and independent commands, then failed after writing the commit while checking GitHub PR-head propagation: https://github.com/juangcarmona/lighthouse-serial-epic-20261105/actions/runs/42147948486. Its failure and missing publication receipt remain retained; do not represent that run as published successfully.

Revalidate the existing candidate on this same PR and publish a fresh authenticated verification receipt. Preserve the formatter, its seven tests, all accepted slice A code/tests and planning files when they already satisfy #21. No file change is required merely to acknowledge this feedback; use the existing verification-only correction path. Run all configured independent checks. Do not recreate the PR or repeat any merge.

A remains accepted: issue #20, PR #22 head a2e56f0096eb14d3d282670dfec2cad068491540, review 5794295063, head CI 42139457389 and candidate CI 42140132074, candidate e6427945426a3152cc1351f39fd2c854a0254472, acceptance run 42140729235, merge/base a5541fe979bda3439e0eaa2521d34ed27a0a38ee. The trusted host must freshly verify those receipts and current-history inclusion. This technical feedback grants no product, merge or release approval.'''
s={'state':'intent','repository':'juangcarmona/lighthouse-serial-epic-20261105','pr':24,'head':head,'base':base,'refinement':42149988066,'originalFailedPublication':42147948486,'purpose':'Existing verification-only correction; retain original commit and failed producer, publish a fresh checked same-PR receipt','body':body,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save():proof.write_text(json.dumps(s,indent=2)+'\n')
save()
try:
 r=json.loads(subprocess.check_output(['gh','api',repo+'pulls/24/reviews','--method','POST','--input','-'],input=json.dumps({'commit_id':head,'event':'REQUEST_CHANGES','body':body}).encode(),timeout=40));s.update(state='verified',review=r['id'],url=r['html_url']);save();print(json.dumps(s))
except (subprocess.SubprocessError,OSError) as e:s.update(state='uncertain',error=type(e).__name__);save();raise
