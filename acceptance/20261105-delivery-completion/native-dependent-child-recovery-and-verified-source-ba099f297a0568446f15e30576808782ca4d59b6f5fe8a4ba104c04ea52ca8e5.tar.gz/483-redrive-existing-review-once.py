from pathlib import Path
import subprocess,json,datetime,time,re
root=Path('/tmp/lighthouse-closeout');p=root/'483-redrive-existing-review.json';assert not p.exists(),'Reconcile saved rerun intent instead of repeating'
repo='repos/juangcarmona/lighthouse-serial-epic-20261105/'
def api(path):return json.loads(subprocess.check_output(['gh','api',repo+path],timeout=40))
assert json.loads((root/'483-native-partial-recovery-qualified.json').read_text())['state']=='verified'
run=api('actions/runs/42150872097');assert run['run_attempt']==1 and run['conclusion']=='failure' and run['actor']['login']=='juangcarmona' and run['triggering_actor']['login']=='juangcarmona' and run['head_sha']=='3c2ed8d2594d89ff1832ec350d14b8971986e80f'
pr=api('pulls/24');head='3c2ed8d2594d89ff1832ec350d14b8971986e80f';assert pr['head']['sha']==head and pr['state']=='open' and pr['draft'] and pr['base']['sha']=='a5541fe979bda3439e0eaa2521d34ed27a0a38ee'
feedback=api('pulls/24/reviews/5794982780');original=json.loads((root/'483-native-verification-feedback.json').read_text());assert feedback['user']['login']=='juangcarmona' and feedback['state']=='CHANGES_REQUESTED' and feedback['commit_id']==head and feedback['body']==original['body']
assert api('git/ref/heads/main')['object']['sha']=='1baa746403e134c13015f0e9a9237956fd090a5f' and not {'agent-working','human-working'}&{x['name'] for x in api('issues/21')['labels']}
receipt=api('issues/comments/6674884379');value=json.loads(re.search(r'<!-- lighthouse-dispatch:(\{[^\n]*\}) -->',receipt['body'])[1]);assert value['status']=='failed' and value['workerRunId']=='42147948486'
s={'state':'intent','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalRouter':42150872097,'originalAttempt':1,'review':5794982780,'pr':24,'head':head,'scope':'Rerun the exact failed pre-dispatch owner review event after native known-effect reconciliation. Existing feedback identity remains unconsumed; no new review, reset or repeated A.'}
def save():p.write_text(json.dumps(s,indent=2)+'\n')
save()
try:subprocess.run(['gh','api',repo+'actions/runs/42150872097/rerun','--method','POST'],check=True,timeout=40);s['state']='sent';save()
except (subprocess.SubprocessError,OSError) as e:s.update(state='uncertain',error=type(e).__name__);save()
for _ in range(8):
 fresh=api('actions/runs/42150872097')
 if fresh['run_attempt']==2:s.update(state='observed',newAttempt=2,status=fresh['status'],url=fresh['html_url']+'/attempts/2');save();print(json.dumps(s));break
 time.sleep(3)
else:raise RuntimeError('Rerun not confirmed yet; inspect saved intent without repeating POST')
