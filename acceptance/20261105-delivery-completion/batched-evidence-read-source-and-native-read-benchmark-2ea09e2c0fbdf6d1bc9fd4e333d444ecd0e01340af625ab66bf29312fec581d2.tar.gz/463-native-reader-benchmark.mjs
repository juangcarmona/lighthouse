import { execFileSync } from 'node:child_process';
import childProcess from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { readUnattendedPlanningReview as before } from '/srv/workspaces/juangcarmona/lighthouse/final-review-recovery/src/packages/sdlc/src/unattended-planning-evidence.mjs';
import { readUnattendedPlanningReview as after } from '/srv/workspaces/juangcarmona/lighthouse/batched-evidence-reads/src/packages/sdlc/src/unattended-planning-evidence.mjs';
import { readZipJson } from '/srv/workspaces/juangcarmona/lighthouse/batched-evidence-reads/src/packages/sdlc/src/zip-json.mjs';
const input=readZipJson(await readFile('/tmp/lighthouse-closeout/395-final-recovery2-input.zip'),'context.json');
const token=execFileSync('gh',['auth','token'],{encoding:'utf8'}).trim();
const original=childProcess.execFileSync;
const proof={kind:'Read-only reconstruction of retained native final-review input, not a new native delivery or current write authorization',nativeInputRun:42103251008,nativeInputArtifact:13450108588,startedAt:new Date().toISOString(),trials:[]};
let trial;
childProcess.execFileSync=(command,args,options)=>{
 assert.equal(command,'gh');assert.equal(args[0],'api');assert.match(args[1],/^repos\/juangcarmona\/lighthouse\/actions\/artifacts\/[1-9][0-9]*\/zip$/);
 trial.zipAttempts++;const bytes=original(command,args,options);trial.zipBytes+=bytes.length;return bytes;
};
syncBuiltinESMExports();
const api=async(path,method='GET',body)=>{
 assert.equal(method,'GET');assert.equal(body,undefined);trial.apiGets++;
 const response=await fetch(`https://api.github.com/repos/juangcarmona/lighthouse/${path}`,{headers:{authorization:`Bearer ${token}`,accept:'application/vnd.github+json'},signal:AbortSignal.timeout(45000)});
 if(!response.ok)throw Error(`GitHub GET ${response.status}: ${path}`);return response.json();
};
try {
 for(const [label,reader] of [['before',before],['after',after]]) {
  trial={label,apiGets:0,zipAttempts:0,zipBytes:0};const start=performance.now();
  console.log(JSON.stringify({label,state:'reading original native artifact'}));
  const result=await reader(api,input.completion,input.priorIntegration);trial.elapsedMs=performance.now()-start;
  trial.available=result!==null;trial.resultSha256=result?createHash('sha256').update(JSON.stringify(result)).digest('hex'):null;
  trial.frozenTests=result?.regression?.frozenTests;proof.trials.push(trial);console.log(JSON.stringify(trial));
 }
 proof.completedAt=new Date().toISOString();proof.sameVerifiedResult=proof.trials[0].resultSha256!==null&&proof.trials[0].resultSha256===proof.trials[1].resultSha256;
 await writeFile('/tmp/lighthouse-closeout/463-native-reader-benchmark.json',JSON.stringify(proof,null,2)+'\n');
 assert.equal(proof.sameVerifiedResult,true);assert.equal(proof.trials[0].zipAttempts,13);assert.equal(proof.trials[1].zipAttempts,1);
}finally{childProcess.execFileSync=original;syncBuiltinESMExports();}
